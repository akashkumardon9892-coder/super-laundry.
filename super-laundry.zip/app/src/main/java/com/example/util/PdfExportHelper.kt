package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.Order
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfExportHelper {

    fun generateAndDownloadFinancialReportPdf(
        context: Context,
        totalRevenue: Double,
        activeOrdersCount: Int,
        completedOrdersCount: Int,
        totalShopsCount: Int,
        recentOrders: List<Order>
    ) {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 Size
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val titlePaint = Paint().apply {
                color = Color.parseColor("#EC4899") // Primary Pink
                textSize = 22f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val subtitlePaint = Paint().apply {
                color = Color.parseColor("#0F172A") // Navy
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val bodyPaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 11f
            }

            val headerBgPaint = Paint().apply {
                color = Color.parseColor("#F1F5F9")
            }

            var y = 40f

            // Header
            canvas.drawText("⚡ SUPER LAUNDRY - FINANCIAL & PLATFORM REPORT", 40f, y, titlePaint)
            y += 24f

            val sdf = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault())
            canvas.drawText("Generated On: ${sdf.format(Date())}", 40f, y, bodyPaint)
            y += 20f

            canvas.drawLine(40f, y, 555f, y, titlePaint)
            y += 25f

            // Financial Summary Box
            canvas.drawRect(40f, y, 555f, y + 90f, headerBgPaint)
            val boxY = y + 25f
            canvas.drawText("Total Platform Revenue: ₹${totalRevenue.toInt()}", 55f, boxY, subtitlePaint)
            canvas.drawText("Active Partner Stores: $totalShopsCount Shops", 55f, boxY + 20f, bodyPaint)
            canvas.drawText("Completed Orders: $completedOrdersCount | Active In-Progress Orders: $activeOrdersCount", 55f, boxY + 40f, bodyPaint)
            y += 110f

            // Recent Transactions Table
            canvas.drawText("📊 RECENT ORDER TRANSACTIONS & REVENUE INVOICES:", 40f, y, subtitlePaint)
            y += 20f

            // Table Header
            canvas.drawRect(40f, y, 555f, y + 22f, headerBgPaint)
            val thPaint = Paint().apply {
                color = Color.BLACK
                textSize = 10f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("Order ID", 45f, y + 15f, thPaint)
            canvas.drawText("Customer", 130f, y + 15f, thPaint)
            canvas.drawText("Store Name", 260f, y + 15f, thPaint)
            canvas.drawText("Status", 420f, y + 15f, thPaint)
            canvas.drawText("Amount", 495f, y + 15f, thPaint)
            y += 30f

            recentOrders.take(15).forEach { order ->
                canvas.drawText(order.orderNumber, 45f, y, bodyPaint)
                canvas.drawText(order.customerName.take(18), 130f, y, bodyPaint)
                canvas.drawText(order.shopName.take(20), 260f, y, bodyPaint)
                canvas.drawText(order.status.name, 420f, y, bodyPaint)
                canvas.drawText("₹${order.totalPrice.toInt()}", 495f, y, subtitlePaint)
                y += 22f
                if (y > 780f) return@forEach
            }

            // Footer
            y = 800f
            canvas.drawLine(40f, y, 555f, y, bodyPaint)
            canvas.drawText("Super Laundry AI Platform • Confidential Official Financial Record • www.superlaundry.in", 40f, y + 18f, bodyPaint)

            pdfDocument.finishPage(page)

            val downloadDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            val pdfFile = File(downloadDir, "SuperLaundry_Financial_Report_${System.currentTimeMillis()}.pdf")
            val outputStream = FileOutputStream(pdfFile)
            pdfDocument.writeTo(outputStream)
            outputStream.close()
            pdfDocument.close()

            Toast.makeText(context, "📄 PDF Downloaded & Saved: ${pdfFile.name}", Toast.LENGTH_LONG).show()

            // Open or Share PDF Intent
            val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", pdfFile)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                // Toast already shown
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "📄 PDF Generated! Report exported to Downloads folder.", Toast.LENGTH_LONG).show()
        }
    }

    fun generateAndDownloadInvoicePdf(context: Context, order: Order) {
        generateSingleOrderInvoicePdf(context, order)
    }

    fun generateSingleOrderInvoicePdf(context: Context, order: Order) {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val titlePaint = Paint().apply {
                color = Color.parseColor("#EC4899")
                textSize = 24f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val subtitlePaint = Paint().apply {
                color = Color.BLACK
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val bodyPaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 12f
            }

            var y = 50f

            canvas.drawText("⚡ SUPER LAUNDRY OFFICIAL INVOICE", 40f, y, titlePaint)
            y += 30f
            canvas.drawText("Order Receipt #: ${order.orderNumber}", 40f, y, subtitlePaint)
            y += 20f

            val sdf = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault())
            canvas.drawText("Date: ${sdf.format(Date(order.createdAt))}", 40f, y, bodyPaint)
            y += 25f

            canvas.drawLine(40f, y, 555f, y, titlePaint)
            y += 30f

            canvas.drawText("Customer Name: ${order.customerName}", 40f, y, bodyPaint)
            y += 20f
            canvas.drawText("Customer Phone: ${order.customerPhone}", 40f, y, bodyPaint)
            y += 20f
            canvas.drawText("Laundry Store: ${order.shopName}", 40f, y, bodyPaint)
            y += 20f
            canvas.drawText("Delivery Address: ${order.deliveryAddress}", 40f, y, bodyPaint)
            y += 35f

            canvas.drawText("ITEMS SUMMARY:", 40f, y, subtitlePaint)
            y += 20f
            canvas.drawText(order.itemsSummary, 40f, y, bodyPaint)
            y += 35f

            canvas.drawText("Order Status: ${order.status.name}", 40f, y, subtitlePaint)
            y += 25f

            val totalPaint = Paint().apply {
                color = Color.parseColor("#10B981")
                textSize = 18f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("Total Amount Paid: ₹${order.totalPrice.toInt()}", 40f, y, totalPaint)

            pdfDocument.finishPage(page)

            val downloadDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            val pdfFile = File(downloadDir, "Invoice_${order.orderNumber}.pdf")
            val outputStream = FileOutputStream(pdfFile)
            pdfDocument.writeTo(outputStream)
            outputStream.close()
            pdfDocument.close()

            Toast.makeText(context, "📄 Invoice PDF Downloaded: ${pdfFile.name}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(context, "📄 Invoice PDF Downloaded to Downloads!", Toast.LENGTH_LONG).show()
        }
    }
}
