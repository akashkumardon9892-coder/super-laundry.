package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.*

class Converters {
    @TypeConverter
    fun fromUserRole(role: UserRole): String = role.name

    @TypeConverter
    fun toUserRole(value: String): UserRole = enumValueOf(value)

    @TypeConverter
    fun fromServiceCategory(category: ServiceCategory): String = category.name

    @TypeConverter
    fun toServiceCategory(value: String): ServiceCategory = enumValueOf(value)

    @TypeConverter
    fun fromOrderStatus(status: OrderStatus): String = status.name

    @TypeConverter
    fun toOrderStatus(value: String): OrderStatus = enumValueOf(value)

    @TypeConverter
    fun fromSubscriptionPlan(plan: SubscriptionPlan): String = plan.name

    @TypeConverter
    fun toSubscriptionPlan(value: String): SubscriptionPlan = enumValueOf(value)

    @TypeConverter
    fun fromTicketStatus(status: TicketStatus): String = status.name

    @TypeConverter
    fun toTicketStatus(value: String): TicketStatus = enumValueOf(value)
}
