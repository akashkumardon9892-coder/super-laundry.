package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.DatabaseInitializer
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SuperLaundryRepository(context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val scope = CoroutineScope(Dispatchers.IO)

    // Current Session State
    private val _currentUser = MutableStateFlow<AppUser?>(null)
    val currentUser: StateFlow<AppUser?> = _currentUser

    private val _activeRole = MutableStateFlow<UserRole>(UserRole.CUSTOMER)
    val activeRole: StateFlow<UserRole> = _activeRole

    private val _superAdminDashboardType = MutableStateFlow(SuperAdminDashboardType.PLATFORM_CONTROL)
    val superAdminDashboardType: StateFlow<SuperAdminDashboardType> = _superAdminDashboardType

    private val _registeredSuperAdminPhone = MutableStateFlow("9876543210")
    val registeredSuperAdminPhone: StateFlow<String> = _registeredSuperAdminPhone

    init {
        scope.launch {
            DatabaseInitializer.seedInitialData(db)
            // Default user session as Customer or Super Admin if previously logged in
            val adminUser = db.appUserDao().getUserByPhone(_registeredSuperAdminPhone.value)
            if (adminUser != null) {
                _currentUser.value = adminUser
                _activeRole.value = UserRole.SUPER_ADMIN
            }
        }
    }

    // Role & Dashboard Switcher
    fun switchRole(role: UserRole) {
        _activeRole.value = role
    }

    fun switchSuperAdminDashboard() {
        val current = _superAdminDashboardType.value
        _superAdminDashboardType.value = if (current == SuperAdminDashboardType.PLATFORM_CONTROL) {
            SuperAdminDashboardType.MY_SUPER_LAUNDRY
        } else {
            SuperAdminDashboardType.PLATFORM_CONTROL
        }
    }

    fun updateRegisteredSuperAdminPhone(newPhone: String) {
        _registeredSuperAdminPhone.value = newPhone
        scope.launch {
            val user = db.appUserDao().getUserByPhone(newPhone) ?: AppUser(
                phone = newPhone,
                role = UserRole.SUPER_ADMIN,
                name = "Super Admin (Owner)",
                isSuperAdminPhone = true
            )
            db.appUserDao().insertUser(user)
        }
    }

    // Auth Flows
    suspend fun loginWithOtp(phone: String, role: UserRole): AppUser = withContext(Dispatchers.IO) {
        val cleanPhone = phone.trim().filter { it.isDigit() }.ifEmpty {
            when (role) {
                UserRole.SUPER_ADMIN -> _registeredSuperAdminPhone.value
                UserRole.LAUNDRY_ADMIN -> "9811122233"
                UserRole.CUSTOMER -> "9988776655"
            }
        }
        var user = db.appUserDao().getUserByPhone(cleanPhone)
        val isSuperAdmin = (cleanPhone == _registeredSuperAdminPhone.value)
        val targetRole = if (isSuperAdmin) UserRole.SUPER_ADMIN else role
        if (user == null) {
            user = AppUser(
                phone = cleanPhone,
                role = targetRole,
                name = if (isSuperAdmin) "Super Admin" else if (targetRole == UserRole.LAUNDRY_ADMIN) "Laundry Owner ($cleanPhone)" else "Customer ($cleanPhone)",
                isSuperAdminPhone = isSuperAdmin
            )
            db.appUserDao().insertUser(user)
        } else {
            if (user.role != targetRole && !user.isSuperAdminPhone) {
                user = user.copy(
                    role = targetRole,
                    name = if (targetRole == UserRole.LAUNDRY_ADMIN) "Laundry Owner ($cleanPhone)" else "Customer ($cleanPhone)"
                )
                db.appUserDao().insertUser(user)
            }
        }
        _currentUser.value = user
        _activeRole.value = user.role
        user
    }

    fun logout() {
        _currentUser.value = null
    }

    // Shops & Rate Cards
    fun getAllShops(): Flow<List<LaundryShop>> = db.laundryShopDao().getAllShops()

    suspend fun getShopById(id: String): LaundryShop? = db.laundryShopDao().getShopById(id)

    fun getRateCardForShop(shopId: String): Flow<List<RateCardItem>> = db.rateCardDao().getRateCardForShop(shopId)

    suspend fun updateRateCardItem(item: RateCardItem) = withContext(Dispatchers.IO) {
        db.rateCardDao().updateItem(item)
    }

    suspend fun insertRateCardItem(item: RateCardItem) = withContext(Dispatchers.IO) {
        db.rateCardDao().insertItem(item)
    }

    suspend fun deleteRateCardItem(itemId: String) = withContext(Dispatchers.IO) {
        db.rateCardDao().deleteItem(itemId)
    }

    suspend fun updateShopDetails(shop: LaundryShop) = withContext(Dispatchers.IO) {
        db.laundryShopDao().updateShop(shop)
    }

    suspend fun addLaundryShop(shop: LaundryShop) = withContext(Dispatchers.IO) {
        db.laundryShopDao().insertShop(shop)
    }

    suspend fun deleteLaundryShop(shopId: String) = withContext(Dispatchers.IO) {
        db.laundryShopDao().deleteShop(shopId)
    }

    // Orders
    fun getAllOrders(): Flow<List<Order>> = db.orderDao().getAllOrders()

    fun getOrdersForShop(shopId: String): Flow<List<Order>> = db.orderDao().getOrdersForShop(shopId)

    fun getOrdersForCustomer(phone: String): Flow<List<Order>> = db.orderDao().getOrdersForCustomer(phone)

    suspend fun placeOrder(order: Order) = withContext(Dispatchers.IO) {
        db.orderDao().insertOrder(order)
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: OrderStatus) = withContext(Dispatchers.IO) {
        val order = db.orderDao().getOrderById(orderId)
        if (order != null) {
            db.orderDao().updateOrder(order.copy(status = newStatus))
        }
    }

    // Chat
    fun getChatMessages(orderId: String): Flow<List<ChatMessage>> = db.chatDao().getMessagesForOrder(orderId)

    suspend fun sendChatMessage(message: ChatMessage) = withContext(Dispatchers.IO) {
        db.chatDao().insertMessage(message)
    }

    suspend fun deleteChatMessage(messageId: String) = withContext(Dispatchers.IO) {
        db.chatDao().deleteMessage(messageId)
    }

    suspend fun clearChatForOrder(orderId: String) = withContext(Dispatchers.IO) {
        db.chatDao().clearChatForOrder(orderId)
    }

    // Subscriptions
    fun getAllSubscriptions(): Flow<List<Subscription>> = db.subscriptionDao().getAllSubscriptions()

    suspend fun getSubscriptionForShop(shopId: String): Subscription? = db.subscriptionDao().getSubscriptionForShop(shopId)

    suspend fun createOrRenewSubscription(shopId: String, shopName: String, plan: SubscriptionPlan) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val durationMillis = plan.durationMonths * 30L * 24 * 60 * 60 * 1000
        val sub = Subscription(
            id = "sub_${shopId}_${System.currentTimeMillis()}",
            shopId = shopId,
            shopName = shopName,
            plan = plan,
            startDate = now,
            endDate = now + durationMillis,
            isActive = true
        )
        db.subscriptionDao().insertSubscription(sub)
    }

    // Support Tickets
    fun getAllSupportTickets(): Flow<List<SupportTicket>> = db.supportTicketDao().getAllTickets()

    fun getTicketsForRole(targetRole: UserRole): Flow<List<SupportTicket>> = db.supportTicketDao().getTicketsForRole(targetRole)

    suspend fun createSupportTicket(ticket: SupportTicket) = withContext(Dispatchers.IO) {
        db.supportTicketDao().insertTicket(ticket)
    }

    suspend fun updateTicketStatus(ticketId: String, status: TicketStatus, response: String? = null) = withContext(Dispatchers.IO) {
        val tickets = db.supportTicketDao().getAllTickets()
        // Find ticket or insert update
    }

    suspend fun deleteSupportTicket(ticketId: String) = withContext(Dispatchers.IO) {
        db.supportTicketDao().deleteTicket(ticketId)
    }

    suspend fun deleteOrder(orderId: String) = withContext(Dispatchers.IO) {
        db.orderDao().deleteOrder(orderId)
    }

    // Banners & Notifications
    fun getAllOfferBanners(): Flow<List<OfferBanner>> = db.offerBannerDao().getAllBanners()

    suspend fun addOfferBanner(banner: OfferBanner) = withContext(Dispatchers.IO) {
        db.offerBannerDao().insertBanner(banner)
    }

    suspend fun deleteOfferBanner(id: String) = withContext(Dispatchers.IO) {
        db.offerBannerDao().deleteBanner(id)
    }

    fun getAllNotifications(): Flow<List<NotificationItem>> = db.notificationDao().getAllNotifications()

    suspend fun sendBroadcastNotification(notification: NotificationItem) = withContext(Dispatchers.IO) {
        db.notificationDao().insertNotification(notification)
    }

    // Users & Customer Profile
    fun getAllAppUsers(): Flow<List<AppUser>> = db.appUserDao().getAllUsers()

    suspend fun saveOrUpdateUser(user: AppUser) = withContext(Dispatchers.IO) {
        db.appUserDao().insertUser(user)
        if (_currentUser.value?.phone == user.phone) {
            _currentUser.value = user
        }
    }

    suspend fun deleteAppUser(phone: String) = withContext(Dispatchers.IO) {
        db.appUserDao().deleteUser(phone)
    }
}
