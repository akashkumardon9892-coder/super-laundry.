package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    SUPER_ADMIN,
    LAUNDRY_ADMIN,
    CUSTOMER
}

enum class SuperAdminDashboardType {
    PLATFORM_CONTROL,
    MY_SUPER_LAUNDRY
}

enum class ServiceCategory(val displayName: String) {
    IRONING("Iron"),
    STEAM_PRESS("Steam Press"),
    DRY_CLEANING("Dry Cleaning")
}

enum class OrderStatus(val label: String) {
    NEW("New Order"),
    IN_PROCESS("In Process"),
    READY("Ready for Pickup"),
    COMPLETED("Completed"),
    CANCELLED("Cancelled")
}

enum class SubscriptionPlan(
    val title: String,
    val durationMonths: Int,
    val priceRupees: Int,
    val badge: String? = null
) {
    MONTHLY("Monthly Plan", 1, 999),
    QUARTERLY("Quarterly Saver", 3, 2699, "Save 10%"),
    HALF_YEARLY("Half-Yearly Pass", 6, 4999, "Popular"),
    YEARLY("Annual Gold", 12, 8999, "Best Value")
}

data class EditableSubscriptionPlan(
    val planId: String,
    val title: String,
    val durationMonths: Int,
    val priceRupees: Int,
    val badge: String? = null,
    val isFree: Boolean = false
)

enum class TicketStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED
}

@Entity(tableName = "laundry_shops")
data class LaundryShop(
    @PrimaryKey val id: String,
    val name: String,
    val ownerPhone: String,
    val logoUrl: String,
    val bannerUrl: String,
    val rating: Double,
    val reviewCount: Int,
    val distanceKm: Double,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val phone: String,
    val isOpen: Boolean = true,
    val isVerified: Boolean = true,
    val serviceAreaRadiusKm: Double = 5.0,
    val shopTiming: String = "8:00 AM - 9:00 PM",
    val description: String = "Premium eco-friendly steam ironing, gentle washing & dry cleaning."
)

@Entity(tableName = "rate_card_items")
data class RateCardItem(
    @PrimaryKey val id: String,
    val shopId: String,
    val category: ServiceCategory,
    val clothName: String,
    val photoUrl: String,
    val price: Double,
    val offerDiscountPercent: Int = 0,
    val unit: String = "pc"
)

data class CartItem(
    val rateCardItem: RateCardItem,
    val quantity: Int
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val id: String,
    val orderNumber: String,
    val shopId: String,
    val shopName: String,
    val customerPhone: String,
    val customerName: String,
    val itemsSummary: String, // e.g. "Shirts x 3, Suits x 1"
    val totalPrice: Double,
    val status: OrderStatus,
    val createdAt: Long = System.currentTimeMillis(),
    val deliveryAddress: String = "House #102, MG Road, Indiranagar, Bengaluru",
    val instructions: String = "",
    val totalItemsCount: Int = 1,
    val isLongTermOrder: Boolean = false
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey val id: String,
    val orderId: String,
    val senderRole: UserRole,
    val senderName: String,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val recipientRole: UserRole = UserRole.LAUNDRY_ADMIN,
    val recipientName: String = "Laundry Admin"
)

@Entity(tableName = "subscriptions")
data class Subscription(
    @PrimaryKey val id: String,
    val shopId: String,
    val shopName: String,
    val plan: SubscriptionPlan,
    val startDate: Long,
    val endDate: Long,
    val isActive: Boolean = true,
    val autoRenew: Boolean = true
)

@Entity(tableName = "support_tickets")
data class SupportTicket(
    @PrimaryKey val id: String,
    val createdByPhone: String,
    val createdByName: String,
    val userRole: UserRole,
    val targetRole: UserRole, // LAUNDRY_ADMIN or SUPER_ADMIN
    val title: String,
    val description: String,
    val status: TicketStatus = TicketStatus.OPEN,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "offer_banners")
data class OfferBanner(
    @PrimaryKey val id: String,
    val shopId: String?, // null if platform wide
    val title: String,
    val subtitle: String,
    val code: String,
    val discountPercent: Int,
    val isPlatformWide: Boolean = true,
    val imageUrl: String
)

@Entity(tableName = "notifications")
data class NotificationItem(
    @PrimaryKey val id: String,
    val senderRole: UserRole,
    val targetRole: String, // ALL_LAUNDRY_ADMIN, ALL_CUSTOMER, SINGLE_LAUNDRY, SINGLE_CUSTOMER
    val targetId: String? = null, // shopId or customerPhone
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "app_users")
data class AppUser(
    @PrimaryKey val phone: String,
    val role: UserRole,
    val name: String,
    val email: String? = null,
    val currentShopId: String? = null,
    val isSuperAdminPhone: Boolean = false,
    val address: String = "House #102, MG Road, Indiranagar, Bengaluru",
    val isLongTermCustomer: Boolean = false,
    val subscriptionPlanName: String? = null
)

data class StaterUpdate(
    val id: String = java.util.UUID.randomUUID().toString(),
    val authorPhone: String,
    val authorName: String,
    val authorRole: UserRole,
    val shopId: String? = null,
    val shopName: String? = null,
    val mediaUrl: String,
    val isVideo: Boolean = false,
    val caption: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class DynamicPlatformRule(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val ruleCategory: String = "Pricing & Operational Niyam", // Pricing, Shop Rules, Delivery, Customer Terms
    val isEnabled: Boolean = true,
    val addedBySuperAdmin: String = "Super Admin"
)

data class DynamicAppTool(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val promptUsed: String,
    val description: String,
    val toolCategory: String = "New Laundry Service", // Laundry Extension, Payment & Discounts, AI Automation, Special Services
    val isEnabled: Boolean = true,
    val createdTimestamp: Long = System.currentTimeMillis()
)

data class FutureFeatureConfig(
    val id: String = "feat_${System.currentTimeMillis()}",
    val featureName: String,
    val promptDescription: String,
    val requirements: String = "",
    val targetRole: String = "All Roles", // Super Admin, Laundry Admin, Customer, All Roles
    val targetDashboard: String = "Super Admin Platform", // Super Admin Store, Super Admin Platform, Laundry Admin, Customer
    val isEnabled: Boolean = true,
    val createdTimestamp: Long = System.currentTimeMillis(),
    val version: String = "v1.0"
)

