package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.model.*

@Database(
    entities = [
        LaundryShop::class,
        RateCardItem::class,
        Order::class,
        ChatMessage::class,
        Subscription::class,
        SupportTicket::class,
        OfferBanner::class,
        NotificationItem::class,
        AppUser::class
    ],
    version = 3,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun laundryShopDao(): LaundryShopDao
    abstract fun rateCardDao(): RateCardDao
    abstract fun orderDao(): OrderDao
    abstract fun chatDao(): ChatDao
    abstract fun subscriptionDao(): SubscriptionDao
    abstract fun supportTicketDao(): SupportTicketDao
    abstract fun offerBannerDao(): OfferBannerDao
    abstract fun notificationDao(): NotificationDao
    abstract fun appUserDao(): AppUserDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "super_laundry_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
