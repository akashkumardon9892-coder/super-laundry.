package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LaundryShopDao {
    @Query("SELECT * FROM laundry_shops")
    fun getAllShops(): Flow<List<LaundryShop>>

    @Query("SELECT * FROM laundry_shops WHERE id = :id LIMIT 1")
    suspend fun getShopById(id: String): LaundryShop?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShop(shop: LaundryShop)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShops(shops: List<LaundryShop>)

    @Update
    suspend fun updateShop(shop: LaundryShop)

    @Query("DELETE FROM laundry_shops WHERE id = :id")
    suspend fun deleteShop(id: String)
}

@Dao
interface RateCardDao {
    @Query("SELECT * FROM rate_card_items WHERE shopId = :shopId")
    fun getRateCardForShop(shopId: String): Flow<List<RateCardItem>>

    @Query("SELECT * FROM rate_card_items WHERE shopId = :shopId AND category = :category")
    fun getRateCardByCategory(shopId: String, category: ServiceCategory): Flow<List<RateCardItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRateCardItems(items: List<RateCardItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: RateCardItem)

    @Update
    suspend fun updateItem(item: RateCardItem)

    @Query("DELETE FROM rate_card_items WHERE id = :itemId")
    suspend fun deleteItem(itemId: String)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE shopId = :shopId ORDER BY createdAt DESC")
    fun getOrdersForShop(shopId: String): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE customerPhone = :phone ORDER BY createdAt DESC")
    fun getOrdersForCustomer(phone: String): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id LIMIT 1")
    suspend fun getOrderById(id: String): Order?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Update
    suspend fun updateOrder(order: Order)

    @Query("DELETE FROM orders WHERE id = :id")
    suspend fun deleteOrder(id: String)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages WHERE orderId = :orderId ORDER BY timestamp ASC")
    fun getMessagesForOrder(orderId: String): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessage)

    @Query("DELETE FROM chat_messages WHERE id = :messageId")
    suspend fun deleteMessage(messageId: String)

    @Query("DELETE FROM chat_messages WHERE orderId = :orderId")
    suspend fun clearChatForOrder(orderId: String)
}

@Dao
interface SubscriptionDao {
    @Query("SELECT * FROM subscriptions")
    fun getAllSubscriptions(): Flow<List<Subscription>>

    @Query("SELECT * FROM subscriptions WHERE shopId = :shopId LIMIT 1")
    suspend fun getSubscriptionForShop(shopId: String): Subscription?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscription(subscription: Subscription)

    @Update
    suspend fun updateSubscription(subscription: Subscription)
}

@Dao
interface SupportTicketDao {
    @Query("SELECT * FROM support_tickets ORDER BY createdAt DESC")
    fun getAllTickets(): Flow<List<SupportTicket>>

    @Query("SELECT * FROM support_tickets WHERE targetRole = :targetRole ORDER BY createdAt DESC")
    fun getTicketsForRole(targetRole: UserRole): Flow<List<SupportTicket>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: SupportTicket)

    @Update
    suspend fun updateTicket(ticket: SupportTicket)

    @Query("DELETE FROM support_tickets WHERE id = :id")
    suspend fun deleteTicket(id: String)
}

@Dao
interface OfferBannerDao {
    @Query("SELECT * FROM offer_banners")
    fun getAllBanners(): Flow<List<OfferBanner>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBanners(banners: List<OfferBanner>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBanner(banner: OfferBanner)

    @Query("DELETE FROM offer_banners WHERE id = :id")
    suspend fun deleteBanner(id: String)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationItem)
}

@Dao
interface AppUserDao {
    @Query("SELECT * FROM app_users")
    fun getAllUsers(): Flow<List<AppUser>>

    @Query("SELECT * FROM app_users WHERE phone = :phone LIMIT 1")
    suspend fun getUserByPhone(phone: String): AppUser?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: AppUser)

    @Update
    suspend fun updateUser(user: AppUser)

    @Query("DELETE FROM app_users WHERE phone = :phone")
    suspend fun deleteUser(phone: String)
}
