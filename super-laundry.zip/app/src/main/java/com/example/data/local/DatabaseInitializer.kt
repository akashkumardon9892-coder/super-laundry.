package com.example.data.local

import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object DatabaseInitializer {

    suspend fun seedInitialData(db: AppDatabase) = withContext(Dispatchers.IO) {
        val shopDao = db.laundryShopDao()
        val rateDao = db.rateCardDao()
        val orderDao = db.orderDao()
        val bannerDao = db.offerBannerDao()
        val subDao = db.subscriptionDao()
        val ticketDao = db.supportTicketDao()
        val userDao = db.appUserDao()
        val chatDao = db.chatDao()

        // 1. App Users & Default Super Admin
        userDao.insertUser(
            AppUser(
                phone = "9876543210",
                role = UserRole.SUPER_ADMIN,
                name = "Super Admin (Owner)",
                email = "admin@superlaundry.in",
                isSuperAdminPhone = true
            )
        )
        userDao.insertUser(
            AppUser(
                phone = "9811122233",
                role = UserRole.LAUNDRY_ADMIN,
                name = "Rajesh Verma",
                currentShopId = "shop_1"
            )
        )
        userDao.insertUser(
            AppUser(
                phone = "9988776655",
                role = UserRole.CUSTOMER,
                name = "Priya Sharma"
            )
        )

        // 2. Shops
        val flagshipShop = LaundryShop(
            id = "shop_flagship",
            name = "Super Laundry Flagship",
            ownerPhone = "9876543210",
            logoUrl = "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=300&q=80",
            bannerUrl = "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?auto=format&fit=crop&w=800&q=80",
            rating = 4.95,
            reviewCount = 342,
            distanceKm = 0.8,
            address = "100 Feet Road, Indiranagar, Bengaluru",
            latitude = 12.9716,
            longitude = 77.6412,
            phone = "+91 98765 43210",
            isOpen = true,
            isVerified = true
        )

        val shop1 = LaundryShop(
            id = "shop_1",
            name = "Express White Steam Laundry",
            ownerPhone = "9811122233",
            logoUrl = "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=300&q=80",
            bannerUrl = "https://images.unsplash.com/photo-1521656693074-0ef32e80a5d5?auto=format&fit=crop&w=800&q=80",
            rating = 4.9,
            reviewCount = 215,
            distanceKm = 1.2,
            address = "12th Main, HAL 2nd Stage, Indiranagar, Bengaluru",
            latitude = 12.9784,
            longitude = 77.6408,
            phone = "+91 98111 22233",
            isOpen = true,
            isVerified = true
        )

        val shop2 = LaundryShop(
            id = "shop_2",
            name = "Royal Dry Cleaners & Steam",
            ownerPhone = "9822233344",
            logoUrl = "https://images.unsplash.com/photo-1567113463300-102a7eb3cb26?auto=format&fit=crop&w=300&q=80",
            bannerUrl = "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=800&q=80",
            rating = 4.8,
            reviewCount = 180,
            distanceKm = 2.5,
            address = "80 Feet Road, 4th Block, Koramangala, Bengaluru",
            latitude = 12.9352,
            longitude = 77.6245,
            phone = "+91 98222 33344",
            isOpen = true,
            isVerified = true
        )

        val shop3 = LaundryShop(
            id = "shop_3",
            name = "EcoWash Premium Care",
            ownerPhone = "9833344455",
            logoUrl = "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?auto=format&fit=crop&w=300&q=80",
            bannerUrl = "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=800&q=80",
            rating = 4.7,
            reviewCount = 96,
            distanceKm = 3.1,
            address = "Sector 2, HSR Layout, Bengaluru",
            latitude = 12.9121,
            longitude = 77.6446,
            phone = "+91 98333 44455",
            isOpen = true,
            isVerified = true
        )

        shopDao.insertShops(listOf(flagshipShop, shop1, shop2, shop3))

        // 3. Rate Card Items for shop_1 & flagship (Iron, Steam Press, Dry Cleaning)
        val rateCardItems = listOf(
            // --- IRON CATEGORY ---
            RateCardItem("rc_1", "shop_1", ServiceCategory.IRONING, "Casual Cotton Shirt", "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80", 12.0, 10),
            RateCardItem("rc_2", "shop_1", ServiceCategory.IRONING, "T-Shirt / Polo", "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=200&q=80", 10.0),
            RateCardItem("rc_3", "shop_1", ServiceCategory.IRONING, "Jeans & Casual Pants", "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=200&q=80", 15.0),
            RateCardItem("rc_4", "shop_1", ServiceCategory.IRONING, "Dailywear Saree", "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80", 30.0),
            RateCardItem("rc_5", "shop_1", ServiceCategory.IRONING, "Kurti & Tops", "https://images.unsplash.com/photo-1564257631407-4deb1f99d992?auto=format&fit=crop&w=200&q=80", 12.0),
            RateCardItem("rc_6", "shop_1", ServiceCategory.IRONING, "Leggings & Shorts", "https://images.unsplash.com/photo-1506629082925-2368c7f76df1?auto=format&fit=crop&w=200&q=80", 10.0),
            RateCardItem("rc_7", "shop_1", ServiceCategory.IRONING, "Salwar & Pyjamas", "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=200&q=80", 12.0),
            RateCardItem("rc_8", "shop_1", ServiceCategory.IRONING, "Towels & Handkerchiefs", "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=200&q=80", 5.0),

            // --- STEAM PRESS CATEGORY ---
            RateCardItem("rc_sp1", "shop_1", ServiceCategory.STEAM_PRESS, "Formal Executive Shirt", "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80", 20.0, 15),
            RateCardItem("rc_sp2", "shop_1", ServiceCategory.STEAM_PRESS, "Formal Trouser Pants", "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&w=200&q=80", 25.0),
            RateCardItem("rc_sp3", "shop_1", ServiceCategory.STEAM_PRESS, "Premium Silk Saree", "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80", 60.0),
            RateCardItem("rc_sp4", "shop_1", ServiceCategory.STEAM_PRESS, "Kurta & Pyjama Set", "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=200&q=80", 35.0),
            RateCardItem("rc_sp5", "shop_1", ServiceCategory.STEAM_PRESS, "Starch Cotton Shirt / Kurta", "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=200&q=80", 30.0),
            RateCardItem("rc_sp6", "shop_1", ServiceCategory.STEAM_PRESS, "Frocks & Party Dresses", "https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?auto=format&fit=crop&w=200&q=80", 45.0),
            RateCardItem("rc_sp7", "shop_1", ServiceCategory.STEAM_PRESS, "Bell-Bottom Trousers", "https://images.unsplash.com/photo-1582552938357-32b906df40cb?auto=format&fit=crop&w=200&q=80", 28.0),
            RateCardItem("rc_sp8", "shop_1", ServiceCategory.STEAM_PRESS, "Formal Blazer / Waistcoat", "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=200&q=80", 80.0),

            // --- DRY CLEANING CATEGORY ---
            RateCardItem("rc_dc1", "shop_1", ServiceCategory.DRY_CLEANING, "Heavy Blanket / Comforter", "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=200&q=80", 399.0, 10),
            RateCardItem("rc_dc2", "shop_1", ServiceCategory.DRY_CLEANING, "Heavy Winter Coat & Jacket", "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?auto=format&fit=crop&w=200&q=80", 299.0),
            RateCardItem("rc_dc3", "shop_1", ServiceCategory.DRY_CLEANING, "Traditional Sherwani & Kurta Set", "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=200&q=80", 499.0),
            RateCardItem("rc_dc4", "shop_1", ServiceCategory.DRY_CLEANING, "2-Piece Suit & Tuxedo", "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=200&q=80", 349.0),
            RateCardItem("rc_dc5", "shop_1", ServiceCategory.DRY_CLEANING, "Woolen Sweater & Cardigan", "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=200&q=80", 149.0),
            RateCardItem("rc_dc6", "shop_1", ServiceCategory.DRY_CLEANING, "Heavy Designer Lehenga / Frock", "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=200&q=80", 499.0),
            RateCardItem("rc_dc7", "shop_1", ServiceCategory.DRY_CLEANING, "Designer Silk Saree & Dupatta", "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80", 199.0),
            RateCardItem("rc_dc8", "shop_1", ServiceCategory.DRY_CLEANING, "Scarves, Stoles & Stockings", "https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?auto=format&fit=crop&w=200&q=80", 79.0),

            // Flagship shop items
            RateCardItem("rc_f1", "shop_flagship", ServiceCategory.IRONING, "Express Casual Ironing", "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80", 15.0),
            RateCardItem("rc_f2", "shop_flagship", ServiceCategory.STEAM_PRESS, "Express Steam Press", "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?auto=format&fit=crop&w=200&q=80", 25.0),
            RateCardItem("rc_f3", "shop_flagship", ServiceCategory.DRY_CLEANING, "Italian Suit Dry Clean", "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=200&q=80", 399.0)
        )
        rateDao.insertRateCardItems(rateCardItems)

        // 4. Sample Orders
        val orders = listOf(
            Order(
                id = "ord_101",
                orderNumber = "SL-8492",
                shopId = "shop_1",
                shopName = "Express White Steam Laundry",
                customerPhone = "9988776655",
                customerName = "Priya Sharma",
                itemsSummary = "Cotton Shirts x 4, Silk Saree x 1",
                totalPrice = 120.0,
                status = OrderStatus.NEW,
                createdAt = System.currentTimeMillis() - 1000 * 60 * 25,
                totalItemsCount = 5
            ),
            Order(
                id = "ord_102",
                orderNumber = "SL-8490",
                shopId = "shop_1",
                shopName = "Express White Steam Laundry",
                customerPhone = "9876500011",
                customerName = "Anjali Kumar",
                itemsSummary = "Wash & Iron (3.5 kg), 2-Piece Blazer x 1",
                totalPrice = 695.0,
                status = OrderStatus.IN_PROCESS,
                createdAt = System.currentTimeMillis() - 1000 * 60 * 180,
                totalItemsCount = 4
            ),
            Order(
                id = "ord_103",
                orderNumber = "SL-8485",
                shopId = "shop_1",
                shopName = "Express White Steam Laundry",
                customerPhone = "9776655443",
                customerName = "Vikram Patel",
                itemsSummary = "Steam Iron Trousers x 5",
                totalPrice = 100.0,
                status = OrderStatus.READY,
                createdAt = System.currentTimeMillis() - 1000 * 60 * 600,
                totalItemsCount = 5
            ),
            Order(
                id = "ord_104",
                orderNumber = "SL-8470",
                shopId = "shop_1",
                shopName = "Express White Steam Laundry",
                customerPhone = "9988776655",
                customerName = "Priya Sharma",
                itemsSummary = "Heavy Designer Lehenga x 1",
                totalPrice = 499.0,
                status = OrderStatus.COMPLETED,
                createdAt = System.currentTimeMillis() - 1000 * 60 * 60 * 28,
                totalItemsCount = 1
            )
        )
        for (ord in orders) {
            orderDao.insertOrder(ord)
        }

        // 5. Initial Chat Messages for ord_101
        chatDao.insertMessage(
            ChatMessage("msg_1", "ord_101", UserRole.CUSTOMER, "Priya Sharma", "Hi! Please use starch on the cotton shirts.")
        )
        chatDao.insertMessage(
            ChatMessage("msg_2", "ord_101", UserRole.LAUNDRY_ADMIN, "Express White Laundry", "Sure ma'am! We will give crisp steam ironing and starch for free.")
        )

        // 6. Offer Banners
        val banners = listOf(
            OfferBanner("b_1", null, "FESTIVE OUTFITS 50% OFF", "Flat 50% OFF on first Dry Cleaning order", "SUPERDRY50", 50, true, "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=800&q=80"),
            OfferBanner("b_2", "shop_1", "EXPRESS STEAM IRON @ ₹12", "Subscribe & get instant 24-hr turnaround", "STEAM12", 20, false, "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?auto=format&fit=crop&w=800&q=80"),
            OfferBanner("b_3", null, "FREE HOME PICKUP & DELIVERY", "On all orders above ₹299 across Bengaluru", "FREEDEL", 100, true, "https://images.unsplash.com/photo-1521656693074-0ef32e80a5d5?auto=format&fit=crop&w=800&q=80")
        )
        bannerDao.insertBanners(banners)

        // 7. Subscriptions for Laundry Admins
        val now = System.currentTimeMillis()
        val oneYearMillis = 365L * 24 * 60 * 60 * 1000
        subDao.insertSubscription(
            Subscription(
                id = "sub_shop1",
                shopId = "shop_1",
                shopName = "Express White Steam Laundry",
                plan = SubscriptionPlan.YEARLY,
                startDate = now - 1000L * 60 * 60 * 24 * 30,
                endDate = now + oneYearMillis - (1000L * 60 * 60 * 24 * 30),
                isActive = true
            )
        )
        subDao.insertSubscription(
            Subscription(
                id = "sub_shop2",
                shopId = "shop_2",
                shopName = "Royal Dry Cleaners & Steam",
                plan = SubscriptionPlan.MONTHLY,
                startDate = now - 1000L * 60 * 60 * 24 * 25,
                endDate = now + (1000L * 60 * 60 * 24 * 5),
                isActive = true
            )
        )

        // 8. Sample Support Tickets
        ticketDao.insertTicket(
            SupportTicket(
                id = "tick_1",
                createdByPhone = "9811122233",
                createdByName = "Rajesh Verma (Express White)",
                userRole = UserRole.LAUNDRY_ADMIN,
                targetRole = UserRole.SUPER_ADMIN,
                title = "Need assistance updating UPI QR Code for shop",
                description = "We updated our bank account and want to refresh the QR banner on our profile.",
                status = TicketStatus.OPEN,
                createdAt = System.currentTimeMillis() - 1000 * 60 * 120
            )
        )
    }
}
