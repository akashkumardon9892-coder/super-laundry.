package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.StaterUpdate
import com.example.data.model.UserRole
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryPink

@Composable
fun StaterStoryBar(
    staters: List<StaterUpdate>,
    currentRole: UserRole,
    currentUserPhone: String,
    onAddStaterClick: () -> Unit,
    onStaterClick: (StaterUpdate) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 2.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = PrimaryPink, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "📸 Shop Staters & Live Updates",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
                Text(
                    text = "${staters.size} Active",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // "My Stater / Add Stater" button for Super Admin or Laundry Admin
                if (currentRole == UserRole.SUPER_ADMIN || currentRole == UserRole.LAUNDRY_ADMIN) {
                    item {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { onAddStaterClick() }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(62.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryPink.copy(alpha = 0.1f))
                                    .border(2.dp, PrimaryPink, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Add,
                                    contentDescription = "Add Stater",
                                    tint = PrimaryPink,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "My Stater",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryPink
                            )
                        }
                    }
                }

                items(staters) { stater ->
                    val isSuperAdminStater = stater.authorRole == UserRole.SUPER_ADMIN
                    val ringColor = if (isSuperAdminStater) PrimaryBlue else PrimaryPink

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(68.dp)
                            .clickable { onStaterClick(stater) }
                    ) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(stater.mediaUrl)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = stater.caption,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(62.dp)
                                    .clip(CircleShape)
                                    .border(2.5.dp, ringColor, CircleShape)
                            )

                            if (stater.isVideo) {
                                Surface(
                                    shape = CircleShape,
                                    color = PrimaryPink,
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Icon(
                                        Icons.Default.PlayArrow,
                                        contentDescription = "Video",
                                        tint = Color.White,
                                        modifier = Modifier.padding(2.dp)
                                    )
                                }
                            } else if (isSuperAdminStater) {
                                Surface(
                                    shape = CircleShape,
                                    color = PrimaryBlue,
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Verified,
                                        contentDescription = "Super Admin",
                                        tint = Color.White,
                                        modifier = Modifier.padding(2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stater.authorName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StaterViewerDialog(
    stater: StaterUpdate,
    currentUserRole: UserRole,
    currentUserPhone: String,
    onDeleteStater: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.95f),
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        confirmButton = {},
        dismissButton = {},
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black)
            ) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = if (stater.authorRole == UserRole.SUPER_ADMIN) PrimaryBlue else PrimaryPink) {
                            Icon(
                                if (stater.authorRole == UserRole.SUPER_ADMIN) Icons.Default.AdminPanelSettings else Icons.Default.Storefront,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier
                                    .padding(6.dp)
                                    .size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(stater.authorName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                if (stater.authorRole == UserRole.SUPER_ADMIN) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("• SUPER ADMIN", color = PrimaryBlue, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                }
                            }
                            Text(
                                if (stater.isVideo) "📹 Live Video Stater Update" else "📸 Photo Stater Update",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row {
                        if (currentUserRole == UserRole.SUPER_ADMIN || stater.authorPhone == currentUserPhone) {
                            IconButton(onClick = {
                                onDeleteStater(stater.id)
                                onDismiss()
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }

                // Media Preview
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .background(Color.DarkGray),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(stater.mediaUrl)
                            .crossfade(true)
                            .build(),
                        contentDescription = stater.caption,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    if (stater.isVideo) {
                        Surface(
                            shape = CircleShape,
                            color = Color.Black.copy(alpha = 0.6f),
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.PlayArrow,
                                    contentDescription = "Playing Stater Video",
                                    tint = Color.White,
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        }
                    }
                }

                // Caption Footer
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black)
                        .padding(16.dp)
                ) {
                    if (stater.caption.isNotBlank()) {
                        Text(
                            text = stater.caption,
                            color = Color.White,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AccentGreen
                        ) {
                            Text(
                                text = "🟢 ACTIVE STATER",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Done", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun AddStaterDialog(
    authorName: String,
    authorPhone: String,
    authorRole: UserRole,
    shopId: String?,
    shopName: String?,
    onPostStater: (mediaUrl: String, isVideo: Boolean, caption: String) -> Unit,
    onDismiss: () -> Unit
) {
    var isVideoType by remember { mutableStateOf(false) }
    var mediaUrlInput by remember {
        mutableStateOf(
            if (isVideoType) "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=800"
            else "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?q=80&w=800"
        )
    }
    var captionInput by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VideoCall, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Post New Stater Update", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Select Stater Type:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !isVideoType,
                        onClick = {
                            isVideoType = false
                            mediaUrlInput = "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?q=80&w=800"
                        },
                        leadingIcon = { Icon(Icons.Default.Photo, contentDescription = null) },
                        label = { Text("📷 Photo Stater") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPink, selectedLabelColor = Color.White)
                    )
                    FilterChip(
                        selected = isVideoType,
                        onClick = {
                            isVideoType = true
                            mediaUrlInput = "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=800"
                        },
                        leadingIcon = { Icon(Icons.Default.Videocam, contentDescription = null) },
                        label = { Text("📹 Video Stater") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPink, selectedLabelColor = Color.White)
                    )
                }

                OutlinedTextField(
                    value = mediaUrlInput,
                    onValueChange = { mediaUrlInput = it },
                    label = { Text(if (isVideoType) "Video Thumbnail / Stream URL" else "Photo Stater Image URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = captionInput,
                    onValueChange = { captionInput = it },
                    label = { Text("Stater Caption / Shop Announcement") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Stater Preview:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Gray)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(mediaUrlInput)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        if (isVideoType) {
                            Surface(shape = CircleShape, color = Color.Black.copy(alpha = 0.6f), modifier = Modifier.size(44.dp)) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.padding(8.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onPostStater(mediaUrlInput, isVideoType, captionInput)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
            ) {
                Text("Publish Stater", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
