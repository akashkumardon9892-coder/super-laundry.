package com.example.ui.screens.laundryadmin

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AiViewModel
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LaundryAdminMainScreen(
    mainViewModel: MainViewModel,
    aiViewModel: AiViewModel,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shops by mainViewModel.allShops.collectAsState()
    val orders by mainViewModel.allOrders.collectAsState()
    val subscriptions by mainViewModel.allSubscriptions.collectAsState()
    val staters by mainViewModel.allStaters.collectAsState()

    val myShop = shops.firstOrNull { it.id == "shop_1" } ?: shops.firstOrNull()
    val myRateCard by mainViewModel.getRateCardForShop(myShop?.id ?: "shop_1").collectAsState(initial = emptyList())
    val myOrders by mainViewModel.getOrdersForShop(myShop?.id ?: "shop_1").collectAsState(initial = emptyList())
    val mySubscription = subscriptions.firstOrNull { it.shopId == myShop?.id }

    var selectedOrderTab by remember { mutableStateOf("New Orders") }
    var selectedCategoryFilter by remember { mutableStateOf<ServiceCategory?>(null) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showSubscriptionSheet by remember { mutableStateOf(false) }
    var showAiSupportSheet by remember { mutableStateOf(false) }
    var showSupportCallDialog by remember { mutableStateOf(false) }
    var showAddStaterDialog by remember { mutableStateOf(false) }
    var activeViewerStater by remember { mutableStateOf<StaterUpdate?>(null) }
    var callingCustomer by remember { mutableStateOf<Pair<String, String>?>(null) }
    var selectedCustomerForHistory by remember { mutableStateOf<Order?>(null) }
    var editingCustomerProfile by remember { mutableStateOf<Order?>(null) }
    var showCustomerChatSheet by remember { mutableStateOf<Order?>(null) }
    var customerChatInput by remember { mutableStateOf("") }
    var customerChatMessages by remember { mutableStateOf(listOf("Admin: Hello! Your order is being processed with care.", "Customer: Thank you! Please iron the formal shirts carefully.")) }

    var showEditPriceModal by remember { mutableStateOf<RateCardItem?>(null) }
    var newPriceInput by remember { mutableStateOf("") }
    var editItemNameInput by remember { mutableStateOf("") }
    var editItemPhotoInput by remember { mutableStateOf("") }
    var newItemPhotoInput by remember { mutableStateOf("https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80") }

    LaunchedEffect(showEditPriceModal) {
        showEditPriceModal?.let {
            newPriceInput = it.price.toInt().toString()
            editItemNameInput = it.clothName
            editItemPhotoInput = it.photoUrl
        }
    }

    val itemGalleryLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            editItemPhotoInput = uri.toString()
            newItemPhotoInput = uri.toString()
        }
    }

    val itemCameraLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            val sampleCameraPhoto = "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=600&q=80"
            editItemPhotoInput = sampleCameraPhoto
            newItemPhotoInput = sampleCameraPhoto
        }
    }

    var showAddNewItemSheet by remember { mutableStateOf(false) }
    var newItemNameInput by remember { mutableStateOf("") }
    var newItemCategoryInput by remember { mutableStateOf(ServiceCategory.IRONING) }
    var newItemPriceInput by remember { mutableStateOf("") }
    var aiQueryInput by remember { mutableStateOf("") }

    // Interactive Settings State Dialogs
    var showLogoBannerDialog by remember { mutableStateOf(false) }
    var showProfileDetailsDialog by remember { mutableStateOf(false) }
    var showTimingAreaDialog by remember { mutableStateOf(false) }
    var showOffersDialog by remember { mutableStateOf(false) }
    var showSecurityDialog by remember { mutableStateOf(false) }
    var showLanguageThemeDialog by remember { mutableStateOf(false) }
    var showAiAdvancedSettingsDialog by remember { mutableStateOf(false) }
    var settingsToastMessage by remember { mutableStateOf<String?>(null) }

    val aiUiAction by aiViewModel.uiActionTrigger.collectAsState()
    LaunchedEffect(aiUiAction) {
        when (aiUiAction) {
            is com.example.ui.viewmodel.AiUiAction.OpenSettings -> {
                showSettingsSheet = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenSubscriptionManager -> {
                showSettingsSheet = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenLanguageSelector -> {
                showLanguageThemeDialog = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenAiVoiceSettings -> {
                showAiAdvancedSettingsDialog = true
                aiViewModel.clearUiAction()
            }
            else -> {}
        }
    }

    var editShopNameInput by remember { mutableStateOf("") }
    var editShopPhoneInput by remember { mutableStateOf("") }
    var editShopAddressInput by remember { mutableStateOf("") }
    var editShopDescInput by remember { mutableStateOf("") }
    var editShopLogoInput by remember { mutableStateOf("") }
    var editShopBannerInput by remember { mutableStateOf("") }
    var editShopTimingInput by remember { mutableStateOf("") }
    var editShopRadiusInput by remember { mutableStateOf("") }
    var editShopIsOpenInput by remember { mutableStateOf(true) }

    val chatMessages by aiViewModel.chatMessages.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(myShop?.name ?: "Express Laundry", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                        Text("Verified Shop • Active", style = MaterialTheme.typography.labelSmall, color = Color.Black.copy(alpha = 0.7f))
                    }
                },
                actions = {
                    // Single Unified AI & Operations Support Button
                    Surface(
                        onClick = { showAiSupportSheet = true },
                        shape = RoundedCornerShape(20.dp),
                        color = PrimaryBlue,
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .testTag("laundry_top_ai_support_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.SupportAgent, contentDescription = "Support Center", tint = Color.White, modifier = Modifier.size(18.dp))
                            Text("Support Center", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    IconButton(onClick = { showSettingsSheet = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.Black)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 100% Free Lifetime Access Banner
                item {
                    Surface(
                        onClick = { showSubscriptionSheet = true },
                        shape = RoundedCornerShape(20.dp),
                        color = AccentGreen.copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AccentGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AccentGreen)
                                Column {
                                    Text("100% Free Lifetime App Access", fontWeight = FontWeight.Bold, color = AccentGreen)
                                    Text("No trial period, expiration, or forced subscription fee!", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            OutlinedButton(
                                onClick = { showSubscriptionSheet = true },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentGreen)
                            ) {
                                Text("Plans Info")
                            }
                        }
                    }
                }

                // AI Namaste Super Laundry Greeting Banner
                item {
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryBlue.copy(alpha = 0.25f)),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryBlue.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🙏", fontSize = 24.sp)
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Namaste, Super Laundry!",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Black,
                                    color = Color.Black
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Wishing you a wonderful, happy, and prosperous day ahead! Super Laundry AI is live and ready to assist your operations.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.Black.copy(alpha = 0.75f)
                                )
                            }
                        }
                    }
                }

                // Laundry Admin & Super Admin Staters / Video Updates Carousel
                item {
                    StaterStoryBar(
                        staters = staters,
                        currentRole = UserRole.LAUNDRY_ADMIN,
                        currentUserPhone = myShop?.ownerPhone ?: "",
                        onAddStaterClick = { showAddStaterDialog = true },
                        onStaterClick = { selectedStater -> activeViewerStater = selectedStater }
                    )
                }

                // Shop Header Card with Store Banner, Store Logo, and Store Profile Status
                item {
                    Surface(
                        shape = RoundedCornerShape(28.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            // Store Banner Image
                            Box(modifier = Modifier.fillMaxWidth().height(140.dp)) {
                                AsyncImage(
                                    model = myShop?.bannerUrl ?: "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=1000",
                                    contentDescription = "Store Banner",
                                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                // Store Logo Overlay
                                Surface(
                                    shape = CircleShape,
                                    shadowElevation = 4.dp,
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(start = 16.dp, bottom = 10.dp)
                                        .size(56.dp)
                                ) {
                                    AsyncImage(
                                        model = myShop?.logoUrl ?: "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?q=80&w=300",
                                        contentDescription = "Store Logo",
                                        modifier = Modifier.fillMaxSize().clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }

                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = myShop?.name ?: "Express Laundry",
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Default.Star, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(16.dp))
                                            Text("${myShop?.rating ?: 4.9} • Verified Laundry Store", style = MaterialTheme.typography.bodyMedium, color = Color.Black.copy(alpha = 0.7f))
                                        }
                                    }

                                    // Store Profile Status Badge
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (myShop?.isOpen == true) AccentGreen else Color.Red
                                    ) {
                                        Text(
                                            text = if (myShop?.isOpen == true) "🟢 STORE OPEN" else "🔴 STORE CLOSED",
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text("🕒 Shop Hours: ${myShop?.shopTiming ?: "8:00 AM - 9:00 PM"}", style = MaterialTheme.typography.bodySmall, color = Color.Gray, fontWeight = FontWeight.Medium)

                            Spacer(modifier = Modifier.height(14.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(10.dp))

                            // Single Unified Quick Support & Communication Bar
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { showAiSupportSheet = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Icon(Icons.Default.SupportAgent, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("24/7 Operations Support", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                if (myOrders.isNotEmpty()) {
                                    OutlinedButton(
                                        onClick = { showCustomerChatSheet = myOrders.first() },
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Customer Chat", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

                // Order Tabs Switcher
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (selectedOrderTab == "New Orders") PrimaryPink else Color.Transparent)
                                .clickable { selectedOrderTab = "New Orders" }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "New Orders (${myOrders.filter { it.status == OrderStatus.NEW }.size})",
                                color = if (selectedOrderTab == "New Orders") Color.White else Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (selectedOrderTab == "Old Orders") PrimaryPink else Color.Transparent)
                                .clickable { selectedOrderTab = "Old Orders" }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "Old Orders (${myOrders.filter { it.status != OrderStatus.NEW }.size})",
                                color = if (selectedOrderTab == "Old Orders") Color.White else Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Active Orders List with Call Customer & Customer Chat options
                val filteredOrders = if (selectedOrderTab == "New Orders") {
                    myOrders.filter { it.status == OrderStatus.NEW }
                } else {
                    myOrders.filter { it.status != OrderStatus.NEW }
                }

                items(filteredOrders) { order ->
                    SleekOrderCard(
                        order = order,
                        onClick = { selectedCustomerForHistory = order },
                        onStatusChange = { newStatus ->
                            mainViewModel.updateOrderStatus(order.id, newStatus)
                        },
                        onCallCustomer = { name, phone ->
                            callingCustomer = name to phone
                        },
                        onChatCustomer = { ord ->
                            showCustomerChatSheet = ord
                        },
                        onViewHistory = { ord ->
                            selectedCustomerForHistory = ord
                        }
                    )
                }

                // Interactive Laundry Quick Calculator Component
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Laundry Billing Calculator",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LaundryQuickCalculatorCard(
                        onSendAiInvoice = { items, rate, total ->
                            aiViewModel.processQuery(
                                userQuery = "Generate draft invoice for $items pieces at ₹$rate per unit. Calculated total: ₹$total",
                                userRole = UserRole.LAUNDRY_ADMIN,
                                userPhone = myShop?.phone ?: "+91 9876543210",
                                userName = myShop?.name ?: "Laundry Admin"
                            )
                            showAiSupportSheet = true
                        }
                    )
                }

                // Rate Card Header & Category Filter Tabs
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Rate Card Management",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                                Text(
                                    text = "Manage rates for Iron, Steam Press, and Dry Clean separately.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Gray
                                )
                            }
                            Button(
                                onClick = { showAddNewItemSheet = true },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Cloth", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Category Filter Row
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(vertical = 4.dp)
                        ) {
                            Surface(
                                onClick = { selectedCategoryFilter = null },
                                shape = RoundedCornerShape(12.dp),
                                color = if (selectedCategoryFilter == null) PrimaryBlue else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "All Categories (${myRateCard.size})",
                                    color = if (selectedCategoryFilter == null) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                            ServiceCategory.values().forEach { cat ->
                                val catCount = myRateCard.count { it.category == cat }
                                Surface(
                                    onClick = { selectedCategoryFilter = cat },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (selectedCategoryFilter == cat) PrimaryBlue else MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Text(
                                        text = "${cat.displayName} ($catCount)",
                                        color = if (selectedCategoryFilter == cat) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                val filteredAdminRateCard = if (selectedCategoryFilter == null) myRateCard else myRateCard.filter { it.category == selectedCategoryFilter }

                items(filteredAdminRateCard, key = { it.id }) { item ->
                    SleekRateCardItemView(
                        item = item,
                        onEditClick = {
                            showEditPriceModal = item
                            newPriceInput = item.price.toInt().toString()
                        },
                        onDeleteClick = {
                            mainViewModel.deleteRateCardItem(item.id)
                        }
                    )
                }
            }
        }
    }

    // Support Call Modal Dialog
    if (showSupportCallDialog) {
        AlertDialog(
            onDismissRequest = { showSupportCallDialog = false },
            icon = { Icon(Icons.Default.SupportAgent, contentDescription = null, tint = PrimaryPink, modifier = Modifier.size(36.dp)) },
            title = { Text("Laundry Admin Support Call", color = Color.Black, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Instant contact options for Laundry Shop Operations & Super Admin:", style = MaterialTheme.typography.bodyMedium, color = Color.Black.copy(alpha = 0.8f))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showSupportCallDialog = false }
                    ) {
                        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = PrimaryPink)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Call Operations Manager", fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("+91 99999 00000 (Toll Free Hotline)", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.6f))
                            }
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showSupportCallDialog = false
                                showAiSupportSheet = true
                            }
                    ) {
                        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SupportAgent, contentDescription = null, tint = PrimaryBlue)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Request AI Operations Callback", fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("AI Assistant will log urgent ticket & notify team", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.6f))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSupportCallDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)) {
                    Text("Close", color = Color.White)
                }
            }
        )
    }

    // Call Customer Dialog
    if (callingCustomer != null) {
        val (custName, custPhone) = callingCustomer!!
        AlertDialog(
            onDismissRequest = { callingCustomer = null },
            icon = { Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = PrimaryPink, modifier = Modifier.size(36.dp)) },
            title = { Text("Call Customer: $custName", color = Color.Black, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Phone Number: $custPhone", style = MaterialTheme.typography.titleMedium, color = PrimaryPink, fontWeight = FontWeight.Bold)
                    Text("Choose call or message action below:", style = MaterialTheme.typography.bodyMedium, color = Color.Black.copy(alpha = 0.7f))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { callingCustomer = null }
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = PrimaryPink)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Start Phone Call (+91 $custPhone)", fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { callingCustomer = null }
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Sms, contentDescription = null, tint = AccentGreen)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Send Order Ready WhatsApp SMS", fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { callingCustomer = null }, colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)) {
                    Text("Close Call", color = Color.White)
                }
            }
        )
    }

    // Customer Detailed Profile & Order History Sheet
    if (selectedCustomerForHistory != null) {
        val ord = selectedCustomerForHistory!!
        ModalBottomSheet(
            onDismissRequest = { selectedCustomerForHistory = null },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    val isLongTerm = ord.isLongTermOrder || ord.itemsSummary.contains("Long-Term", ignoreCase = true)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(ord.customerName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.Black)
                                    if (isLongTerm) {
                                        Surface(shape = RoundedCornerShape(6.dp), color = PrimaryPink) {
                                            Text("★ LONG-TERM SUBSCRIBER", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                                Text("Phone: ${ord.customerPhone} • ${ord.deliveryAddress}", style = MaterialTheme.typography.bodyMedium, color = Color.Black.copy(alpha = 0.7f))
                            }
                            IconButton(onClick = { selectedCustomerForHistory = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                            }
                        }
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                editingCustomerProfile = ord
                                selectedCustomerForHistory = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit Profile Data", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                callingCustomer = ord.customerName to ord.customerPhone
                                selectedCustomerForHistory = null
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = PrimaryPink, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call", color = PrimaryPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                showCustomerChatSheet = ord
                                selectedCustomerForHistory = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Chat", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                item {
                    Text("Previous Order History & Itemized Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                }

                // All orders for this customer
                val customerAllOrders = myOrders.filter { it.customerPhone == ord.customerPhone || it.customerName == ord.customerName }
                val pastList = if (customerAllOrders.isNotEmpty()) customerAllOrders else listOf(ord)

                items(pastList) { pastOrder ->
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Order #${pastOrder.orderNumber}", fontWeight = FontWeight.Bold, color = Color.Black)
                                SleekStatusBadge(status = pastOrder.status)
                            }

                            Text("Date: ${pastOrder.createdAt}", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.6f))

                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                            Text("Items Ordered:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryBlue)
                            Text("• ${pastOrder.itemsSummary}", style = MaterialTheme.typography.bodyMedium, color = Color.Black)

                            Spacer(modifier = Modifier.height(4.dp))

                            Text("Items NOT Ordered / Excluded:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AccentOrange)
                            Text("• Heavy Woolen Blankets (Not requested)", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.7f))
                            Text("• Stain Removal Express Polish (Excluded by user)", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.7f))

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total Amount Paid:", fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("₹${pastOrder.totalPrice.toInt()}", fontWeight = FontWeight.Black, color = PrimaryPink)
                            }
                        }
                    }
                }
            }
        }
    }

    // Customer Live Direct Chat Sheet
    if (showCustomerChatSheet != null) {
        val custOrd = showCustomerChatSheet!!
        val dbChatMessages by mainViewModel.getChatMessages(custOrd.id).collectAsState(initial = emptyList())

        ModalBottomSheet(
            onDismissRequest = { showCustomerChatSheet = null },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(540.dp)
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Chat with ${custOrd.customerName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                        Text("Order #${custOrd.orderNumber} • ${custOrd.customerPhone}", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.6f))
                    }
                    IconButton(onClick = { showCustomerChatSheet = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Chat Messages List from Database
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (dbChatMessages.isEmpty()) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                                Text("No messages yet. Send a message to the customer below!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }
                    }
                    items(dbChatMessages) { msg ->
                        val isMe = msg.senderRole == UserRole.LAUNDRY_ADMIN
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = if (isMe) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isMe) PrimaryBlue else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.widthIn(max = 300.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val roleIcon = when (msg.senderRole) {
                                            UserRole.SUPER_ADMIN -> "👑"
                                            UserRole.LAUNDRY_ADMIN -> "🧺"
                                            UserRole.CUSTOMER -> "👤"
                                        }
                                        Text(
                                            text = "$roleIcon ${msg.senderName} (${msg.senderRole.name.replace("_", " ")})",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isMe) Color.White.copy(alpha = 0.9f) else PrimaryBlue
                                        )
                                        IconButton(
                                            onClick = { mainViewModel.deleteChatMessage(msg.id) },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "Delete",
                                                tint = if (isMe) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "➡️ To: ${msg.recipientName} • 🔒 Private Chat",
                                        fontSize = 10.sp,
                                        color = if (isMe) Color.White.copy(alpha = 0.75f) else Color.Gray,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = msg.messageText,
                                        color = if (isMe) Color.White else Color.Black,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Message Preset Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AssistChip(
                        onClick = {
                            mainViewModel.sendChatMessage(
                                orderId = custOrd.id,
                                senderRole = UserRole.LAUNDRY_ADMIN,
                                senderName = "Laundry Admin (${myShop?.name ?: "Shop"})",
                                text = "Your clothes are washed & ready for pickup!",
                                recipientRole = UserRole.CUSTOMER,
                                recipientName = custOrd.customerName
                            )
                        },
                        label = { Text("Ready Chip", fontSize = 11.sp) }
                    )
                    AssistChip(
                        onClick = {
                            mainViewModel.sendChatMessage(
                                orderId = custOrd.id,
                                senderRole = UserRole.LAUNDRY_ADMIN,
                                senderName = "Laundry Admin (${myShop?.name ?: "Shop"})",
                                text = "Delivery agent is on the way with your laundry!",
                                recipientRole = UserRole.CUSTOMER,
                                recipientName = custOrd.customerName
                            )
                        },
                        label = { Text("Delivery Chip", fontSize = 11.sp) }
                    )
                    AssistChip(
                        onClick = {
                            mainViewModel.sendChatMessage(
                                orderId = custOrd.id,
                                senderRole = UserRole.LAUNDRY_ADMIN,
                                senderName = "Laundry Admin (${myShop?.name ?: "Shop"})",
                                text = "Hello! Your laundry processing has started.",
                                recipientRole = UserRole.CUSTOMER,
                                recipientName = custOrd.customerName
                            )
                        },
                        label = { Text("Processing Started", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Input bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = customerChatInput,
                        onValueChange = { customerChatInput = it },
                        placeholder = { Text("Type message to customer...") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true
                    )
                    IconButton(
                        onClick = {
                            if (customerChatInput.isNotBlank()) {
                                mainViewModel.sendChatMessage(
                                    orderId = custOrd.id,
                                    senderRole = UserRole.LAUNDRY_ADMIN,
                                    senderName = "Laundry Admin (${myShop?.name ?: "Shop"})",
                                    text = customerChatInput.trim(),
                                    recipientRole = UserRole.CUSTOMER,
                                    recipientName = custOrd.customerName
                                )
                                customerChatInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(PrimaryBlue)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    }

    // AI Support Modal Sheet (Text Only - No Image Avatar Bubbles)
    if (showAiSupportSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAiSupportSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(560.dp)
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(PrimaryPink),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.SupportAgent, contentDescription = null, tint = Color.White)
                        }
                        Column {
                            Text("Akash (Operations Support Manager)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                            Text("Senior Support Executive • Rate Card, Orders & Billing", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.6f))
                        }
                    }
                    IconButton(onClick = { showAiSupportSheet = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Chat Messages (Pure Text Bubbles - With Voice Speak Icon)
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(chatMessages) { msg ->
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = if (msg.isUser) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Row(
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(
                                        topStart = 18.dp,
                                        topEnd = 18.dp,
                                        bottomStart = if (msg.isUser) 18.dp else 4.dp,
                                        bottomEnd = if (msg.isUser) 4.dp else 18.dp
                                    ),
                                    color = if (msg.isUser) PrimaryPink else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.widthIn(max = 280.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(
                                            text = msg.text,
                                            color = if (msg.isUser) Color.White else Color.Black,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Prompt Input (Text Only)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = aiQueryInput,
                        onValueChange = { aiQueryInput = it },
                        placeholder = { Text("Ask AI support (text)...") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    IconButton(
                        onClick = {
                            if (aiQueryInput.isNotBlank()) {
                                aiViewModel.processQuery(
                                    userQuery = aiQueryInput,
                                    userRole = UserRole.LAUNDRY_ADMIN,
                                    userPhone = myShop?.phone ?: "+91 9876543210",
                                    userName = myShop?.name ?: "Laundry Admin"
                                )
                                aiQueryInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(PrimaryPink)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    }

    // Settings Modal Sheet
    if (showSettingsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSettingsSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text("Laundry Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.Black)
                }

                val settingsItems = listOf(
                    "Profile & Shop Details",
                    "Rate Card Manager",
                    "Offers & Combo Pricing",
                    "Language Selection (Disabled in Edit - Managed by Platform)",
                    "Notifications & Alerts",
                    "Security",
                    "Shop Timing & Service Area"
                )

                items(settingsItems) { setting ->
                    Surface(
                        onClick = {
                            when {
                                setting.contains("Logo") -> {
                                    showLogoBannerDialog = true
                                }
                                setting.contains("Profile") -> {
                                    showProfileDetailsDialog = true
                                }
                                setting.contains("AI Persona") -> {
                                    showAiAdvancedSettingsDialog = true
                                }
                                setting.contains("Timing") -> {
                                    editShopTimingInput = myShop?.shopTiming ?: "8:00 AM - 9:00 PM"
                                    editShopRadiusInput = (myShop?.serviceAreaRadiusKm ?: 5.0).toString()
                                    editShopIsOpenInput = myShop?.isOpen ?: true
                                    showTimingAreaDialog = true
                                }
                                setting.contains("Offers") || setting.contains("Advertisements") -> {
                                    showOffersDialog = true
                                }
                                setting.contains("Security") -> {
                                    showSecurityDialog = true
                                }
                                setting.contains("Notifications") -> {
                                    settingsToastMessage = "🔔 Laundry Admin Notifications enabled for new orders, customer chats, and revenue!"
                                }
                                setting.contains("Language") -> {
                                    settingsToastMessage = "🌐 Language selection in edit settings is currently disabled for now. It can be enabled by the Platform Admin."
                                }
                                setting.contains("Rate Card") -> {
                                    showSettingsSheet = false
                                }
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(setting, fontWeight = FontWeight.SemiBold, color = Color.Black)
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Black.copy(alpha = 0.6f))
                        }
                    }
                }

                item {
                    OutlinedButton(
                        onClick = {
                            showSettingsSheet = false
                            onLogout()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Logout Shop Admin", color = AccentRose)
                    }
                }
            }
        }
    }

    // Interactive Dialog: Logo, Gallery & Banner Settings
    if (showLogoBannerDialog) {
        AlertDialog(
            onDismissRequest = { showLogoBannerDialog = false },
            title = { Text("📷 Logo & Banner Settings", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Update store logo and banner image URL:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                    OutlinedTextField(
                        value = editShopLogoInput,
                        onValueChange = { editShopLogoInput = it },
                        label = { Text("Logo Image URL") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Text("Quick Logo Presets:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                    ) {
                        val logoPresets = listOf(
                            "Modern Wash" to "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=300&q=80",
                            "Royal Dry" to "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?auto=format&fit=crop&w=300&q=80",
                            "Express Steam" to "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=300&q=80",
                            "Eco Clean" to "https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=300&q=80"
                        )
                        logoPresets.forEach { (label, url) ->
                            FilterChip(
                                selected = editShopLogoInput == url,
                                onClick = { editShopLogoInput = url },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedTextField(
                        value = editShopBannerInput,
                        onValueChange = { editShopBannerInput = it },
                        label = { Text("Banner Image URL") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Text("Quick Banner Presets:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                    ) {
                        val bannerPresets = listOf(
                            "Laundry Hub" to "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=800&q=80",
                            "Washing Machine" to "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?auto=format&fit=crop&w=800&q=80",
                            "Steam Station" to "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=800&q=80",
                            "Dry Cleaning" to "https://images.unsplash.com/photo-1521656693074-0ef32e80a5d5?auto=format&fit=crop&w=800&q=80"
                        )
                        bannerPresets.forEach { (label, url) ->
                            FilterChip(
                                selected = editShopBannerInput == url,
                                onClick = { editShopBannerInput = url },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (myShop != null) {
                            val updated = myShop.copy(
                                logoUrl = editShopLogoInput.ifBlank { myShop.logoUrl },
                                bannerUrl = editShopBannerInput.ifBlank { myShop.bannerUrl }
                            )
                            mainViewModel.updateShopDetails(updated)
                            mainViewModel.updateAppBranding(
                                name = myShop.name,
                                logoUrl = editShopLogoInput.ifBlank { myShop.logoUrl },
                                backgroundUrl = editShopBannerInput.ifBlank { myShop.bannerUrl }
                            )
                            settingsToastMessage = "✅ Logo & Banner saved successfully!"
                        }
                        showLogoBannerDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Save Logo & Banner", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoBannerDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Interactive Dialog: Profile & Shop Details
    if (showProfileDetailsDialog) {
        AlertDialog(
            onDismissRequest = { showProfileDetailsDialog = false },
            title = { Text("🏪 Profile & Shop Details", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editShopNameInput,
                        onValueChange = { editShopNameInput = it },
                        label = { Text("Shop Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editShopPhoneInput,
                        onValueChange = { editShopPhoneInput = it },
                        label = { Text("Owner Mobile Number") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editShopAddressInput,
                        onValueChange = { editShopAddressInput = it },
                        label = { Text("Shop Address") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editShopDescInput,
                        onValueChange = { editShopDescInput = it },
                        label = { Text("Shop Tagline / Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (myShop != null && editShopNameInput.isNotBlank()) {
                            val updated = myShop.copy(
                                name = editShopNameInput,
                                phone = editShopPhoneInput,
                                address = editShopAddressInput,
                                description = editShopDescInput
                            )
                            mainViewModel.updateShopDetails(updated)
                            settingsToastMessage = "✅ Shop profile details updated!"
                        }
                        showProfileDetailsDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Save Details", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showProfileDetailsDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Interactive Dialog: Shop Timing & Service Area
    if (showTimingAreaDialog) {
        AlertDialog(
            onDismissRequest = { showTimingAreaDialog = false },
            title = { Text("⏰ Timing & Delivery Radius", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editShopTimingInput,
                        onValueChange = { editShopTimingInput = it },
                        label = { Text("Shop Hours (e.g. 8:00 AM - 9:00 PM)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editShopRadiusInput,
                        onValueChange = { editShopRadiusInput = it },
                        label = { Text("Delivery Radius in KM") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Shop Status (Open for Orders)", fontWeight = FontWeight.Bold)
                        Switch(
                            checked = editShopIsOpenInput,
                            onCheckedChange = { editShopIsOpenInput = it }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (myShop != null) {
                            val radius = editShopRadiusInput.toDoubleOrNull() ?: myShop.serviceAreaRadiusKm
                            val updated = myShop.copy(
                                shopTiming = editShopTimingInput,
                                serviceAreaRadiusKm = radius,
                                isOpen = editShopIsOpenInput
                            )
                            mainViewModel.updateShopDetails(updated)
                            settingsToastMessage = "✅ Shop timing and delivery radius updated!"
                        }
                        showTimingAreaDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Save Timing", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimingAreaDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Interactive Dialog: Edit Offers & Edit Offer Combos
    if (showOffersDialog) {
        var offerSectionTab by remember { mutableStateOf("Offers") } // "Offers" or "Combos"
        var couponCodeInput by remember { mutableStateOf("FLAT20") }
        var couponTitleInput by remember { mutableStateOf("20% OFF on Dry Cleaning") }
        var couponDiscountInput by remember { mutableStateOf("20") }
        var couponMinOrderInput by remember { mutableStateOf("300") }

        var comboTitleInput by remember { mutableStateOf("5 Shirts Steam Press + 2 Trousers Dry Clean Combo") }
        var comboOriginalPriceInput by remember { mutableStateOf("500") }
        var comboCustomPriceInput by remember { mutableStateOf("299") }

        AlertDialog(
            onDismissRequest = { showOffersDialog = false },
            title = {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Sell, contentDescription = null, tint = PrimaryPink)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("🏷️ Edit Offers & Combo Pricing", fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = offerSectionTab == "Offers",
                            onClick = { offerSectionTab = "Offers" },
                            label = { Text("Edit Coupons & Offers") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPink, selectedLabelColor = Color.White)
                        )
                        FilterChip(
                            selected = offerSectionTab == "Combos",
                            onClick = { offerSectionTab = "Combos" },
                            label = { Text("Edit Offer Combos (Custom Price)") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPink, selectedLabelColor = Color.White)
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (offerSectionTab == "Offers") {
                        Text("✏️ Edit & Create Promotional Coupons:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                        
                        OutlinedTextField(
                            value = couponCodeInput,
                            onValueChange = { couponCodeInput = it },
                            label = { Text("Coupon Code (e.g. FLAT20)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = couponTitleInput,
                            onValueChange = { couponTitleInput = it },
                            label = { Text("Offer Headline / Tagline") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = couponDiscountInput,
                                onValueChange = { couponDiscountInput = it },
                                label = { Text("Discount %") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = couponMinOrderInput,
                                onValueChange = { couponMinOrderInput = it },
                                label = { Text("Min Order (₹)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Text("Active Coupons Live Preview:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Surface(shape = RoundedCornerShape(12.dp), color = PrimaryPink.copy(alpha = 0.1f), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("${couponCodeInput.uppercase()} — $couponTitleInput", fontWeight = FontWeight.Bold, color = PrimaryPink)
                                Text("Discount: $couponDiscountInput% OFF • Min Order: ₹$couponMinOrderInput", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                            }
                        }
                    } else {
                        Text("⚡ Edit Offer Combos & Set Custom Price:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                        
                        OutlinedTextField(
                            value = comboTitleInput,
                            onValueChange = { comboTitleInput = it },
                            label = { Text("Combo Offer Name & Items Included") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = comboOriginalPriceInput,
                                onValueChange = { comboOriginalPriceInput = it },
                                label = { Text("Standard Price (₹)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = comboCustomPriceInput,
                                onValueChange = { comboCustomPriceInput = it },
                                label = { Text("Set Custom Offer Price (₹)") },
                                leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, color = PrimaryPink) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Text("Quick Price Presets:", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            listOf("99", "149", "199", "299", "499", "699", "999").forEach { presetAmt ->
                                FilterChip(
                                    selected = comboCustomPriceInput == presetAmt,
                                    onClick = { comboCustomPriceInput = presetAmt },
                                    label = { Text("₹$presetAmt", style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }

                        Surface(shape = RoundedCornerShape(14.dp), color = AccentGreen.copy(alpha = 0.12f), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("🎉 Combo Offer Preview:", fontWeight = FontWeight.Bold, color = AccentGreen, style = MaterialTheme.typography.labelMedium)
                                Text(comboTitleInput, fontWeight = FontWeight.Bold, color = Color.Black)
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("₹$comboCustomPriceInput", fontWeight = FontWeight.Black, color = PrimaryPink, style = MaterialTheme.typography.titleMedium)
                                    Text("₹$comboOriginalPriceInput", style = MaterialTheme.typography.bodySmall, color = Color.Gray, textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
                                    val orig = comboOriginalPriceInput.toDoubleOrNull() ?: 1.0
                                    val cust = comboCustomPriceInput.toDoubleOrNull() ?: 0.0
                                    val savings = if (orig > cust) (((orig - cust) / orig) * 100).toInt() else 0
                                    Text("($savings% OFF)", color = AccentGreen, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (offerSectionTab == "Offers") {
                            settingsToastMessage = "✅ Offer '${couponCodeInput.uppercase()}' updated and published!"
                        } else {
                            settingsToastMessage = "✅ Combo Offer '${comboTitleInput}' updated with custom price ₹$comboCustomPriceInput!"
                        }
                        showOffersDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Save & Apply Pricing", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showOffersDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Interactive Dialog: Security & Admin Contact
    if (showSecurityDialog) {
        AlertDialog(
            onDismissRequest = { showSecurityDialog = false },
            title = { Text("🔒 Security & Access PIN", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Admin Login Phone: ${myShop?.phone ?: "+91 9876543210"}", fontWeight = FontWeight.SemiBold)
                    Text("PIN Protection: Enforced for rate card edits and revenue logs.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        settingsToastMessage = "✅ Security settings verified!"
                        showSecurityDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("OK", color = Color.White)
                }
            }
        )
    }

    if (showLanguageThemeDialog) {
        LanguageThemeDialog(mainViewModel = mainViewModel, aiViewModel = aiViewModel, userRole = UserRole.LAUNDRY_ADMIN, onDismiss = { showLanguageThemeDialog = false })
    }

    if (showAiAdvancedSettingsDialog) {
        AiVoiceSettingsDialog(aiViewModel = aiViewModel, onDismiss = { showAiAdvancedSettingsDialog = false })
    }

    // Settings Feedback Toast / Banner
    if (settingsToastMessage != null) {
        AlertDialog(
            onDismissRequest = { settingsToastMessage = null },
            title = { Text("⚙️ Settings Updated", fontWeight = FontWeight.Bold) },
            text = { Text(settingsToastMessage!!) },
            confirmButton = {
                TextButton(onClick = { settingsToastMessage = null }) {
                    Text("OK", fontWeight = FontWeight.Bold, color = PrimaryPink)
                }
            }
        )
    }

    // Subscription Modal Sheet
    if (showSubscriptionSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSubscriptionSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                val subPlans by mainViewModel.subscriptionPlans.collectAsState()
                Text("Select Subscription Plan", style = MaterialTheme.typography.titleLarge, color = Color.Black, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))

                SubscriptionPlan.values().forEach { plan ->
                    val matchPlan = subPlans.find { it.planId == plan.name }
                    val isFree = matchPlan?.isFree == true
                    val displayPrice = if (isFree) "FREE (₹0)" else "₹${matchPlan?.priceRupees ?: plan.priceRupees}"

                    Surface(
                        onClick = {
                            if (myShop != null) {
                                mainViewModel.renewSubscription(myShop.id, myShop.name, plan)
                                showSubscriptionSheet = false
                            }
                        },
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(plan.title, fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("${plan.durationMonths} Months Duration", style = MaterialTheme.typography.bodyMedium, color = Color.Black.copy(alpha = 0.7f))
                            }
                            Text(displayPrice, fontWeight = FontWeight.Black, color = if (isFree) AccentGreen else PrimaryPink, fontSize = 18.sp)
                        }
                    }
                }
            }
        }
    }

    // Edit Item & Photo Modal (Red Card / Rate Card Item)
    if (showEditPriceModal != null) {
        val presetPhotos = listOf(
            "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80",
            "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&w=200&q=80",
            "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80",
            "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=200&q=80",
            "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=200&q=80",
            "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=200&q=80"
        )

        AlertDialog(
            onDismissRequest = { showEditPriceModal = null },
            title = { Text("✏️ Edit Card Item & Photo", color = Color.Black, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Item Photo Preview with Camera & Gallery Pickers
                    AsyncImage(
                        model = editItemPhotoInput.ifBlank { showEditPriceModal?.photoUrl },
                        contentDescription = "Item Photo",
                        modifier = Modifier
                            .size(100.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(2.dp, PrimaryPink, RoundedCornerShape(16.dp)),
                        contentScale = ContentScale.Crop
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                try { itemCameraLauncher.launch(null) } catch (e: Exception) {
                                    editItemPhotoInput = "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=600&q=80"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoGradientStart),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("📸 Camera", fontSize = 12.sp, color = Color.White)
                        }

                        Button(
                            onClick = {
                                try { itemGalleryLauncher.launch("image/*") } catch (e: Exception) {
                                    editItemPhotoInput = "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=600&q=80"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("🖼️ Gallery", fontSize = 12.sp, color = Color.White)
                        }
                    }

                    Text("Or choose quick photo preset:", fontSize = 11.sp, color = Color.Gray)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    ) {
                        presetPhotos.forEach { photoUrl ->
                            AsyncImage(
                                model = photoUrl,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { editItemPhotoInput = photoUrl },
                                contentScale = ContentScale.Crop
                            )
                        }
                    }

                    OutlinedTextField(
                        value = editItemNameInput,
                        onValueChange = { editItemNameInput = it },
                        label = { Text("Item / Cloth Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newPriceInput,
                        onValueChange = { newPriceInput = it },
                        label = { Text("Price in ₹") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newPrice = newPriceInput.toDoubleOrNull()
                        if (newPrice != null && showEditPriceModal != null) {
                            mainViewModel.updateRateCardItem(
                                showEditPriceModal!!.copy(
                                    clothName = editItemNameInput.ifBlank { showEditPriceModal!!.clothName },
                                    price = newPrice,
                                    photoUrl = editItemPhotoInput.ifBlank { showEditPriceModal!!.photoUrl }
                                )
                            )
                            showEditPriceModal = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("Save Changes", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditPriceModal = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Add New Clothing Item Modal
    if (showAddNewItemSheet) {
        AlertDialog(
            onDismissRequest = { showAddNewItemSheet = false },
            title = {
                Text(
                    text = "➕ Add New Clothing Item",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Enter clothing details for ${myShop?.name ?: "your shop"}:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )

                    OutlinedTextField(
                        value = newItemNameInput,
                        onValueChange = { newItemNameInput = it },
                        label = { Text("Cloth Name (e.g. Saree, Suit, Kurta)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Select Category:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ServiceCategory.values().forEach { cat ->
                            FilterChip(
                                selected = newItemCategoryInput == cat,
                                onClick = { newItemCategoryInput = cat },
                                label = { Text(cat.displayName, fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = newItemPriceInput,
                        onValueChange = { newItemPriceInput = it },
                        label = { Text("Price in ₹") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Select Item Photo Preset:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )

                    val presets = listOf(
                        "Shirt" to "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80",
                        "Pants" to "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=200&q=80",
                        "Saree" to "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80",
                        "Suit" to "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=200&q=80",
                        "Dress" to "https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?auto=format&fit=crop&w=200&q=80",
                        "Blanket" to "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=200&q=80"
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                    ) {
                        presets.forEach { (label, url) ->
                            FilterChip(
                                selected = newItemPhotoInput == url,
                                onClick = { newItemPhotoInput = url },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val priceVal = newItemPriceInput.toDoubleOrNull() ?: 0.0
                        if (newItemNameInput.isNotBlank() && priceVal > 0) {
                            val newItem = RateCardItem(
                                id = "custom_${System.currentTimeMillis()}",
                                shopId = myShop?.id ?: "shop_1",
                                category = newItemCategoryInput,
                                clothName = newItemNameInput.trim(),
                                photoUrl = newItemPhotoInput,
                                price = priceVal
                            )
                            mainViewModel.addRateCardItem(newItem)
                            showAddNewItemSheet = false
                            newItemNameInput = ""
                            newItemPriceInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    enabled = newItemNameInput.isNotBlank() && (newItemPriceInput.toDoubleOrNull() ?: 0.0) > 0
                ) {
                    Text("Add Item Now", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddNewItemSheet = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (editingCustomerProfile != null) {
        val cust = editingCustomerProfile!!
        EditCustomerProfileDialog(
            initialName = cust.customerName,
            initialPhone = cust.customerPhone,
            initialEmail = null,
            initialAddress = cust.deliveryAddress,
            initialIsLongTerm = cust.isLongTermOrder || cust.itemsSummary.contains("Long-Term", ignoreCase = true),
            initialPlanName = if (cust.isLongTermOrder) cust.itemsSummary else null,
            onSave = { name, phone, email, address, isLongTerm, planName ->
                mainViewModel.updateCustomerProfile(
                    phone = phone,
                    name = name,
                    email = email,
                    address = address,
                    isLongTermCustomer = isLongTerm,
                    subscriptionPlanName = planName
                )
                settingsToastMessage = "Updated customer profile for $name!"
                editingCustomerProfile = null
            },
            onDismiss = { editingCustomerProfile = null }
        )
    }

    if (showAddStaterDialog) {
        AddStaterDialog(
            authorName = myShop?.name ?: "Laundry Admin",
            authorPhone = myShop?.ownerPhone ?: "+91 9876543210",
            authorRole = UserRole.LAUNDRY_ADMIN,
            shopId = myShop?.id ?: "shop_1",
            shopName = myShop?.name ?: "Express Laundry",
            onPostStater = { mediaUrl, isVideo, caption ->
                mainViewModel.addStater(
                    authorPhone = myShop?.ownerPhone ?: "+91 9876543210",
                    authorName = myShop?.name ?: "Express Laundry",
                    authorRole = UserRole.LAUNDRY_ADMIN,
                    shopId = myShop?.id ?: "shop_1",
                    shopName = myShop?.name ?: "Express Laundry",
                    mediaUrl = mediaUrl,
                    isVideo = isVideo,
                    caption = caption
                )
                settingsToastMessage = "🚀 Stater status update published to customers & super admin!"
            },
            onDismiss = { showAddStaterDialog = false }
        )
    }

    if (activeViewerStater != null) {
        StaterViewerDialog(
            stater = activeViewerStater!!,
            currentUserRole = UserRole.LAUNDRY_ADMIN,
            currentUserPhone = myShop?.ownerPhone ?: "",
            onDeleteStater = { mainViewModel.deleteStater(it) },
            onDismiss = { activeViewerStater = null }
        )
    }
}
