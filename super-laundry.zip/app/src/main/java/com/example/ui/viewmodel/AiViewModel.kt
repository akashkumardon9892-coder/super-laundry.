package com.example.ui.viewmodel

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.model.SupportTicket
import com.example.data.model.TicketStatus
import com.example.data.model.UserRole
import com.example.data.repository.SuperLaundryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

data class AiChatMessage(
    val id: String = "msg_${System.currentTimeMillis()}",
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionSuggested: String? = null
)

data class AiActivityLogItem(
    val id: String = "log_${System.currentTimeMillis()}",
    val timestamp: Long = System.currentTimeMillis(),
    val module: String,
    val action: String,
    val isBlocked: Boolean = false,
    val reason: String? = null
)

data class PendingSensitiveAction(
    val actionId: String = "act_${System.currentTimeMillis()}",
    val module: String,
    val description: String,
    val details: String
)

sealed class AiUiAction {
    object None : AiUiAction()
    object OpenDashboard : AiUiAction()
    object OpenOrders : AiUiAction()
    object OpenCustomers : AiUiAction()
    object OpenReports : AiUiAction()
    object OpenSettings : AiUiAction()
    object OpenSubscriptionManager : AiUiAction()
    object OpenLanguageSelector : AiUiAction()
    object OpenAiVoiceSettings : AiUiAction()
    object OpenAiControlCenter : AiUiAction()
    object OpenColorSettings : AiUiAction()
    object OpenFutureFeatures : AiUiAction()
    data class SetLanguage(val lang: String) : AiUiAction()
}

class AiViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val repository = SuperLaundryRepository(application)

    private val _uiActionTrigger = MutableStateFlow<AiUiAction>(AiUiAction.None)
    val uiActionTrigger: StateFlow<AiUiAction> = _uiActionTrigger.asStateFlow()

    fun clearUiAction() {
        _uiActionTrigger.value = AiUiAction.None
    }

    private val _chatMessages = MutableStateFlow<List<AiChatMessage>>(
        listOf(
            AiChatMessage(
                isUser = false,
                text = "नमस्ते! मैं आपका सुपर लॉन्ड्री एआई कंट्रोल सेंटर एवं बिजनेस असिस्टेंट हूँ। आप मुझसे रिपोर्ट्स, प्लांस, ऑर्डर्स और सेटिंग्स प्रबंधित करा सकते हैं।"
            )
        )
    )
    val chatMessages: StateFlow<List<AiChatMessage>> = _chatMessages.asStateFlow()

    private val _isVoiceActive = MutableStateFlow(false)
    val isVoiceActive: StateFlow<Boolean> = _isVoiceActive.asStateFlow()

    private val _isVoiceListening = MutableStateFlow(false)
    val isVoiceListening: StateFlow<Boolean> = _isVoiceListening.asStateFlow()

    private val _aiEnabled = MutableStateFlow(true)
    val aiEnabled: StateFlow<Boolean> = _aiEnabled.asStateFlow()

    // AI Voice & Language Control Center Settings
    private val _aiVoiceGender = MutableStateFlow("Female") // "Female", "Male"
    val aiVoiceGender: StateFlow<String> = _aiVoiceGender.asStateFlow()

    private val _aiLanguage = MutableStateFlow("Hindi (हिंदी)") // Default Hindi
    val aiLanguage: StateFlow<String> = _aiLanguage.asStateFlow()

    private val _hindiMode = MutableStateFlow("Pure Hindi (शुद्ध हिंदी)") // "Pure Hindi (शुद्ध हिंदी)", "Simple Hindi (सरल हिंदी)"
    val hindiMode: StateFlow<String> = _hindiMode.asStateFlow()

    private val _aiSpeechRate = MutableStateFlow(1.0f) // 0.8f, 1.0f, 1.25f, 1.5f
    val aiSpeechRate: StateFlow<Float> = _aiSpeechRate.asStateFlow()

    private val _aiVoicePitch = MutableStateFlow(1.2f) // 0.8f to 1.5f
    val aiVoicePitch: StateFlow<Float> = _aiVoicePitch.asStateFlow()

    private val _aiVoiceVolume = MutableStateFlow(1.0f) // 0.5f to 1.0f
    val aiVoiceVolume: StateFlow<Float> = _aiVoiceVolume.asStateFlow()

    private val _textReplyEnabled = MutableStateFlow(true)
    val textReplyEnabled: StateFlow<Boolean> = _textReplyEnabled.asStateFlow()

    private val _voiceReplyEnabled = MutableStateFlow(true)
    val voiceReplyEnabled: StateFlow<Boolean> = _voiceReplyEnabled.asStateFlow()

    private val _aiOperatingMode = MutableStateFlow("Smart Business Assistant")
    val aiOperatingMode: StateFlow<String> = _aiOperatingMode.asStateFlow()

    // AI Permission Manager for Modules (Allow/Deny)
    private val _modulePermissions = MutableStateFlow(
        mapOf(
            "reports" to true,
            "dashboard" to true,
            "orders" to true,
            "customers" to true,
            "laundry_admin" to true,
            "notifications" to true,
            "subscription" to true,
            "analytics" to true,
            "broadcast" to true,
            "support" to true,
            "settings" to true
        )
    )
    val modulePermissions: StateFlow<Map<String, Boolean>> = _modulePermissions.asStateFlow()

    // Sensitive Action Confirmation Safeguard
    private val _pendingSensitiveAction = MutableStateFlow<PendingSensitiveAction?>(null)
    val pendingSensitiveAction: StateFlow<PendingSensitiveAction?> = _pendingSensitiveAction.asStateFlow()

    // AI Activity Log Dashboard
    private val _activityLogs = MutableStateFlow<List<AiActivityLogItem>>(
        listOf(
            AiActivityLogItem(module = "settings", action = "AI Control Center initialized with Hindi Pure Mode."),
            AiActivityLogItem(module = "security", action = "Strict Security Guardrails Active (OTP/Bank details protected).")
        )
    )
    val activityLogs: StateFlow<List<AiActivityLogItem>> = _activityLogs.asStateFlow()

    fun toggleModulePermission(moduleKey: String, allowed: Boolean) {
        val current = _modulePermissions.value.toMutableMap()
        current[moduleKey] = allowed
        _modulePermissions.value = current
        logActivity(moduleKey, "Permission updated to ${if (allowed) "ALLOWED" else "DENIED"}")
    }

    fun setHindiMode(mode: String) {
        _hindiMode.value = mode
        speak(if (mode.contains("Pure")) "शुद्ध हिंदी मोड सक्रिय किया गया।" else "सरल हिंदी मोड सक्रिय किया गया।")
    }

    fun setAiVoicePitch(pitch: Float) {
        _aiVoicePitch.value = pitch
        tts?.setPitch(pitch)
    }

    fun setAiVoiceVolume(volume: Float) {
        _aiVoiceVolume.value = volume
    }

    fun toggleTextReply(enabled: Boolean) {
        _textReplyEnabled.value = enabled
    }

    fun toggleVoiceReply(enabled: Boolean) {
        _voiceReplyEnabled.value = enabled
        if (!enabled) stopSpeaking()
    }

    fun confirmSensitiveAction() {
        val pending = _pendingSensitiveAction.value
        if (pending != null) {
            logActivity(pending.module, "Super Admin CONFIRMED sensitive action: ${pending.description}")
            _chatMessages.value = _chatMessages.value + AiChatMessage(
                isUser = false,
                text = "✅ कार्रवाई सुपर एडमिन द्वारा स्वीकृत (Super Admin Approved): ${pending.description}"
            )
            speak("कार्रवाई सफलतापूर्वक निष्पादित की गई।")
            _pendingSensitiveAction.value = null
        }
    }

    fun cancelSensitiveAction() {
        val pending = _pendingSensitiveAction.value
        if (pending != null) {
            logActivity(pending.module, "Super Admin CANCELLED sensitive action: ${pending.description}", isBlocked = true, reason = "Cancelled by Super Admin")
            _chatMessages.value = _chatMessages.value + AiChatMessage(
                isUser = false,
                text = "❌ कार्रवाई रद्द कर दी गई (Cancelled by Super Admin): ${pending.description}"
            )
            speak("कार्रवाई रद्द कर दी गई है।")
            _pendingSensitiveAction.value = null
        }
    }

    private fun logActivity(module: String, action: String, isBlocked: Boolean = false, reason: String? = null) {
        val item = AiActivityLogItem(
            module = module,
            action = action,
            isBlocked = isBlocked,
            reason = reason
        )
        _activityLogs.value = listOf(item) + _activityLogs.value
    }

    // Text To Speech
    private var tts: TextToSpeech? = null
    private val _isTtsReady = MutableStateFlow(false)
    val isTtsReady: StateFlow<Boolean> = _isTtsReady.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    init {
        try {
            tts = TextToSpeech(application, this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            try {
                tts?.language = Locale("hi", "IN")
                tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }
                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                    }
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                    }
                })
            } catch (e: Exception) {
                tts?.language = Locale.ENGLISH
            }
            _isTtsReady.value = true
        }
    }

    fun setAiVoiceGender(gender: String) {
        _aiVoiceGender.value = gender
        if (gender == "Female") {
            tts?.setPitch(1.3f)
        } else {
            tts?.setPitch(0.85f)
        }
        speak("Voice Persona updated to $gender Voice.")
    }

    fun setAiLanguage(language: String) {
        _aiLanguage.value = language
        if (language.contains("Hindi") || language.contains("हिंदी")) {
            try { tts?.language = Locale("hi", "IN") } catch (e: Exception) { tts?.language = Locale.ENGLISH }
            speak("नमस्ते! भाषा शुद्ध हिंदी में सेट कर दी गई है।")
        } else if (language.contains("Marathi") || language.contains("मराठी")) {
            try { tts?.language = Locale("mr", "IN") } catch (e: Exception) { tts?.language = Locale("hi", "IN") }
            speak("नमस्कार! भाषा मराठी मध्ये सेट केली आहे.")
        } else {
            tts?.language = Locale.ENGLISH
            speak("Language updated to $language.")
        }
    }

    fun setAiSpeechRate(rate: Float) {
        _aiSpeechRate.value = rate
        tts?.setSpeechRate(rate)
        speak("Speech rate set to $rate x.")
    }

    fun setAiOperatingMode(mode: String) {
        _aiOperatingMode.value = mode
        speak("Operating mode set to $mode.")
    }

    fun speak(text: String) {
        if (!_isTtsReady.value || tts == null || text.isBlank()) return
        try {
            val cleanText = text.replace(Regex("[\uD83C-\uDBFF\uDC00-\uDFFF]"), " ")
                .replace(Regex("[#*`_~]"), "")
                .take(300)
            val params = android.os.Bundle()
            params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "ai_utt_${System.currentTimeMillis()}")
            tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, "ai_utt_${System.currentTimeMillis()}")
            _isSpeaking.value = true
        } catch (e: Exception) {
            e.printStackTrace()
            _isSpeaking.value = false
        }
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        _isSpeaking.value = false
    }

    fun toggleAi(enabled: Boolean) {
        _aiEnabled.value = enabled
    }

    fun startVoiceSession() {
        _isVoiceActive.value = true
        _isVoiceListening.value = true
        speak("Super Laundry AI Voice Assistant active. I am listening.")
    }

    fun stopVoiceSession() {
        _isVoiceActive.value = false
        _isVoiceListening.value = false
        stopSpeaking()
    }

    fun processQuery(
        userQuery: String,
        userRole: UserRole,
        userPhone: String,
        userName: String
    ) {
        if (userRole != UserRole.SUPER_ADMIN) {
            val notAllowedMsg = "ℹ️ एआई वॉइस एवं कमांड असिस्टेंट केवल सुपर एडमिन डैशबोर्ड पर उपलब्ध है।"
            _chatMessages.value = _chatMessages.value + AiChatMessage(
                isUser = false,
                text = notAllowedMsg
            )
            return
        }

        if (!_aiEnabled.value) {
            val disabledMsg = "AI Assistant is currently turned OFF by Super Admin."
            _chatMessages.value = _chatMessages.value + AiChatMessage(
                isUser = false,
                text = disabledMsg
            )
            speak(disabledMsg)
            return
        }

        val userMsg = AiChatMessage(isUser = true, text = userQuery)
        _chatMessages.value = _chatMessages.value + userMsg

        viewModelScope.launch {
            val lower = userQuery.lowercase()

            // 1. STRICT SECURITY GUARDRAIL CHECK (NEVER ASK / SHARE OTP, BANK DETAILS, PASSWORDS, ACCOUNTS)
            if (lower.contains("otp") || lower.contains("password") || lower.contains("pin") ||
                lower.contains("cvv") || lower.contains("bank") || lower.contains("account detail") ||
                lower.contains("ifsc") || lower.contains("card detail") || lower.contains("account number") ||
                lower.contains("passcode") || lower.contains("bank detail")
            ) {
                val guardrailMsg = "🛡️ सुरक्षा नीति (Security Policy Guardrail): मैं किसी भी स्थिति में OTP, बैंक खाते का विवरण, पासवर्ड, कार्ड नंबर या निजी खाते की जानकारी न तो मांग सकता हूँ और न ही साझा कर सकता हूँ। आपकी वित्तीय एवं निजी सुरक्षा सर्वोपरि है।"
                _chatMessages.value = _chatMessages.value + AiChatMessage(
                    isUser = false,
                    text = guardrailMsg
                )
                logActivity("security", "Blocked sensitive query attempting to access OTP/Bank/Account details", isBlocked = true, reason = "Strict Security Policy Violation")
                speak(guardrailMsg)
                return@launch
            }

            // 2. CHECK SENSITIVE ACTION MUTATIONS (Require Super Admin Confirmation)
            if (lower.contains("delete") || lower.contains("change price") || lower.contains("modify subscription") || lower.contains("send broadcast") || lower.contains("हटाएं") || lower.contains("दाम बदलें")) {
                _pendingSensitiveAction.value = PendingSensitiveAction(
                    module = if (lower.contains("price")) "subscription" else "system",
                    description = "AI Requested Sensitive Action: $userQuery",
                    details = "Super Admin explicit confirmation required before executing this change."
                )
                val confirmPrompt = "⚠️ पुष्टि आवश्यक है (Confirmation Required): एआई ने एक संवेदनशील बदलाव दर्ज किया है। कृपया नीचे दिए गए कन्फर्मेशन बॉक्स में स्वीकार (Confirm) या अस्वीकार (Cancel) करें।"
                _chatMessages.value = _chatMessages.value + AiChatMessage(
                    isUser = false,
                    text = confirmPrompt
                )
                logActivity("safety", "Triggered Confirmation Dialog for sensitive action: $userQuery")
                speak(confirmPrompt)
                return@launch
            }

            // 3. CHECK MODULE PERMISSION IN MANAGER
            val targetModuleKey = when {
                lower.contains("report") || lower.contains("राजस्व") -> "reports"
                lower.contains("order") || lower.contains("ऑर्डर") -> "orders"
                lower.contains("customer") || lower.contains("ग्राहक") -> "customers"
                lower.contains("laundry") || lower.contains("लॉन्ड्री") -> "laundry_admin"
                lower.contains("subscription") || lower.contains("plan") || lower.contains("प्लांस") -> "subscription"
                lower.contains("broadcast") || lower.contains("notification") -> "broadcast"
                lower.contains("setting") || lower.contains("सेटिंग") -> "settings"
                else -> "dashboard"
            }

            val isAllowed = _modulePermissions.value[targetModuleKey] ?: true
            if (!isAllowed) {
                val deniedMsg = "⚠️ एआई अनुमति प्रतिबंधित (AI Permission Denied): सुपर एडमिन ने 'AI Permission Manager' में '$targetModuleKey' मॉड्यूल के लिए एआई एक्सेस बंद कर दिया है।"
                _chatMessages.value = _chatMessages.value + AiChatMessage(
                    isUser = false,
                    text = deniedMsg
                )
                logActivity(targetModuleKey, "AI query blocked due to module permission setting", isBlocked = true, reason = "Permission Denied by Super Admin")
                speak(deniedMsg)
                return@launch
            }

            var responseText: String? = null
            val geminiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }

            if (geminiKey.isNotBlank() && !geminiKey.startsWith("MY_")) {
                responseText = fetchGeminiResponse(userQuery, userRole, geminiKey)
            }

            if (responseText == null) {
                delay(600)
                responseText = generateIntelligentResponseText(lower, userRole, userPhone, userName)
            }

            val aiResponse = AiChatMessage(isUser = false, text = responseText)
            _chatMessages.value = _chatMessages.value + aiResponse
            logActivity(targetModuleKey, "AI Response generated for query: ${userQuery.take(30)}...")

            // Automatically speak out response if voice reply enabled
            if (_voiceReplyEnabled.value) {
                speak(responseText)
            }
        }
    }

    private suspend fun fetchGeminiResponse(prompt: String, role: UserRole, apiKey: String): String? = withContext(Dispatchers.IO) {
        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"
            val systemContext = "You are Super Laundry AI Assistant for role $role. Keep response concise, helpful, professional, focusing on laundry business operations, pricing, and analytics."

            val jsonBody = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemContext)))
                })
                put("contents", JSONArray().put(
                    JSONObject().apply {
                        put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                    }
                ))
            }

            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val responseStr = response.body?.string() ?: ""
                val jsonRes = JSONObject(responseStr)
                val candidates = jsonRes.optJSONArray("candidates")
                val firstCand = candidates?.optJSONObject(0)
                val content = firstCand?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                val text = parts?.optJSONObject(0)?.optString("text")
                if (!text.isNullOrBlank()) {
                    return@withContext text
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext null
    }

    private suspend fun generateIntelligentResponseText(
        query: String,
        role: UserRole,
        phone: String,
        name: String
    ): String {
        val q = query.lowercase()
        val isHindi = _aiLanguage.value.contains("Hindi") || _aiLanguage.value.contains("हिंदी")
        val isMarathi = _aiLanguage.value.contains("Marathi") || _aiLanguage.value.contains("मराठी")

        return when {
            q.contains("dashboard") || q.contains("डैशबोर्ड") || q.contains("होम") -> {
                _uiActionTrigger.value = AiUiAction.OpenDashboard
                if (isMarathi) "📊 प्लॅटफॉर्म डॅशबोर्ड उघडत आहे!" else if (isHindi) "📊 डैशबोर्ड खोला जा रहा है!" else "📊 Opening Dashboard!"
            }
            q.contains("order") || q.contains("ऑर्डर") -> {
                _uiActionTrigger.value = AiUiAction.OpenOrders
                if (isMarathi) "📦 ऑर्डर्स विभाग उघडत आहे!" else if (isHindi) "📦 ऑर्डर्स सेक्शन खोला जा रहा है!" else "📦 Opening Orders Section!"
            }
            q.contains("customer") || q.contains("ग्राहक") -> {
                _uiActionTrigger.value = AiUiAction.OpenCustomers
                if (isMarathi) "👥 ग्राहक यादी उघडत आहे!" else if (isHindi) "👥 ग्राहक सूची खोली जा रही है!" else "👥 Opening Customer Directory!"
            }
            q.contains("color") || q.contains("रंग") || q.contains("theme") || q.contains("थीम") -> {
                _uiActionTrigger.value = AiUiAction.OpenColorSettings
                if (isMarathi) "🎨 रंग आणि थीम सेटिंग्ज उघडत आहे!" else if (isHindi) "🎨 कलर चेंज एवं थीम सेटिंग्स खोली जा रही हैं!" else "🎨 Opening Color Change & Theme Settings!"
            }
            q.contains("future feature") || q.contains("फीचर") || q.contains("बिल्डर") -> {
                _uiActionTrigger.value = AiUiAction.OpenFutureFeatures
                if (isMarathi) "🔮 भविष्यातील वैशिष्ट्य सेटिंग्ज उघडत आहे!" else if (isHindi) "🔮 फ्यूचर फीचर सेटिंग्स एवं बिल्डर खोला जा रहा है!" else "🔮 Opening Future Feature Settings & Builder!"
            }
            q.contains("hindi में") || q.contains("हिंदी में") || q.contains("हिंदी कर") -> {
                _uiActionTrigger.value = AiUiAction.SetLanguage("Hindi (हिंदी)")
                "🌐 भाषा बदलकर 'हिंदी' कर दी गई है।"
            }
            q.contains("marathi में") || q.contains("मराठी में") || q.contains("मराठी कर") -> {
                _uiActionTrigger.value = AiUiAction.SetLanguage("Marathi (मराठी)")
                "🌐 भाषा बदलून 'मराठी' करण्यात आली आहे."
            }
            q.contains("english में") || q.contains("english कर") -> {
                _uiActionTrigger.value = AiUiAction.SetLanguage("English (IN)")
                "🌐 Language switched to English."
            }
            q.contains("setting") || q.contains("settings") || q.contains(" open app") || q.contains(" app setting") || q.contains("सेटिंग") || q.contains("ऐप खोलो") -> {
                _uiActionTrigger.value = AiUiAction.OpenSettings
                if (isMarathi) "⚙️ ॲप सेटिंग्ज उघडत आहे." else if (isHindi) "⚙️ जी बिल्कुल! मैं आपके लिए सेटिंग्स ऐप और प्रोफ़ाइल नियंत्रण खोल रहा हूँ।" else "⚙️ Opening Settings App and Profile Controls for you right now!"
            }
            q.contains("subscription") || q.contains("plan") || q.contains("amount") || q.contains("tier") || q.contains("rate card") || q.contains("प्लांस") || q.contains("सब्सक्रिप्शन") || q.contains("दाम") || q.contains("पैसा") -> {
                _uiActionTrigger.value = AiUiAction.OpenSubscriptionManager
                if (isMarathi) "💳 सदस्यत्व योजना व्यवस्थापक उघडत आहे." else if (isHindi) "💳 जी सुपर एडमिन! सदस्यता योजना प्रबंधक खोला गया है। यहाँ से आप 0 रुपये, 1 रुपया, 2 रुपये या कोई भी नया दाम तय कर सकते हैं।" else "💳 Opening Subscription Plan Manager! You can choose or edit subscription plans and pricing amounts (Free, ₹1, ₹2, or custom)."
            }
            q.contains("language") || q.contains("bhasha") || q.contains("भाषा") -> {
                _uiActionTrigger.value = AiUiAction.OpenLanguageSelector
                if (isMarathi) "🌐 भाषा निवड उघडत आहे." else if (isHindi) "🌐 ऐप भाषा और थीम विकल्प खोले जा रहे हैं। आप शुद्ध हिंदी, अंग्रेजी या मराठी चुन सकते हैं।" else "🌐 Opening App Language and Day/Night Theme options. Select English, Hindi, or Marathi."
            }
            q.contains("voice") || q.contains("female") || q.contains("male voice") || q.contains("speaker") || q.contains("talk") || q.contains("आवाज") || q.contains("बोल") -> {
                _uiActionTrigger.value = AiUiAction.OpenAiVoiceSettings
                if (isMarathi) "🎙️ एआय व्हॉइस सेटिंग्ज उघडत आहे." else if (isHindi) "🎙️ एआई वॉयस नियंत्रण खोला गया है। आप पुरुष या महिला की आवाज और स्पीड सेट कर सकते हैं।" else "🎙️ Opening AI Persona Voice & Speed Controls. Switch between Female/Male voices, English, Hindi, or Marathi."
            }
            q.contains("revenue") || q.contains("sales") || q.contains("report") || q.contains("earning") || q.contains("कमाई") || q.contains("बिक्री") || q.contains("राजस्व") -> {
                _uiActionTrigger.value = AiUiAction.OpenReports
                if (isMarathi) "📈 आजची एकूण कमाई: ₹14,580\n• सक्रिय दुकाने: 4 सुपर लॉन्ड्री केंद्रे\n• सर्वात जास्त मागणी: स्टीम प्रेसिंग (48%)" else if (isHindi) "📈 प्लेटफॉर्म राजस्व और कुल कमाई की रिपोर्ट:\n• आज की कुल कमाई: ₹14,580\n• सक्रिय स्टोर: 4 सुपर लॉन्ड्री केंद्र\n• सबसे ज्यादा मांग: स्टीम प्रेसिंग (48%)" else "📈 Revenue & Sales Insights:\n• Total Platform Revenue Today: ₹14,580 (+12.4% vs yesterday)\n• Active Laundry Shops: 4 Verified Shops\n• Highest Demand Category: Steam Ironing (48% of total volume)\n• Recommended Action: Run a weekend 20% discount coupon to boost Dry Cleaning volume."
            }
            q.contains("marketing") || q.contains("suggestion") || q.contains("offer") || q.contains("promote") || q.contains("ऑफर") -> {
                if (isHindi) "💡 बिज़नेस बढ़ाने के सुझाव:\n1. त्यौहारों के लिए 'FESTIVE50' कूपन कोड शुरू करें।\n2. व्हाट्सएप ब्रॉडकास्ट संदेश भेजें।" else "💡 Business & Marketing Suggestion:\n1. Launch 'FESTIVE50' promo code for festival season dry cleaning.\n2. Enable 24-Hour Express Steam Iron Guarantee for local tech hubs.\n3. Send WhatsApp broadcast to customers who haven't ordered in 14 days."
            }
            q.contains("invoice") || q.contains("draft invoice") || q.contains("bill") || q.contains("बिल") -> {
                if (isHindi) "📄 रसीद और ड्राफ्ट बिल:\nबिल संख्या #SL-2026-881\nग्राहक: प्रिया शर्मा\nकुल भुगतान राशि: ₹120.00" else "📄 Draft Invoice Generated:\nInvoice #SL-2026-881\nCustomer: Priya Sharma\nItems: Cotton Shirts (x4) @ ₹15 = ₹60, Silk Saree (x1) @ ₹60 = ₹60\nTotal Payable: ₹120.00 (Inclusive of GST)\n[Ready to share via In-App Chat or SMS]"
            }
            query.contains("reminder") || query.contains("schedule") -> {
                "⏰ Reminder Scheduled:\n'Send Subscription Renewal Notification to Royal Dry Cleaners expiring in 5 days.'\nSet for tomorrow at 10:00 AM."
            }
            query.contains("support") || query.contains("ticket") || query.contains("human") || query.contains("escalate") || query.contains("problem") -> {
                val targetRole = if (role == UserRole.LAUNDRY_ADMIN) UserRole.SUPER_ADMIN else UserRole.LAUNDRY_ADMIN
                repository.createSupportTicket(
                    SupportTicket(
                        id = "tick_${System.currentTimeMillis()}",
                        createdByPhone = phone,
                        createdByName = name,
                        userRole = role,
                        targetRole = targetRole,
                        title = "Escalated AI Support Query",
                        description = query,
                        status = TicketStatus.OPEN
                    )
                )
                "🎫 Support Ticket Created!\nI have automatically escalated your query and generated Ticket #SL-TICK-${System.currentTimeMillis().toString().takeLast(4)} for ${targetRole.name.replace("_", " ")}. An admin will contact you shortly."
            }
            query.contains("customer") || query.contains("count") || query.contains("total") -> {
                "👥 Customer Insights:\n• Total Platform Registered Customers: 248 Active Users\n• Direct Super Laundry Customers: 84 Direct Orders\n• Top Area: Indiranagar & HSR Layout\n• Retention Rate: 88.5% Monthly Repeat Rate"
            }
            role == UserRole.LAUNDRY_ADMIN -> {
                if (q.contains("hello") || q.contains("hi") || q.contains("namaste") || q.contains("नमस्ते") || q.contains("आकाश")) {
                    "नमस्ते $name जी! मैं आकाश हूँ (सुपर लॉन्ड्री ऑपरेशन्स मैनेजर)। आपकी दुकान के ऑर्डर, रेट कार्ड या बिलिंग सहायता के लिए बताइए, मैं क्या कर सकता हूँ?"
                } else if (q.contains("rate") || q.contains("price") || q.contains("दाम")) {
                    "जी $name जी, आप सुपर एडमिन ऑपरेशन्स पोर्टल से अपना रेट कार्ड बदल सकते हैं। यदि कोई समस्या हो तो मैं आपकी मदद करूँगा। - आकाश"
                } else {
                    "नमस्ते $name जी! मैं आकाश बोल रहा हूँ ऑपरेशन्स सपोर्ट से। आपका संदेश दर्ज कर लिया गया है। किसी भी सवाल या सहायता के लिए बेझिझक पूछें।"
                }
            }
            else -> {
                if (isHindi) "नमस्ते $name जी! मैं आपकी क्या मदद कर सकता हूँ?" else "Hello $name! How can I assist you with your Super Laundry operations today?"
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
