package com.example.ui.screens.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRole
import com.example.ui.components.VoiceAiWaveVisualizer
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderChatScreen(
    orderId: String,
    mainViewModel: MainViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val messages by mainViewModel.getChatMessages(orderId).collectAsState(initial = emptyList())
    val currentUser by mainViewModel.currentUser.collectAsState()
    val activeRole by mainViewModel.activeRole.collectAsState()

    var messageInput by remember { mutableStateOf("") }
    var showInAppCallSheet by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Order #$orderId", fontWeight = FontWeight.Bold)
                        Text("Direct Customer ↔ Laundry Connect", style = MaterialTheme.typography.labelSmall, color = AccentGreen)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { mainViewModel.clearChatForOrder(orderId) },
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Chat", tint = MaterialTheme.colorScheme.error)
                    }
                    IconButton(
                        onClick = { showInAppCallSheet = true },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clip(CircleShape)
                            .background(AccentGreen)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "Direct Call", tint = Color.White)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val isMe = msg.senderRole == activeRole
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = if (isMe) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = if (isMe) PrimaryBlue else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp)
                            ) {
                                // Chatter Sender & Role Badge
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    val roleIcon = when (msg.senderRole) {
                                        UserRole.SUPER_ADMIN -> "👑"
                                        UserRole.LAUNDRY_ADMIN -> "🧺"
                                        UserRole.CUSTOMER -> "👤"
                                    }
                                    Text(
                                        text = "$roleIcon ${msg.senderName} (${msg.senderRole.name.replace("_", " ")})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isMe) Color.White.copy(alpha = 0.9f) else PrimaryBlue,
                                        fontWeight = FontWeight.Bold
                                    )
                                    IconButton(
                                        onClick = { mainViewModel.deleteChatMessage(msg.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Delete Message",
                                            tint = if (isMe) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                // Recipient Target & Isolation Tag
                                Text(
                                    text = "➡️ To: ${msg.recipientName} • 🔒 Private Chat",
                                    fontSize = 10.sp,
                                    color = if (isMe) Color.White.copy(alpha = 0.75f) else Color.Gray,
                                    fontWeight = FontWeight.Medium
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                // Message Body
                                Text(
                                    text = msg.messageText,
                                    color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }
            }

            // Input Bar
            Surface(
                tonalElevation = 4.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = messageInput,
                        onValueChange = { messageInput = it },
                        placeholder = { Text("Type message for laundry...") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp)
                    )

                    IconButton(
                        onClick = {
                            if (messageInput.isNotBlank()) {
                                mainViewModel.sendChatMessage(
                                    orderId = orderId,
                                    senderRole = activeRole,
                                    senderName = currentUser?.name ?: "User",
                                    text = messageInput
                                )
                                messageInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(PrimaryBlue)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    }

    // In-App Call Modal Sheet
    if (showInAppCallSheet) {
        ModalBottomSheet(
            onDismissRequest = { showInAppCallSheet = false },
            containerColor = SurfaceDark
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Direct Encrypted In-App Call", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Connected with Laundry Admin", style = MaterialTheme.typography.bodyMedium, color = AccentGreen)

                Spacer(modifier = Modifier.height(20.dp))

                VoiceAiWaveVisualizer(isListening = true)

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { showInAppCallSheet = false },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("💬 Switch to Text Chat")
                    }

                    FloatingActionButton(
                        onClick = { showInAppCallSheet = false },
                        containerColor = AccentRose,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier.size(56.dp)
                    ) {
                        Icon(Icons.Default.CallEnd, contentDescription = "End Call")
                    }
                }
            }
        }
    }
}
