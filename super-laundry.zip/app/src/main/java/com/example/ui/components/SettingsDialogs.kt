package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AiViewModel
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageThemeDialog(
    mainViewModel: MainViewModel,
    aiViewModel: AiViewModel,
    userRole: UserRole = UserRole.CUSTOMER,
    onDismiss: () -> Unit
) {
    val roleLang = when (userRole) {
        UserRole.CUSTOMER -> mainViewModel.customerLanguage.collectAsState().value
        UserRole.LAUNDRY_ADMIN -> mainViewModel.laundryAdminLanguage.collectAsState().value
        UserRole.SUPER_ADMIN -> mainViewModel.superAdminLanguage.collectAsState().value
    }
    val currentTheme by mainViewModel.appThemeMode.collectAsState()

    var selectedLanguage by remember { mutableStateOf(roleLang) }
    var selectedTheme by remember { mutableStateOf(currentTheme) }

    val languages = listOf("English (IN)", "Hindi (हिंदी)", "Hinglish", "Tamil (தமிழ்)", "Marathi (मराठी)", "Gujarati (ગુજરાતી)")
    val themes = listOf("Light Mode", "Dark Mode", "Auto Day/Night")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Language, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("App Language & Theme (${userRole.name.replace("_", " ")})", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Select Preferred Dashboard Language:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    languages.forEach { lang ->
                        Surface(
                            onClick = { selectedLanguage = lang },
                            shape = RoundedCornerShape(12.dp),
                            color = if (selectedLanguage == lang) PrimaryPink.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (selectedLanguage == lang) androidx.compose.foundation.BorderStroke(2.dp, PrimaryPink) else null,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(lang, fontWeight = FontWeight.SemiBold, color = Color.Black)
                                RadioButton(
                                    selected = selectedLanguage == lang,
                                    onClick = { selectedLanguage = lang },
                                    colors = RadioButtonDefaults.colors(selectedColor = PrimaryPink)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text("Select Display Theme:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    themes.forEach { theme ->
                        FilterChip(
                            selected = selectedTheme == theme,
                            onClick = { selectedTheme = theme },
                            label = { Text(theme, style = MaterialTheme.typography.bodySmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    mainViewModel.updateAppLanguage(selectedLanguage, userRole)
                    mainViewModel.updateAppThemeMode(selectedTheme)
                    aiViewModel.setAiLanguage(selectedLanguage)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
            ) {
                Text("Save & Apply", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiVoiceSettingsDialog(
    aiViewModel: AiViewModel,
    onDismiss: () -> Unit
) {
    val aiEnabled by aiViewModel.aiEnabled.collectAsState()
    val aiVoiceGender by aiViewModel.aiVoiceGender.collectAsState()
    val aiLanguage by aiViewModel.aiLanguage.collectAsState()
    val hindiMode by aiViewModel.hindiMode.collectAsState()
    val aiSpeechRate by aiViewModel.aiSpeechRate.collectAsState()
    val aiVoicePitch by aiViewModel.aiVoicePitch.collectAsState()
    val aiVoiceVolume by aiViewModel.aiVoiceVolume.collectAsState()
    val textReplyEnabled by aiViewModel.textReplyEnabled.collectAsState()
    val voiceReplyEnabled by aiViewModel.voiceReplyEnabled.collectAsState()
    val aiOperatingMode by aiViewModel.aiOperatingMode.collectAsState()
    val modulePermissions by aiViewModel.modulePermissions.collectAsState()
    val activityLogs by aiViewModel.activityLogs.collectAsState()
    val pendingAction by aiViewModel.pendingSensitiveAction.collectAsState()

    var genderInput by remember { mutableStateOf(aiVoiceGender) }
    var languageInput by remember { mutableStateOf(aiLanguage) }
    var hindiModeInput by remember { mutableStateOf(hindiMode) }
    var speedInput by remember { mutableStateOf(aiSpeechRate) }
    var pitchInput by remember { mutableStateOf(aiVoicePitch) }
    var volumeInput by remember { mutableStateOf(aiVoiceVolume) }
    var modeInput by remember { mutableStateOf(aiOperatingMode) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Settings & Voice, 1: Permission Manager, 2: Activity Logs

    // Show Confirmation Dialog if sensitive action pending
    if (pendingAction != null) {
        AlertDialog(
            onDismissRequest = { aiViewModel.cancelSensitiveAction() },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFF9800))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("⚠️ Super Admin Confirmation Required", fontWeight = FontWeight.Bold, color = Color.Black)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(pendingAction!!.description, fontWeight = FontWeight.Bold, color = Color.Black)
                    Text(pendingAction!!.details, style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = PrimaryPink.copy(alpha = 0.1f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "Super Admin explicit approval is mandatory before any delete, price update, subscription change, or broadcast.",
                            style = MaterialTheme.typography.labelSmall,
                            color = PrimaryPink,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { aiViewModel.confirmSensitiveAction() },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Confirm Action", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { aiViewModel.cancelSensitiveAction() }) {
                    Text("Cancel Action", color = Color.Red)
                }
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Psychology, contentDescription = null, tint = PrimaryPink, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("🤖 AI Settings & AI Control Center", fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.titleMedium)
                    Text("Super Admin Master Control Panel", style = MaterialTheme.typography.labelSmall, color = PrimaryPink)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Strict Security Banner
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E293B),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF4ADE80), modifier = Modifier.size(20.dp))
                        Text(
                            "🛡️ SECURITY GUARANTEE: AI will NEVER ask for, collect, process or share OTPs, Passwords, PINs, or Bank Details.",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Control Center Navigation Tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = PrimaryPink
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("🎛️ AI Voice & Controls", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("🔐 Permissions", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("📜 Activity Log", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
                    )
                }

                if (selectedTab == 0) {
                    // TAB 0: AI STATUS, LANGUAGE, VOICE & AUDIO CONTROLS
                    // Master AI Switch
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (aiEnabled) AccentGreen.copy(alpha = 0.12f) else Color.Red.copy(alpha = 0.12f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("AI Assistant Master Status", fontWeight = FontWeight.Bold, color = Color.Black)
                                Text(
                                    if (aiEnabled) "🟢 AI Status: ACTIVE & ONLINE" else "🔴 AI Status: OFF",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (aiEnabled) AccentGreen else Color.Red
                                )
                            }
                            Switch(
                                checked = aiEnabled,
                                onCheckedChange = { aiViewModel.toggleAi(it) },
                                colors = SwitchDefaults.colors(checkedThumbColor = PrimaryPink)
                            )
                        }
                    }

                    // Output Response Toggles
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("💬 Text Reply", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                Switch(checked = textReplyEnabled, onCheckedChange = { aiViewModel.toggleTextReply(it) })
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("🔊 Voice Reply", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                Switch(checked = voiceReplyEnabled, onCheckedChange = { aiViewModel.toggleVoiceReply(it) })
                            }
                        }
                    }

                    // AI Language Selection (Hindi Default)
                    Text("🌐 Primary AI Language (Hindi Default):", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Hindi (हिंदी)", "English (IN)", "Marathi (मराठी)").forEach { lang ->
                            FilterChip(
                                selected = languageInput == lang,
                                onClick = {
                                    languageInput = lang
                                    aiViewModel.setAiLanguage(lang)
                                },
                                label = { Text(lang, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPink, selectedLabelColor = Color.White)
                            )
                        }
                    }

                    // Hindi Mode (Pure vs Simple)
                    if (languageInput.contains("Hindi") || languageInput.contains("हिंदी")) {
                        Text("🇮🇳 Hindi Accent & Style Mode:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Pure Hindi (शुद्ध हिंदी)", "Simple Hindi (सरल हिंदी)").forEach { mode ->
                                FilterChip(
                                    selected = hindiModeInput == mode,
                                    onClick = {
                                        hindiModeInput = mode
                                        aiViewModel.setHindiMode(mode)
                                    },
                                    label = { Text(mode, style = MaterialTheme.typography.labelMedium) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryBlue, selectedLabelColor = Color.White)
                                )
                            }
                        }
                    }

                    // Voice Persona Selection
                    Text("👧/👦 Voice Persona Gender Tone:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            onClick = {
                                genderInput = "Female"
                                aiViewModel.setAiVoiceGender("Female")
                            },
                            shape = RoundedCornerShape(14.dp),
                            color = if (genderInput == "Female") PrimaryPink.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (genderInput == "Female") androidx.compose.foundation.BorderStroke(2.dp, PrimaryPink) else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("👧 Female Voice", fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("Warm & Courteous", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }
                        }

                        Surface(
                            onClick = {
                                genderInput = "Male"
                                aiViewModel.setAiVoiceGender("Male")
                            },
                            shape = RoundedCornerShape(14.dp),
                            color = if (genderInput == "Male") PrimaryBlue.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (genderInput == "Male") androidx.compose.foundation.BorderStroke(2.dp, PrimaryBlue) else null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("👦 Male Voice", fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("Executive Professional", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }
                        }
                    }

                    // Audio Parameters (Speed, Pitch, Volume)
                    Text("⚡ AI Speech Speed Rate:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0.8f to "0.8x Slow", 1.0f to "1.0x Normal", 1.25f to "1.25x Fast", 1.5f to "1.5x Rapid").forEach { (speed, label) ->
                            FilterChip(
                                selected = speedInput == speed,
                                onClick = {
                                    speedInput = speed
                                    aiViewModel.setAiSpeechRate(speed)
                                },
                                label = { Text(label, style = MaterialTheme.typography.bodySmall) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryBlue, selectedLabelColor = Color.White)
                            )
                        }
                    }

                    // Pitch Control
                    Text("🎵 Voice Pitch Modulation:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0.8f to "Deep Pitch", 1.0f to "Standard", 1.3f to "High Pitch").forEach { (pitch, label) ->
                            FilterChip(
                                selected = pitchInput == pitch,
                                onClick = {
                                    pitchInput = pitch
                                    aiViewModel.setAiVoicePitch(pitch)
                                },
                                label = { Text(label, style = MaterialTheme.typography.bodySmall) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPink, selectedLabelColor = Color.White)
                            )
                        }
                    }

                    // Voice Test Button
                    OutlinedButton(
                        onClick = {
                            aiViewModel.speak("नमस्ते! सुपर लॉन्ड्री एआई कंट्रोल सेंटर वॉयस टेस्ट सक्रिय है।")
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = PrimaryPink)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("🔊 Test AI Voice Greeting Now", color = PrimaryPink, fontWeight = FontWeight.Bold)
                    }

                } else if (selectedTab == 1) {
                    // TAB 1: AI PERMISSION MANAGER (Allow / Deny per Module)
                    Text("🔑 AI Module Permission Manager (Allow/Deny):", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                    Text("Super Admin can grant or revoke AI assistant access for specific modules:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                    val moduleList = listOf(
                        "reports" to "Daily / Weekly / Yearly Reports",
                        "dashboard" to "Platform Control Dashboard",
                        "orders" to "Orders & Rate Cards",
                        "customers" to "Customers & Order History",
                        "laundry_admin" to "Laundry Stores Management",
                        "notifications" to "App Push Notifications",
                        "subscription" to "Subscription Plans & Pricing",
                        "analytics" to "Sales & Business Analytics",
                        "broadcast" to "Marketing & Offer Broadcasts",
                        "support" to "Support Tickets Resolution",
                        "settings" to "App & Theme Settings"
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        moduleList.forEach { (key, label) ->
                            val isAllowed = modulePermissions[key] ?: true
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isAllowed) PrimaryPink.copy(alpha = 0.08f) else Color.Red.copy(alpha = 0.08f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                                        Text(
                                            if (isAllowed) "Allowed (AI active for this module)" else "Denied (AI restricted by Super Admin)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (isAllowed) AccentGreen else Color.Red
                                        )
                                    }
                                    Switch(
                                        checked = isAllowed,
                                        onCheckedChange = { allowed ->
                                            aiViewModel.toggleModulePermission(key, allowed)
                                        },
                                        colors = SwitchDefaults.colors(checkedThumbColor = PrimaryPink, uncheckedThumbColor = Color.Red)
                                    )
                                }
                            }
                        }
                    }

                } else {
                    // TAB 2: AI ACTIVITY LOG DASHBOARD
                    Text("📜 Real-Time AI Activity & Audit Log:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                    if (activityLogs.isEmpty()) {
                        Text("No activity logged yet.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            activityLogs.forEach { log ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (log.isBlocked) Color.Red.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Module: ${log.module.uppercase()}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, color = PrimaryPink)
                                            Text(
                                                if (log.isBlocked) "🚫 BLOCKED" else "✅ EXECUTED",
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (log.isBlocked) Color.Red else AccentGreen
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(log.action, style = MaterialTheme.typography.bodySmall, color = Color.Black)
                                        if (log.reason != null) {
                                            Text("Reason: ${log.reason}", style = MaterialTheme.typography.labelSmall, color = Color.Red)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    aiViewModel.setAiVoiceGender(genderInput)
                    aiViewModel.setAiLanguage(languageInput)
                    aiViewModel.setAiSpeechRate(speedInput)
                    aiViewModel.setAiOperatingMode(modeInput)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
            ) {
                Text("Save Control Settings", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionPlanManagerDialog(
    mainViewModel: MainViewModel,
    shops: List<LaundryShop>,
    onDismiss: () -> Unit
) {
    val defaultShop = LaundryShop(
        id = "shop_1",
        name = "Super Laundry Drive Cleaners",
        ownerPhone = "+91 9876543210",
        logoUrl = "https://images.unsplash.com/photo-1545173168-9f1947eebb7f",
        bannerUrl = "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60",
        rating = 4.8,
        reviewCount = 120,
        distanceKm = 1.2,
        address = "Main Market Road, City Center",
        latitude = 12.9716,
        longitude = 77.5946,
        phone = "+91 9876543210",
        isOpen = true
    )

    var selectedShop by remember { mutableStateOf(shops.firstOrNull() ?: defaultShop) }
    var selectedPlan by remember { mutableStateOf(SubscriptionPlan.MONTHLY) }
    var monthlyPrice by remember { mutableStateOf("999") }
    var yearlyPrice by remember { mutableStateOf("8999") }
    var customAmount by remember { mutableStateOf("999") }
    var planLogoUrl by remember { mutableStateOf(selectedShop.logoUrl) }

    val logoPresets = listOf(
        "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?q=80&w=300",
        "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=300",
        "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=300",
        "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?q=80&w=300"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CardMembership, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Super Admin Subscription & Plan Pricing Control", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Select Laundry Store:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    shops.take(4).forEach { shop ->
                        Surface(
                            onClick = {
                                selectedShop = shop
                                planLogoUrl = shop.logoUrl
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = if (selectedShop.id == shop.id) PrimaryPink.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(shop.name, fontWeight = FontWeight.SemiBold, color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                                if (selectedShop.id == shop.id) Icon(Icons.Default.Check, contentDescription = null, tint = PrimaryPink)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("Choose & Edit Plan Tiers (Monthly, Yearly, Annually):", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                val plans = listOf(
                    SubscriptionPlan.MONTHLY to "Standard 1 Month Plan (₹999/mo)",
                    SubscriptionPlan.QUARTERLY to "Popular 3 Month Plan (₹2,699/3-mo)",
                    SubscriptionPlan.HALF_YEARLY to "Priority AI 6 Month Plan (₹4,999/6-mo)",
                    SubscriptionPlan.YEARLY to "Unlimited 1 Year Plan (₹8,999/yr)"
                )

                plans.forEach { pair ->
                    val plan = pair.first
                    val subtitle = pair.second
                    Surface(
                        onClick = {
                            selectedPlan = plan
                            customAmount = when(plan) {
                                SubscriptionPlan.MONTHLY -> monthlyPrice
                                SubscriptionPlan.QUARTERLY -> "2699"
                                SubscriptionPlan.HALF_YEARLY -> "4999"
                                SubscriptionPlan.YEARLY -> yearlyPrice
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        color = if (selectedPlan == plan) PrimaryPink.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (selectedPlan == plan) androidx.compose.foundation.BorderStroke(2.dp, PrimaryPink) else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(plan.title, fontWeight = FontWeight.Bold, color = Color.Black)
                                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                            RadioButton(
                                selected = selectedPlan == plan,
                                onClick = {
                                    selectedPlan = plan
                                    customAmount = when(plan) {
                                        SubscriptionPlan.MONTHLY -> monthlyPrice
                                        SubscriptionPlan.QUARTERLY -> "2699"
                                        SubscriptionPlan.HALF_YEARLY -> "4999"
                                        SubscriptionPlan.YEARLY -> yearlyPrice
                                    }
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = PrimaryPink)
                            )
                        }
                    }
                }

                Text("Edit Monthly & Yearly Subscription Prices:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = monthlyPrice,
                        onValueChange = { 
                            monthlyPrice = it
                            if (selectedPlan == SubscriptionPlan.MONTHLY) customAmount = it
                        },
                        label = { Text("Monthly Price (₹)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = yearlyPrice,
                        onValueChange = { 
                            yearlyPrice = it
                            if (selectedPlan == SubscriptionPlan.YEARLY) customAmount = it
                        },
                        label = { Text("Yearly Price (₹)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Text("Custom Active Price / Amount (Free, ₹1, ₹2, or Custom):", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                OutlinedTextField(
                    value = customAmount,
                    onValueChange = { customAmount = it },
                    label = { Text("Enter Amount in INR (₹)") },
                    singleLine = true,
                    leadingIcon = { Text("₹", fontWeight = FontWeight.Bold, color = PrimaryPink) },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Quick Price Presets:", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val presets = listOf("0" to "₹0 (Free)", "1" to "₹1 (Trial)", "2" to "₹2 (Promo)", "499" to "₹499", "999" to "₹999", "2699" to "₹2,699", "8999" to "₹8,999")
                    items(presets) { (amt, label) ->
                        FilterChip(
                            selected = customAmount == amt,
                            onClick = { customAmount = amt },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPink, selectedLabelColor = Color.White)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("Edit Subscription Plan Logo Image URL:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                OutlinedTextField(
                    value = planLogoUrl,
                    onValueChange = { planLogoUrl = it },
                    label = { Text("Plan / Store Badge Image URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Select Preset Logo Badge:", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(logoPresets) { url ->
                        AsyncImage(
                            model = url,
                            contentDescription = null,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .border(2.dp, if (planLogoUrl == url) PrimaryPink else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { planLogoUrl = url },
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val customVal = customAmount.toIntOrNull() ?: 0
                    val isFree = customAmount == "0" || customAmount.lowercase() == "free"

                    val mVal = monthlyPrice.toIntOrNull() ?: 999
                    val yVal = yearlyPrice.toIntOrNull() ?: 8999

                    mainViewModel.updateSubscriptionPlanPrice("MONTHLY", mVal, mVal == 0)
                    mainViewModel.updateSubscriptionPlanPrice("YEARLY", yVal, yVal == 0)
                    mainViewModel.updateSubscriptionPlanPrice(selectedPlan.name, customVal, isFree)

                    mainViewModel.updateShopDetails(
                        selectedShop.copy(
                            logoUrl = planLogoUrl
                        )
                    )
                    mainViewModel.changeShopSubscription(selectedShop.id, selectedShop.name, selectedPlan)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
            ) {
                Text("Save Subscription & Price (₹$customAmount)", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvertisementBannerCreatorDialog(
    mainViewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val banners by mainViewModel.allBanners.collectAsState()

    var adTitle by remember { mutableStateOf("⚡ FESTIVE 50% OFF STEAM PRESSING") }
    var adSubtitle by remember { mutableStateOf("Special Festival Offer Across All Partner Shops") }
    var adCode by remember { mutableStateOf("FESTIVE50") }
    var adDiscount by remember { mutableStateOf("50") }
    var adImageUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=1000") }
    var photoCaptureNotice by remember { mutableStateOf<String?>(null) }
    var showCameraSimulatedCapture by remember { mutableStateOf(false) }

    // Camera Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            photoCaptureNotice = "📷 Camera Photo Captured Successfully!"
            adImageUrl = "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=1000"
        } else {
            photoCaptureNotice = "📷 Camera photo recorded (Sample Preset Loaded)"
            adImageUrl = "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=1000"
        }
    }

    // Gallery Picker Launcher
    val galleryPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            adImageUrl = uri.toString()
            photoCaptureNotice = "🖼️ Gallery Photo Selected: ${uri.lastPathSegment}"
        } else {
            photoCaptureNotice = "🖼️ Gallery Banner Selected"
        }
    }

    val galleryPresets = listOf(
        "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=1000" to "Washing Machine",
        "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?q=80&w=1000" to "Steam Ironing",
        "https://images.unsplash.com/photo-1521656693074-0ef32e80a5d5?q=80&w=1000" to "Dry Cleaning",
        "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?q=80&w=1000" to "Store Hero Banner"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Campaign, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("📢 Advertisements & Banner Ads Creator", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Active Platform Advertisements (${banners.size}):", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                if (banners.isEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = PrimaryPink.copy(alpha = 0.1f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "No active ads! Create your first banner ad below using Camera or Gallery.",
                            style = MaterialTheme.typography.bodySmall,
                            color = PrimaryPink,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        banners.forEach { banner ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        AsyncImage(
                                            model = banner.imageUrl,
                                            contentDescription = null,
                                            modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                        Column {
                                            Text(banner.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                                            Text("Code: ${banner.code} • ${banner.discountPercent}% OFF", style = MaterialTheme.typography.labelSmall, color = PrimaryPink)
                                        }
                                    }
                                    IconButton(onClick = { mainViewModel.deleteOfferBanner(banner.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete Ad", tint = Color.Red.copy(alpha = 0.7f))
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("➕ Create & Publish New Banner Ad:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                OutlinedTextField(
                    value = adTitle,
                    onValueChange = { adTitle = it },
                    label = { Text("Ad Headline Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = adSubtitle,
                    onValueChange = { adSubtitle = it },
                    label = { Text("Ad Subtitle / Tagline") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = adCode,
                        onValueChange = { adCode = it },
                        label = { Text("Promo Code") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = adDiscount,
                        onValueChange = { adDiscount = it },
                        label = { Text("Discount %") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Text("Banner Photo (Camera or Gallery):", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { cameraLauncher.launch(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("📷 Camera", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { galleryPickerLauncher.launch("image/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("🖼️ Gallery", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (photoCaptureNotice != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AccentGreen.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            photoCaptureNotice!!,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentGreen,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                Text("Pick Preset Banner or Custom URL:", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(galleryPresets) { (url, label) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            AsyncImage(
                                model = url,
                                contentDescription = null,
                                modifier = Modifier
                                    .width(80.dp)
                                    .height(50.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(2.dp, if (adImageUrl == url) PrimaryPink else Color.Transparent, RoundedCornerShape(8.dp))
                                    .clickable { 
                                        adImageUrl = url
                                        showCameraSimulatedCapture = false
                                    },
                                contentScale = ContentScale.Crop
                            )
                            Text(label, style = MaterialTheme.typography.labelSmall, fontSize = 9.sp)
                        }
                    }
                }

                OutlinedTextField(
                    value = adImageUrl,
                    onValueChange = { 
                        adImageUrl = it
                        showCameraSimulatedCapture = false
                    },
                    label = { Text("Ad Image URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (adTitle.isNotBlank()) {
                        val banner = OfferBanner(
                            id = "banner_${System.currentTimeMillis()}",
                            shopId = null,
                            title = adTitle,
                            subtitle = adSubtitle,
                            code = adCode,
                            discountPercent = adDiscount.toIntOrNull() ?: 20,
                            isPlatformWide = true,
                            imageUrl = adImageUrl
                        )
                        mainViewModel.addOfferBanner(banner)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Publish Advertisement Ad", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BroadcastNotificationDialog(
    mainViewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    var titleInput by remember { mutableStateOf("⚡ Special Super Laundry Festival Offer!") }
    var messageInput by remember { mutableStateOf("Enjoy 20% flat discount on all Dry Cleaning and Steam Press orders across all verified stores.") }
    var audienceInput by remember { mutableStateOf("Both Admins & Customers") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Campaign, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Send Broadcast Announcement", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = titleInput,
                    onValueChange = { titleInput = it },
                    label = { Text("Announcement Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = messageInput,
                    onValueChange = { messageInput = it },
                    label = { Text("Notification Message") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Target Audience:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("All Laundry Admins", "All Customers", "Both Admins & Customers").forEach { audience ->
                        FilterChip(
                            selected = audienceInput == audience,
                            onClick = { audienceInput = audience },
                            label = { Text(audience, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPink, selectedLabelColor = Color.White)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (titleInput.isNotBlank() && messageInput.isNotBlank()) {
                        mainViewModel.sendBroadcastAnnouncement(titleInput, messageInput, audienceInput)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Send Announcement", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogoBannerDialog(
    mainViewModel: MainViewModel,
    myShop: LaundryShop?,
    onDismiss: () -> Unit
) {
    var logoInput by remember { mutableStateOf(myShop?.logoUrl ?: "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?q=80&w=300") }
    var bannerInput by remember { mutableStateOf(myShop?.bannerUrl ?: "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=1000") }

    val logoPresets = listOf(
        "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?q=80&w=300",
        "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=300",
        "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=300"
    )

    val bannerPresets = listOf(
        "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=1000",
        "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?q=80&w=1000",
        "https://images.unsplash.com/photo-1489274495757-95c7c837b101?q=80&w=1000"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("📷 Edit Logo & Store Banner", fontWeight = FontWeight.Bold, color = Color.Black) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Store Logo Image URL:", fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(
                    value = logoInput,
                    onValueChange = { logoInput = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Pick Preset Logo:", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(logoPresets) { url ->
                        AsyncImage(
                            model = url,
                            contentDescription = null,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .border(2.dp, if (logoInput == url) PrimaryPink else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { logoInput = url },
                            contentScale = ContentScale.Crop
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("Store Hero Banner Image URL:", fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(
                    value = bannerInput,
                    onValueChange = { bannerInput = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Pick Preset Banner:", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(bannerPresets) { url ->
                        AsyncImage(
                            model = url,
                            contentDescription = null,
                            modifier = Modifier
                                .width(90.dp)
                                .height(50.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .border(2.dp, if (bannerInput == url) PrimaryPink else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { bannerInput = url },
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (myShop != null) {
                        mainViewModel.updateShopDetails(myShop.copy(logoUrl = logoInput, bannerUrl = bannerInput))
                    } else {
                        mainViewModel.updateAppBranding("Super Laundry", logoInput, bannerInput)
                    }
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
            ) {
                Text("Save Logo & Banner", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileDetailsDialog(
    mainViewModel: MainViewModel,
    myShop: LaundryShop?,
    onDismiss: () -> Unit
) {
    var nameInput by remember { mutableStateOf(myShop?.name ?: "Super Laundry Drive Cleaners") }
    var phoneInput by remember { mutableStateOf(myShop?.phone ?: "+91 9876543210") }
    var addressInput by remember { mutableStateOf(myShop?.address ?: "Main Market Road, City Center") }
    var descInput by remember { mutableStateOf(myShop?.description ?: "Premium Dry Cleaning & Steam Pressing") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("👤 Edit Profile & Store Details", fontWeight = FontWeight.Bold, color = Color.Black) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("Store / Owner Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { phoneInput = it },
                    label = { Text("Contact Phone Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = addressInput,
                    onValueChange = { addressInput = it },
                    label = { Text("Shop Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = descInput,
                    onValueChange = { descInput = it },
                    label = { Text("Service Description") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (myShop != null) {
                        mainViewModel.updateShopDetails(
                            myShop.copy(
                                name = nameInput,
                                phone = phoneInput,
                                address = addressInput,
                                description = descInput
                            )
                        )
                    }
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
            ) {
                Text("Save Profile Changes", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun EditCustomerProfileDialog(
    initialName: String,
    initialPhone: String,
    initialEmail: String?,
    initialAddress: String,
    initialIsLongTerm: Boolean = false,
    initialPlanName: String? = null,
    onSave: (name: String, phone: String, email: String?, address: String, isLongTerm: Boolean, planName: String?) -> Unit,
    onDismiss: () -> Unit
) {
    var nameInput by remember { mutableStateOf(initialName) }
    var phoneInput by remember { mutableStateOf(initialPhone) }
    var emailInput by remember { mutableStateOf(initialEmail ?: "") }
    var addressInput by remember { mutableStateOf(initialAddress) }
    var isLongTerm by remember { mutableStateOf(initialIsLongTerm) }
    var selectedPlan by remember { mutableStateOf(initialPlanName ?: "Monthly Plan (1 Month)") }

    val longTermPlans = listOf(
        "Monthly Plan (1 Month)",
        "Quarterly Saver (3 Months)",
        "Half-Yearly Pass (6 Months)",
        "Annual Gold (12 Months)"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Edit Customer Profile Data", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Update customer details below. All fields can be edited and saved.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("Customer Full Name") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = PrimaryPink) },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { phoneInput = it },
                    label = { Text("Mobile Phone Number") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = PrimaryPink) },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = emailInput,
                    onValueChange = { emailInput = it },
                    label = { Text("Email Address") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = PrimaryPink) },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = addressInput,
                    onValueChange = { addressInput = it },
                    label = { Text("Delivery Address") },
                    minLines = 2,
                    leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, tint = PrimaryPink) },
                    modifier = Modifier.fillMaxWidth()
                )

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Long-Term Order / Subscription Customer", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                        Text("Display long-term status badge and order history", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Switch(
                        checked = isLongTerm,
                        onCheckedChange = { isLongTerm = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = PrimaryPink, checkedTrackColor = PrimaryPink.copy(alpha = 0.3f))
                    )
                }

                if (isLongTerm) {
                    Text("Select Long-Term Subscription Package:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    longTermPlans.forEach { plan ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { selectedPlan = plan }
                                .padding(vertical = 6.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = (selectedPlan == plan),
                                onClick = { selectedPlan = plan },
                                colors = RadioButtonDefaults.colors(selectedColor = PrimaryPink)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(plan, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        nameInput,
                        phoneInput,
                        emailInput.ifEmpty { null },
                        addressInput,
                        isLongTerm,
                        if (isLongTerm) selectedPlan else null
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save Profile Data", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun PlaceLongTermOrderDialog(
    mainViewModel: MainViewModel,
    customerPhone: String,
    customerName: String,
    customerAddress: String,
    onDismiss: () -> Unit
) {
    val allShops by mainViewModel.allShops.collectAsState()
    var selectedShop by remember { mutableStateOf(allShops.firstOrNull()) }
    var selectedPlan by remember { mutableStateOf(SubscriptionPlan.MONTHLY) }
    var addressInput by remember { mutableStateOf(customerAddress) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CardMembership, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Place Long-Term Laundry Order", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Get doorstep laundry pickups and unlimited pressing with a long-term pass. Your profile will show your active long-term subscription.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                Text("1. Select Laundry Shop:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                allShops.forEach { shop ->
                    Surface(
                        onClick = { selectedShop = shop },
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedShop?.id == shop.id) PrimaryPink.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (selectedShop?.id == shop.id) androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryPink) else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(shop.name, fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("${shop.address} • Rating: ${shop.rating} ★", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                            if (selectedShop?.id == shop.id) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PrimaryPink)
                            }
                        }
                    }
                }

                Text("2. Choose Subscription Pass Duration:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                SubscriptionPlan.entries.forEach { plan ->
                    Surface(
                        onClick = { selectedPlan = plan },
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedPlan == plan) PrimaryPink.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (selectedPlan == plan) androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryPink) else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(plan.title, fontWeight = FontWeight.Bold, color = Color.Black)
                                    if (plan.badge != null) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(shape = RoundedCornerShape(4.dp), color = AccentGreen) {
                                            Text(plan.badge, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                                Text("${plan.durationMonths} Months Duration • Unlimited Pickups", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                            Text("₹${plan.priceRupees}", fontWeight = FontWeight.Black, color = PrimaryPink, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }

                OutlinedTextField(
                    value = addressInput,
                    onValueChange = { addressInput = it },
                    label = { Text("Delivery Address for Long-Term Pickups") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val shop = selectedShop ?: allShops.firstOrNull()
                    if (shop != null) {
                        mainViewModel.placeLongTermOrder(
                            shopId = shop.id,
                            shopName = shop.name,
                            planTitle = selectedPlan.title,
                            priceRupees = selectedPlan.priceRupees.toDouble(),
                            customerPhone = customerPhone,
                            customerName = customerName,
                            deliveryAddress = addressInput
                        )
                    }
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Confirm & Pay ₹${selectedPlan.priceRupees}", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppBrandingCustomizationDialog(
    mainViewModel: MainViewModel,
    aiViewModel: AiViewModel,
    onDismiss: () -> Unit
) {
    val currentAppName by mainViewModel.appName.collectAsState()
    val currentTagline by mainViewModel.appTagline.collectAsState()
    val currentPrimaryHex by mainViewModel.primaryColorHex.collectAsState()
    val currentHeaderBgHex by mainViewModel.headerBgColorHex.collectAsState()
    val currentSupportCallHex by mainViewModel.supportCallColorHex.collectAsState()
    val currentLogoHex by mainViewModel.logoColorHex.collectAsState()

    val isOrderTracking by mainViewModel.isOrderTrackingEnabled.collectAsState()
    val isDirectCall by mainViewModel.isDirectCallEnabled.collectAsState()
    val isInAppChat by mainViewModel.isInAppChatEnabled.collectAsState()
    val isRateCard by mainViewModel.isRateCardManagerEnabled.collectAsState()
    val isCoupons by mainViewModel.isCouponsOffersEnabled.collectAsState()
    val isSelfCheckout by mainViewModel.isSelfCheckoutEnabled.collectAsState()
    val isAiEnabled by aiViewModel.aiEnabled.collectAsState()

    var appTitleInput by remember { mutableStateOf(currentAppName) }
    var taglineInput by remember { mutableStateOf(currentTagline) }
    var selectedPrimaryHex by remember { mutableStateOf(currentPrimaryHex) }
    var selectedHeaderBgHex by remember { mutableStateOf(currentHeaderBgHex) }
    var selectedSupportCallHex by remember { mutableStateOf(currentSupportCallHex) }
    var selectedLogoHex by remember { mutableStateOf(currentLogoHex) }

    val primaryColors = listOf(
        "#EC4899" to "Soft Pink (Default)",
        "#0EA5E9" to "Sky Light Blue",
        "#6366F1" to "Indigo Royal",
        "#10B981" to "Emerald Green",
        "#F59E0B" to "Golden Amber",
        "#DC2626" to "Crimson Red",
        "#8B5CF6" to "Violet Purple",
        "#0F172A" to "Dark Slate Navy"
    )

    val supportCallColors = listOf(
        "#10B981" to "Emerald Green (Default Call)",
        "#0EA5E9" to "Sky Blue Call",
        "#EC4899" to "Pink Call Accent",
        "#F59E0B" to "Amber Gold Call",
        "#0F172A" to "Dark Navy Call"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Palette, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Color Change Setting & App Controls", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("🎨 1. App Primary Theme & Thumbnail Color Setting", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    primaryColors.forEach { (hex, name) ->
                        val colorVal = try { Color(android.graphics.Color.parseColor(hex)) } catch (e: Exception) { PrimaryPink }
                        Surface(
                            onClick = {
                                selectedPrimaryHex = hex
                                selectedLogoHex = hex
                            },
                            shape = RoundedCornerShape(10.dp),
                            color = colorVal.copy(alpha = 0.15f),
                            border = if (selectedPrimaryHex == hex) androidx.compose.foundation.BorderStroke(2.dp, colorVal) else null,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(modifier = Modifier.size(22.dp).clip(CircleShape).background(colorVal))
                                    Text(name, fontWeight = FontWeight.SemiBold, color = Color.Black)
                                }
                                RadioButton(
                                    selected = selectedPrimaryHex == hex,
                                    onClick = {
                                        selectedPrimaryHex = hex
                                        selectedLogoHex = hex
                                    },
                                    colors = RadioButtonDefaults.colors(selectedColor = colorVal)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("📞 2. Support Call Button Color Setting", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    supportCallColors.forEach { (hex, name) ->
                        val colorVal = try { Color(android.graphics.Color.parseColor(hex)) } catch (e: Exception) { AccentGreen }
                        Surface(
                            onClick = { selectedSupportCallHex = hex },
                            shape = RoundedCornerShape(10.dp),
                            color = colorVal.copy(alpha = 0.15f),
                            border = if (selectedSupportCallHex == hex) androidx.compose.foundation.BorderStroke(2.dp, colorVal) else null,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(modifier = Modifier.size(22.dp).clip(CircleShape).background(colorVal))
                                    Text(name, fontWeight = FontWeight.SemiBold, color = Color.Black)
                                }
                                RadioButton(
                                    selected = selectedSupportCallHex == hex,
                                    onClick = { selectedSupportCallHex = hex },
                                    colors = RadioButtonDefaults.colors(selectedColor = colorVal)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("👁️ Live Theme & Button Preview", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = try { Color(android.graphics.Color.parseColor(selectedPrimaryHex)).copy(alpha = 0.12f) } catch (e: Exception) { PrimaryPink.copy(alpha = 0.12f) },
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, try { Color(android.graphics.Color.parseColor(selectedPrimaryHex)) } catch (e: Exception) { PrimaryPink }),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(try { Color(android.graphics.Color.parseColor(selectedPrimaryHex)) } catch (e: Exception) { PrimaryPink }))
                            Text("Active Theme: $appTitleInput", fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {},
                                colors = ButtonDefaults.buttonColors(containerColor = try { Color(android.graphics.Color.parseColor(selectedPrimaryHex)) } catch (e: Exception) { PrimaryPink }),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Primary Action", color = Color.White, style = MaterialTheme.typography.labelMedium)
                            }
                            Button(
                                onClick = {},
                                colors = ButtonDefaults.buttonColors(containerColor = try { Color(android.graphics.Color.parseColor(selectedSupportCallHex)) } catch (e: Exception) { AccentGreen }),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Call Support", color = Color.White, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("🏷️ 3. App Title & Subtitle Customization", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                OutlinedTextField(
                    value = appTitleInput,
                    onValueChange = { appTitleInput = it },
                    label = { Text("App Name / Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = taglineInput,
                    onValueChange = { taglineInput = it },
                    label = { Text("App Subtitle / Tagline") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))
                Text("⚙️ 4. Feature Enable / Disable Controls", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Live GPS Order Tracking", style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                    Switch(checked = isOrderTracking, onCheckedChange = { mainViewModel.toggleFeature("order_tracking", it) })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Direct Phone Call Button", style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                    Switch(checked = isDirectCall, onCheckedChange = { mainViewModel.toggleFeature("direct_call", it) })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("In-App Order Chat", style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                    Switch(checked = isInAppChat, onCheckedChange = { mainViewModel.toggleFeature("in_app_chat", it) })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Rate Card & Pricing Manager", style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                    Switch(checked = isRateCard, onCheckedChange = { mainViewModel.toggleFeature("rate_card_manager", it) })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Coupons & Offers Banner", style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                    Switch(checked = isCoupons, onCheckedChange = { mainViewModel.toggleFeature("coupons_offers", it) })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Self Checkout & Online Pay", style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                    Switch(checked = isSelfCheckout, onCheckedChange = { mainViewModel.toggleFeature("self_checkout", it) })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("AI Voice & Operations Support", style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                    Switch(checked = isAiEnabled, onCheckedChange = { aiViewModel.toggleAi(it) })
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        mainViewModel.resetThemeToDefault()
                        selectedPrimaryHex = "#EC4899"
                        selectedHeaderBgHex = "#6366F1"
                        selectedSupportCallHex = "#10B981"
                        selectedLogoHex = "#EC4899"
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Reset Theme", fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        mainViewModel.updateAppBranding(
                            name = appTitleInput,
                            logoUrl = "",
                            backgroundUrl = ""
                        )
                        mainViewModel.updateAppStylingAndColors(
                            primaryHex = selectedPrimaryHex,
                            headerBgHex = selectedHeaderBgHex,
                            textHex = "#0F172A",
                            logoHex = selectedLogoHex,
                            supportCallHex = selectedSupportCallHex,
                            tagline = taglineInput
                        )
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Save Settings", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FutureFeatureSettingsDialog(
    mainViewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val futureFeatures by mainViewModel.futureFeatures.collectAsState()

    var featureNameInput by remember { mutableStateOf("") }
    var featurePromptInput by remember { mutableStateOf("") }
    var featureReqsInput by remember { mutableStateOf("") }
    var selectedTargetRole by remember { mutableStateOf("All Roles") }
    var selectedTargetDashboard by remember { mutableStateOf("Super Admin Platform") }

    val roles = listOf("All Roles", "Super Admin", "Laundry Admin", "Customer")
    val dashboards = listOf("Super Admin Platform", "Super Admin Store", "Laundry Admin", "Customer")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.BuildCircle, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Future Feature Settings & Builder", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("📝 1. Add New Future Feature Prompt / Requirement", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                OutlinedTextField(
                    value = featureNameInput,
                    onValueChange = { featureNameInput = it },
                    label = { Text("Feature Name") },
                    placeholder = { Text("e.g. Subscription Expiry Reminder") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = featurePromptInput,
                    onValueChange = { featurePromptInput = it },
                    label = { Text("Feature Description / Prompt") },
                    placeholder = { Text("Describe what this feature should do...") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = featureReqsInput,
                    onValueChange = { featureReqsInput = it },
                    label = { Text("Feature Requirements & Rules") },
                    placeholder = { Text("List any technical rules, triggers or permissions...") },
                    minLines = 2,
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Target Role:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = Color.Black)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    roles.forEach { role ->
                        FilterChip(
                            selected = selectedTargetRole == role,
                            onClick = { selectedTargetRole = role },
                            label = { Text(role, fontSize = 11.sp) }
                        )
                    }
                }

                Text("Target Dashboard:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = Color.Black)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    dashboards.forEach { dash ->
                        FilterChip(
                            selected = selectedTargetDashboard == dash,
                            onClick = { selectedTargetDashboard = dash },
                            label = { Text(dash.take(12), fontSize = 11.sp) }
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            if (featureNameInput.isNotBlank() && featurePromptInput.isNotBlank()) {
                                val config = FutureFeatureConfig(
                                    featureName = featureNameInput,
                                    promptDescription = featurePromptInput,
                                    requirements = featureReqsInput,
                                    targetRole = selectedTargetRole,
                                    targetDashboard = selectedTargetDashboard,
                                    isEnabled = true
                                )
                                mainViewModel.addFutureFeature(config)
                                featureNameInput = ""
                                featurePromptInput = ""
                                featureReqsInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Activate Feature", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            if (featureNameInput.isNotBlank()) {
                                val config = FutureFeatureConfig(
                                    featureName = featureNameInput,
                                    promptDescription = featurePromptInput,
                                    requirements = featureReqsInput,
                                    targetRole = selectedTargetRole,
                                    targetDashboard = selectedTargetDashboard,
                                    isEnabled = false
                                )
                                mainViewModel.addFutureFeature(config)
                                featureNameInput = ""
                                featurePromptInput = ""
                                featureReqsInput = ""
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Draft", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("📜 2. Feature Registry & Active Feature Flags", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                futureFeatures.forEach { feat ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(feat.featureName, fontWeight = FontWeight.Bold, color = Color.Black)
                                    Text("Role: ${feat.targetRole} • ${feat.targetDashboard}", fontSize = 11.sp, color = PrimaryBlue)
                                }
                                Switch(
                                    checked = feat.isEnabled,
                                    onCheckedChange = { isChecked ->
                                        mainViewModel.toggleFutureFeature(feat.id, isChecked)
                                    }
                                )
                            }
                            Text(feat.promptDescription, style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Done", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UiLabelManagerDialog(
    mainViewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val labels by mainViewModel.customUiLabels.collectAsState()

    var namasteInput by remember { mutableStateOf(labels["namaste"] ?: "Namaste, Super Laundry!") }
    var greetingSubInput by remember { mutableStateOf(labels["greeting_sub"] ?: "Platform controls and AI neural insights are online.") }
    var storeSwitchInput by remember { mutableStateOf(labels["switch_to_store"] ?: "Super Laundry Store") }
    var platformSwitchInput by remember { mutableStateOf(labels["switch_to_platform"] ?: "Platform Admin") }
    var chatLabelInput by remember { mutableStateOf(labels["chat_label"] ?: "In-App Customer Chat") }
    var callingLabelInput by remember { mutableStateOf(labels["calling_label"] ?: "Direct Phone Call Support") }
    var supportLabelInput by remember { mutableStateOf(labels["support_label"] ?: "Super Admin Helpdesk") }
    var aiControlInput by remember { mutableStateOf(labels["ai_control_center"] ?: "AI Control Center") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.EditNote, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("✍️ Dynamic UI Label Settings", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Change any UI label at any time:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                OutlinedTextField(
                    value = namasteInput,
                    onValueChange = { namasteInput = it },
                    label = { Text("Dashboard Header Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = greetingSubInput,
                    onValueChange = { greetingSubInput = it },
                    label = { Text("Header Subtitle / Tagline") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = storeSwitchInput,
                    onValueChange = { storeSwitchInput = it },
                    label = { Text("Store View Switcher Label") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = platformSwitchInput,
                    onValueChange = { platformSwitchInput = it },
                    label = { Text("Platform Control Switcher Label") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = chatLabelInput,
                    onValueChange = { chatLabelInput = it },
                    label = { Text("Chat Button Label") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = callingLabelInput,
                    onValueChange = { callingLabelInput = it },
                    label = { Text("Calling Button Label") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = supportLabelInput,
                    onValueChange = { supportLabelInput = it },
                    label = { Text("Support & Helpdesk Label") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = aiControlInput,
                    onValueChange = { aiControlInput = it },
                    label = { Text("AI Control Center Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    mainViewModel.updateCustomUiLabels(
                        mapOf(
                            "namaste" to namasteInput,
                            "greeting_sub" to greetingSubInput,
                            "switch_to_store" to storeSwitchInput,
                            "switch_to_platform" to platformSwitchInput,
                            "chat_label" to chatLabelInput,
                            "calling_label" to callingLabelInput,
                            "support_label" to supportLabelInput,
                            "ai_control_center" to aiControlInput
                        )
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Save UI Labels", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColorSettingsDialog(
    mainViewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val primaryHex by mainViewModel.primaryColorHex.collectAsState()
    val chatHex by mainViewModel.chatColorHex.collectAsState()
    val callHex by mainViewModel.callColorHex.collectAsState()
    val supportHex by mainViewModel.supportColorHex.collectAsState()

    var customPrimaryHexInput by remember { mutableStateOf(primaryHex) }
    var customChatHexInput by remember { mutableStateOf(chatHex) }
    var customCallHexInput by remember { mutableStateOf(callHex) }
    var customSupportHexInput by remember { mutableStateOf(supportHex) }

    val presetColors = listOf(
        "#EC4899" to "Soft Pink",
        "#6366F1" to "Indigo Royal",
        "#10B981" to "Emerald Green",
        "#0EA5E9" to "Sky Blue",
        "#F59E0B" to "Amber Gold",
        "#DC2626" to "Crimson Red",
        "#8B5CF6" to "Violet Purple",
        "#0F172A" to "Dark Navy"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Palette, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("🎨 Custom Color Settings (Chat, Call, Support)", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Manage colors for Chat, Calling, Support & Theme:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                // 1. Primary App Theme Color
                Text("1. Primary App Theme Color:", fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 12.sp)
                OutlinedTextField(
                    value = customPrimaryHexInput,
                    onValueChange = { customPrimaryHexInput = it },
                    label = { Text("Primary Theme Hex Code") },
                    singleLine = true,
                    leadingIcon = {
                        val colorVal = try { Color(android.graphics.Color.parseColor(customPrimaryHexInput)) } catch (e: Exception) { PrimaryPink }
                        Box(modifier = Modifier.size(20.dp).clip(CircleShape).background(colorVal))
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                // 2. Chat Color
                Text("2. Customer & AI Chat Color:", fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 12.sp)
                OutlinedTextField(
                    value = customChatHexInput,
                    onValueChange = { customChatHexInput = it },
                    label = { Text("In-App Chat Color Hex Code") },
                    singleLine = true,
                    leadingIcon = {
                        val colorVal = try { Color(android.graphics.Color.parseColor(customChatHexInput)) } catch (e: Exception) { PrimaryBlue }
                        Box(modifier = Modifier.size(20.dp).clip(CircleShape).background(colorVal))
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                // 3. Calling Color
                Text("3. Direct Phone Calling Button Color:", fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 12.sp)
                OutlinedTextField(
                    value = customCallHexInput,
                    onValueChange = { customCallHexInput = it },
                    label = { Text("Call Button Color Hex Code") },
                    singleLine = true,
                    leadingIcon = {
                        val colorVal = try { Color(android.graphics.Color.parseColor(customCallHexInput)) } catch (e: Exception) { AccentGreen }
                        Box(modifier = Modifier.size(20.dp).clip(CircleShape).background(colorVal))
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                // 4. Support Color
                Text("4. Support Helpdesk Color:", fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 12.sp)
                OutlinedTextField(
                    value = customSupportHexInput,
                    onValueChange = { customSupportHexInput = it },
                    label = { Text("Support Badge Color Hex Code") },
                    singleLine = true,
                    leadingIcon = {
                        val colorVal = try { Color(android.graphics.Color.parseColor(customSupportHexInput)) } catch (e: Exception) { Color(0xFFF59E0B) }
                        Box(modifier = Modifier.size(20.dp).clip(CircleShape).background(colorVal))
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))
                Text("Quick Preset Palette:", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(presetColors) { (hex, label) ->
                        val c = try { Color(android.graphics.Color.parseColor(hex)) } catch (e: Exception) { PrimaryPink }
                        Surface(
                            onClick = {
                                customPrimaryHexInput = hex
                                customChatHexInput = hex
                            },
                            shape = RoundedCornerShape(10.dp),
                            color = c.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, c)
                        ) {
                            Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(c))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    mainViewModel.updateAppStylingAndColors(
                        primaryHex = customPrimaryHexInput,
                        headerBgHex = "#F0F9FF",
                        textHex = "#0F172A",
                        logoHex = customPrimaryHexInput,
                        supportCallHex = customCallHexInput
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Apply & Save All Colors", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalPromptSettingsDialog(
    mainViewModel: MainViewModel,
    aiViewModel: AiViewModel,
    onDismiss: () -> Unit
) {
    var promptInput by remember { mutableStateOf("") }
    var promptStatusNotice by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("⚡ Digital Prompt & Platform AI Settings", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Type any natural prompt command to enable/configure digital platform settings at any time:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                OutlinedTextField(
                    value = promptInput,
                    onValueChange = { promptInput = it },
                    placeholder = { Text("e.g. 'Enable self checkout, set chat color to blue, rename header to Super Laundry Clean'") },
                    modifier = Modifier.fillMaxWidth().height(100.dp),
                    maxLines = 4
                )

                Button(
                    onClick = {
                        val p = promptInput.lowercase()
                        var executedCount = 0
                        if (p.contains("chat")) { mainViewModel.toggleFeature("in_app_chat", true); executedCount++ }
                        if (p.contains("call") || p.contains("phone")) { mainViewModel.toggleFeature("direct_call", true); executedCount++ }
                        if (p.contains("checkout") || p.contains("pay")) { mainViewModel.toggleFeature("self_checkout", true); executedCount++ }
                        if (p.contains("rate card")) { mainViewModel.toggleFeature("rate_card_manager", true); executedCount++ }
                        if (p.contains("tracking")) { mainViewModel.toggleFeature("order_tracking", true); executedCount++ }
                        if (p.contains("ai")) { aiViewModel.toggleAi(true); executedCount++ }

                        promptStatusNotice = "✅ Processed $executedCount digital settings successfully via AI prompt!"
                        promptInput = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Execute Digital Settings Prompt", fontWeight = FontWeight.Bold)
                }

                if (promptStatusNotice != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AccentGreen.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            promptStatusNotice!!,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentGreen,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)) {
                Text("Done", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionManagerDialog(
    mainViewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val plans by mainViewModel.subscriptionPlans.collectAsState()
    var selectedPlanId by remember { mutableStateOf("MONTHLY") }
    var customPriceInput by remember { mutableStateOf("999") }
    var isFreeChecked by remember { mutableStateOf(false) }
    var statusNotice by remember { mutableStateOf<String?>(null) }

    val currentPlan = plans.find { it.planId == selectedPlanId } ?: plans.first()

    LaunchedEffect(selectedPlanId) {
        val p = plans.find { it.planId == selectedPlanId }
        if (p != null) {
            customPriceInput = p.priceRupees.toString()
            isFreeChecked = p.isFree
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CardMembership, contentDescription = null, tint = PrimaryPink)
                Spacer(modifier = Modifier.width(8.dp))
                Text("💳 Subscription Plan & Price Control", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Super Admin and Laundry Admins can edit plan prices, set preferred rates, or make subscription plans completely FREE (₹0). Any change applies platform-wide.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                Text("1. Select Plan to Edit:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                plans.forEach { plan ->
                    Surface(
                        onClick = {
                            selectedPlanId = plan.planId
                            customPriceInput = plan.priceRupees.toString()
                            isFreeChecked = plan.isFree
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedPlanId == plan.planId) PrimaryPink.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (selectedPlanId == plan.planId) androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryPink) else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(plan.title, fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("${plan.durationMonths} Months Duration", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                            if (plan.isFree) {
                                Surface(shape = RoundedCornerShape(6.dp), color = AccentGreen) {
                                    Text("FREE (₹0)", modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            } else {
                                Text("₹${plan.priceRupees}", fontWeight = FontWeight.Black, color = PrimaryPink, style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 4.dp))

                Text("2. Price & Rate Settings for ${currentPlan.title}:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Make Plan Completely FREE (₹0)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Color.Black)
                        Text("Set price to 0 Rupees for all laundry admins & customers", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Switch(
                        checked = isFreeChecked,
                        onCheckedChange = {
                            isFreeChecked = it
                            if (it) customPriceInput = "0"
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = PrimaryPink)
                    )
                }

                if (!isFreeChecked) {
                    OutlinedTextField(
                        value = customPriceInput,
                        onValueChange = { customPriceInput = it },
                        label = { Text("Preferred Plan Price (Rupees ₹)") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.CurrencyRupee, contentDescription = null, tint = PrimaryPink) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Quick Price Presets:", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("1" to "₹1 Trial", "99" to "₹99 Offer", "299" to "₹299 Saver", "999" to "₹999 Regular").forEach { (price, label) ->
                            OutlinedButton(
                                onClick = {
                                    customPriceInput = price
                                    isFreeChecked = false
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
                            ) {
                                Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (statusNotice != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AccentGreen.copy(alpha = 0.15f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            statusNotice!!,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentGreen,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val priceVal = customPriceInput.toIntOrNull() ?: 0
                    mainViewModel.updateSubscriptionPlanPrice(
                        planId = selectedPlanId,
                        newPrice = if (isFreeChecked) 0 else priceVal,
                        isFree = isFreeChecked
                    )
                    statusNotice = "✅ Subscription ${currentPlan.title} price updated to ${if (isFreeChecked) "FREE (₹0)" else "₹$priceVal"} across platform!"
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save & Apply Price Change", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}


