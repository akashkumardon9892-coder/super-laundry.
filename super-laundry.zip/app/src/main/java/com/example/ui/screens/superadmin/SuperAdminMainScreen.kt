package com.example.ui.screens.superadmin

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AiViewModel
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuperAdminMainScreen(
    mainViewModel: MainViewModel,
    aiViewModel: AiViewModel,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dashboardType by mainViewModel.superAdminDashboardType.collectAsState()
    val shops by mainViewModel.allShops.collectAsState()
    val orders by mainViewModel.allOrders.collectAsState()
    val subscriptions by mainViewModel.allSubscriptions.collectAsState()
    val tickets by mainViewModel.allTickets.collectAsState()
    val banners by mainViewModel.allBanners.collectAsState()
    val staters by mainViewModel.allStaters.collectAsState()
    val registeredPhone by mainViewModel.registeredSuperAdminPhone.collectAsState()

    val flagshipShop = shops.firstOrNull { it.id == "shop_flagship" } ?: shops.firstOrNull()
    val flagshipRateCard by mainViewModel.getRateCardForShop(flagshipShop?.id ?: "shop_flagship").collectAsState(initial = emptyList())

    // App Control Settings collected state
    val appName by mainViewModel.appName.collectAsState()
    val appLogoUrl by mainViewModel.appLogoUrl.collectAsState()
    val appBackgroundUrl by mainViewModel.appBackgroundUrl.collectAsState()
    val isOrderTrackingEnabled by mainViewModel.isOrderTrackingEnabled.collectAsState()
    val isDirectCallEnabled by mainViewModel.isDirectCallEnabled.collectAsState()
    val isInAppChatEnabled by mainViewModel.isInAppChatEnabled.collectAsState()
    val isRateCardManagerEnabled by mainViewModel.isRateCardManagerEnabled.collectAsState()
    val isCouponsOffersEnabled by mainViewModel.isCouponsOffersEnabled.collectAsState()
    val isSelfCheckoutEnabled by mainViewModel.isSelfCheckoutEnabled.collectAsState()

    // Dynamic Platform Controls & Custom Rules States
    val isByWeightKiloPricingEnabled by mainViewModel.isByWeightKiloPricingEnabled.collectAsState()
    val isStaterVideoStoriesEnabled by mainViewModel.isStaterVideoStoriesEnabled.collectAsState()
    val isShoeSpaCareEnabled by mainViewModel.isShoeSpaCareEnabled.collectAsState()
    val isExpress2HourDeliveryEnabled by mainViewModel.isExpress2HourDeliveryEnabled.collectAsState()
    val isClothRentalServiceEnabled by mainViewModel.isClothRentalServiceEnabled.collectAsState()
    val dynamicPlatformRules by mainViewModel.dynamicPlatformRules.collectAsState()
    val dynamicAppTools by mainViewModel.dynamicAppTools.collectAsState()

    val appDirection by mainViewModel.appDirection.collectAsState()
    val aiAccessScope by mainViewModel.aiAccessScope.collectAsState()
    val aiStrictTaskEnforcement by mainViewModel.aiStrictTaskEnforcement.collectAsState()
    val aiEnabled by aiViewModel.aiEnabled.collectAsState()
    val superAdminLang by mainViewModel.superAdminLanguage.collectAsState()

    val speechLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                aiViewModel.processQuery(spoken, UserRole.SUPER_ADMIN, registeredPhone, "Super Admin")
            }
        }
    }

    fun launchVoiceRecognizer() {
        val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, if (superAdminLang.contains("Hindi") || superAdminLang.contains("हिंदी")) "hi-IN" else if (superAdminLang.contains("Marathi") || superAdminLang.contains("मराठी")) "mr-IN" else "en-IN")
            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, mainViewModel.getTr("सुपर एडमिन बोलिए...", "Speak your command...", "सुपर ॲडमिन बोला...", UserRole.SUPER_ADMIN))
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            aiViewModel.speak("Speech recognition is not available. Please type your query.")
        }
    }

    var activeTab by remember { mutableStateOf("Overview") }
    var storeActiveTab by remember { mutableStateOf("Live Orders") }
    var superAdminCategoryFilter by remember { mutableStateOf<ServiceCategory?>(null) }
    var showVoiceAiSheet by remember { mutableStateOf(false) }
    var showAiChatSheet by remember { mutableStateOf(false) }
    var showSupportChatSheet by remember { mutableStateOf(false) }
    var showSecuritySettingsSheet by remember { mutableStateOf(false) }
    var showLaundryAdminSettingsSheet by remember { mutableStateOf(false) }
    var showAddStaterDialog by remember { mutableStateOf(false) }
    var activeViewerStater by remember { mutableStateOf<StaterUpdate?>(null) }

    // Dynamic Platform Control Dialogs & Input States
    var showAddRuleDialog by remember { mutableStateOf(false) }
    var showAiPromptToolDialog by remember { mutableStateOf(false) }
    var aiToolPromptInput by remember { mutableStateOf("") }
    var aiToolNameInput by remember { mutableStateOf("") }
    var aiToolDescInput by remember { mutableStateOf("") }
    var aiToolCategoryInput by remember { mutableStateOf("New Laundry Service") }

    var ruleTitleInput by remember { mutableStateOf("") }
    var ruleDescInput by remember { mutableStateOf("") }
    var ruleCategoryInput by remember { mutableStateOf("Pricing & Operational Niyam") }

    var showEditPriceModal by remember { mutableStateOf<RateCardItem?>(null) }
    var newPriceInput by remember { mutableStateOf("") }
    var editItemNameInput by remember { mutableStateOf("") }
    var editItemPhotoInput by remember { mutableStateOf("") }
    var newItemPhotoInput by remember { mutableStateOf("https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80") }

    LaunchedEffect(showEditPriceModal) {
        showEditPriceModal?.let {
            newPriceInput = it.price.toInt().toString()
            editItemNameInput = it.clothName
            editItemPhotoInput = it.photoUrl
        }
    }

    val superAdminGalleryLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            editItemPhotoInput = uri.toString()
            newItemPhotoInput = uri.toString()
        }
    }

    val superAdminCameraLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            val sampleCameraPhoto = "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=600&q=80"
            editItemPhotoInput = sampleCameraPhoto
            newItemPhotoInput = sampleCameraPhoto
        }
    }
    var showAddNewItemSheet by remember { mutableStateOf(false) }
    var newItemNameInput by remember { mutableStateOf("") }
    var newItemCategoryInput by remember { mutableStateOf(ServiceCategory.IRONING) }
    var newItemPriceInput by remember { mutableStateOf("") }
    var newSuperAdminPhoneInput by remember { mutableStateOf("") }
    var showAdminCallModal by remember { mutableStateOf<Pair<String, String>?>(null) }
    var selectedOrderTab by remember { mutableStateOf("New Orders") }
    var callingCustomer by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showCustomerChatSheet by remember { mutableStateOf<Order?>(null) }
    var selectedCustomerForHistory by remember { mutableStateOf<Order?>(null) }
    var superAdminChatMessageInput by remember { mutableStateOf("") }
    var aiQueryInput by remember { mutableStateOf("") }

    val chatMessages by aiViewModel.chatMessages.collectAsState()
    val isSpeaking by aiViewModel.isSpeaking.collectAsState()

    // Settings input fields
    var editAppNameInput by remember(appName) { mutableStateOf(appName) }
    var editAppLogoInput by remember(appLogoUrl) { mutableStateOf(appLogoUrl) }
    var editAppBgInput by remember(appBackgroundUrl) { mutableStateOf(appBackgroundUrl) }

    // Interactive Settings Dialogs
    var showLogoBannerDialog by remember { mutableStateOf(false) }
    var showProfileDetailsDialog by remember { mutableStateOf(false) }
    var showTimingAreaDialog by remember { mutableStateOf(false) }
    var showOffersDialog by remember { mutableStateOf(false) }
    var showLanguageThemeDialog by remember { mutableStateOf(false) }
    var showAppBrandingDialog by remember { mutableStateOf(false) }
    var showFutureFeatureDialog by remember { mutableStateOf(false) }
    var showAiAdvancedSettingsDialog by remember { mutableStateOf(false) }
    var showSubscriptionManagerDialog by remember { mutableStateOf(false) }
    var showBroadcastNotificationDialog by remember { mutableStateOf(false) }
    var showUiLabelManagerDialog by remember { mutableStateOf(false) }
    var showColorSettingsDialog by remember { mutableStateOf(false) }
    var showDigitalPromptSettingsDialog by remember { mutableStateOf(false) }
    var settingsToastMessage by remember { mutableStateOf<String?>(null) }

    // Module CRUD Dialog & Filter States
    var showAddLaundryDialog by remember { mutableStateOf(false) }
    var addLaundryNameInput by remember { mutableStateOf("") }
    var addLaundryPhoneInput by remember { mutableStateOf("") }
    var addLaundryAddressInput by remember { mutableStateOf("") }
    var addLaundryRadiusInput by remember { mutableStateOf("5") }
    var addLaundryLogoInput by remember { mutableStateOf("https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=200&q=80") }
    var editingShop by remember { mutableStateOf<LaundryShop?>(null) }

    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var addCustNameInput by remember { mutableStateOf("") }
    var addCustPhoneInput by remember { mutableStateOf("") }
    var addCustAddressInput by remember { mutableStateOf("") }
    var customerSearchQuery by remember { mutableStateOf("") }
    var editingCustomerProfile by remember { mutableStateOf<Order?>(null) }

    var reportsTimeframe by remember { mutableStateOf("Monthly") }

    var supportReplyTicket by remember { mutableStateOf<SupportTicket?>(null) }
    var ticketReplyText by remember { mutableStateOf("") }
    var ticketNewStatus by remember { mutableStateOf(TicketStatus.IN_PROGRESS) }

    val aiUiAction by aiViewModel.uiActionTrigger.collectAsState()
    LaunchedEffect(aiUiAction) {
        when (aiUiAction) {
            is com.example.ui.viewmodel.AiUiAction.OpenDashboard -> {
                activeTab = "Overview"
                storeActiveTab = "Live Orders"
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenOrders -> {
                activeTab = "Laundries"
                storeActiveTab = "Live Orders"
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenCustomers -> {
                activeTab = "Customers"
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenReports -> {
                activeTab = "Reports"
                storeActiveTab = "Financial Reports"
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenSettings -> {
                activeTab = "App Control Settings"
                showLaundryAdminSettingsSheet = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenSubscriptionManager -> {
                showSubscriptionManagerDialog = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenLanguageSelector -> {
                showLanguageThemeDialog = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenAiVoiceSettings -> {
                showAiAdvancedSettingsDialog = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenColorSettings -> {
                showAppBrandingDialog = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenFutureFeatures -> {
                showFutureFeatureDialog = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.SetLanguage -> {
                val lang = (aiUiAction as com.example.ui.viewmodel.AiUiAction.SetLanguage).lang
                mainViewModel.updateAppLanguage(lang, UserRole.SUPER_ADMIN)
                aiViewModel.setAiLanguage(lang)
                aiViewModel.clearUiAction()
            }
            else -> {}
        }
    }

    var editShopLogoInput by remember { mutableStateOf("") }
    var editShopBannerInput by remember { mutableStateOf("") }
    var editShopNameInput by remember { mutableStateOf("") }
    var editShopPhoneInput by remember { mutableStateOf("") }
    var editShopAddressInput by remember { mutableStateOf("") }
    var editShopDescInput by remember { mutableStateOf("") }
    var editShopTimingInput by remember { mutableStateOf("") }
    var editShopRadiusInput by remember { mutableStateOf("") }
    var editShopIsOpenInput by remember { mutableStateOf(true) }

    // Customer Counts
    val totalPlatformCustomersCount = 1248 // Visible total across all laundries
    val superLaundryStoreCustomersCount = 365 // Visible count for Super Laundry Drive Cleaners flagship store

    Scaffold(
        topBar = {
            SleekTopBar(
                title = if (dashboardType == SuperAdminDashboardType.PLATFORM_CONTROL) mainViewModel.getTr("प्लेटफॉर्म कंट्रोल (Super Admin)", "Platform Control", "प्लॅटफॉर्म नियंत्रण", UserRole.SUPER_ADMIN) else mainViewModel.getTr("सुपर लॉन्ड्री ड्राई क्लीनर्स", "Super Laundry Drive Cleaners", "सुपर लॉन्ड्री ड्राय क्लीनर्स", UserRole.SUPER_ADMIN),
                subtitle = if (dashboardType == SuperAdminDashboardType.PLATFORM_CONTROL) mainViewModel.getTr("सुपर एडमिन प्लेटफॉर्म", "Super Admin Platform", "सुपर ॲडमिन प्लॅटफॉर्म", UserRole.SUPER_ADMIN) else mainViewModel.getTr("फ्लैगशिप स्टोर (Super Laundry)", "Own Flagship Store", "फ्लॅगशिप स्टोअर", UserRole.SUPER_ADMIN),
                roleBadge = if (dashboardType == SuperAdminDashboardType.PLATFORM_CONTROL) mainViewModel.getTr("स्टोर पर जाएं", "Switch to Store", "स्टोअरवर जा", UserRole.SUPER_ADMIN) else mainViewModel.getTr("कंट्रोल पर जाएं", "Switch to Control", "कंट्रोलवर जा", UserRole.SUPER_ADMIN),
                onRoleSwitchClick = { mainViewModel.switchSuperAdminDashboard() },
                onProfileClick = {
                    if (dashboardType == SuperAdminDashboardType.PLATFORM_CONTROL) {
                        showSecuritySettingsSheet = true
                    } else {
                        showLaundryAdminSettingsSheet = true
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Dashboard Switcher Pill Button
                    Button(
                        onClick = { mainViewModel.switchSuperAdminDashboard() },
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                        modifier = Modifier.testTag("switch_dashboard_bottom_button")
                    ) {
                        Icon(Icons.Default.SyncAlt, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (dashboardType == SuperAdminDashboardType.PLATFORM_CONTROL) mainViewModel.getTr("सुपर लॉन्ड्री स्टोर", "Super Laundry Store", "सुपर लॉन्ड्री स्टोअर", UserRole.SUPER_ADMIN) else mainViewModel.getTr("प्लेटफॉर्म एडमिन", "Platform Admin", "प्लॅटफॉर्म ॲडमिन", UserRole.SUPER_ADMIN),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Voice AI Mic Action Button
                    IconButton(
                        onClick = { showVoiceAiSheet = true },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(IndigoGradientStart)
                            .testTag("voice_ai_mic_button")
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Voice AI", tint = Color.White)
                    }

                    // AI Chat Action
                    IconButton(
                        onClick = { showAiChatSheet = true },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .testTag("ai_chat_button")
                    ) {
                        Icon(Icons.Outlined.AutoAwesome, contentDescription = "AI Chat", tint = PrimaryPink)
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (dashboardType == SuperAdminDashboardType.PLATFORM_CONTROL) {
                // DASHBOARD 1: PLATFORM CONTROL (Super Admin)
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // AI Namaste Super Laundry Greeting Card
                    item {
                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryBlue.copy(alpha = 0.25f)),
                            shadowElevation = 2.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                    .background(PrimaryBlue.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("🙏", fontSize = 24.sp)
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = mainViewModel.tr("namaste", UserRole.SUPER_ADMIN),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Black,
                                        color = Color.Black
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = mainViewModel.tr("greeting_sub", UserRole.SUPER_ADMIN),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.Black.copy(alpha = 0.75f)
                                    )
                                }
                            }
                        }
                    }

                    // Staters / Video Stories Bar for Super Admin & Laundry Admins
                    item {
                        StaterStoryBar(
                            staters = staters,
                            currentRole = UserRole.SUPER_ADMIN,
                            currentUserPhone = registeredPhone,
                            onAddStaterClick = { showAddStaterDialog = true },
                            onStaterClick = { selectedStater -> activeViewerStater = selectedStater }
                        )
                    }

                    item {
                        SleekGradientHeaderCard(
                            mainAmount = "₹1,45,800.00",
                            amountLabel = "Platform Total Revenue",
                            growthTag = "+18.2% ↑",
                            stat1Label = "Active Laundries",
                            stat1Value = "${shops.size} Shops",
                            stat2Label = "Subscriptions",
                            stat2Value = "${subscriptions.filter { it.isActive }.size} Active",
                            stat3Label = "Total Customers",
                            stat3Value = "$totalPlatformCustomersCount Total"
                        )
                    }

                    // Prominent AI Settings / AI Control Center Banner
                    item {
                        Surface(
                            onClick = { showAiAdvancedSettingsDialog = true },
                            shape = RoundedCornerShape(20.dp),
                            color = PrimaryPink.copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryPink),
                            modifier = Modifier.fillMaxWidth().testTag("open_ai_control_center_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(PrimaryPink),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Psychology, contentDescription = null, tint = Color.White)
                                    }

                                    Column {
                                        Text("🤖 AI Settings / AI Control Center", fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.titleMedium)
                                        Text("Hindi Mode • Voice Settings • Module Permissions • Activity Logs", style = MaterialTheme.typography.labelSmall, color = Color.DarkGray)
                                    }
                                }

                                Button(
                                    onClick = { showAiAdvancedSettingsDialog = true },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                                ) {
                                    Text("Open", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Quick Action Category Grid
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            SleekQuickActionButton(
                                icon = Icons.Outlined.Store,
                                label = "Laundries",
                                onClick = { activeTab = "Laundries" }
                            )
                            SleekQuickActionButton(
                                icon = Icons.Outlined.Group,
                                label = "Customers",
                                onClick = { activeTab = "Customers" }
                            )
                            SleekQuickActionButton(
                                icon = Icons.Outlined.CardMembership,
                                label = "Plans",
                                onClick = { activeTab = "Subscriptions" }
                            )
                            SleekQuickActionButton(
                                icon = Icons.Outlined.Analytics,
                                label = "Reports",
                                onClick = { activeTab = "Reports" }
                            )
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            SleekQuickActionButton(
                                icon = Icons.Outlined.BuildCircle,
                                label = "Platform Control",
                                onClick = { activeTab = "Platform Control" }
                            )
                            SleekQuickActionButton(
                                icon = Icons.Outlined.Campaign,
                                label = "Ads & Banners",
                                onClick = { activeTab = "Ads" }
                            )
                            SleekQuickActionButton(
                                icon = Icons.Outlined.SettingsSuggest,
                                label = "App Settings",
                                onClick = { activeTab = "App Control Settings" }
                            )
                            SleekQuickActionButton(
                                icon = Icons.Outlined.SupportAgent,
                                label = "Support",
                                onClick = { activeTab = "Support" },
                                badgeCount = tickets.filter { it.status == TicketStatus.OPEN }.size
                            )
                        }
                    }

                    // Dynamic Tab Section
                    item {
                        Surface(
                            shape = RoundedCornerShape(28.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(
                                    text = activeTab,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                when (activeTab) {
                                    "Platform Control" -> {
                                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                            // Banner: Platform Control Header
                                            Surface(
                                                shape = RoundedCornerShape(20.dp),
                                                color = IndigoGradientStart,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                                        Icon(Icons.Default.BuildCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                                                        Column {
                                                            Text("🛠️ Platform Control & AI Prompt Studio", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                                                            Text("Dynamically add options, enable/disable features, set new rules & generate tools via AI prompts", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
                                                        }
                                                    }
                                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        Button(
                                                            onClick = { showAiPromptToolDialog = true },
                                                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                            shape = RoundedCornerShape(12.dp),
                                                            modifier = Modifier.weight(1f)
                                                        ) {
                                                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("AI Tool Generator", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                                        }

                                                        Button(
                                                            onClick = { showAddRuleDialog = true },
                                                            colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                                                            shape = RoundedCornerShape(12.dp),
                                                            modifier = Modifier.weight(1f)
                                                        ) {
                                                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("+ Add Niyam/Rule", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                                        }
                                                    }
                                                }
                                            }

                                            // Section 1: Dynamic Option & Feature Toggles (Badhana / Band Karna)
                                            Surface(
                                                shape = RoundedCornerShape(20.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                                    Text("🎛️ Platform Options & Feature Toggles (Badhana / Band Karna)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)

                                                    val dynamicOptions = listOf(
                                                        Triple("⚖️ Per-Kg Cloth Pricing (Kilo Rate Wash & Press)", "Allow laundry shops to accept clothes by weight in Kilograms", isByWeightKiloPricingEnabled to { b: Boolean -> mainViewModel.toggleByWeightKiloPricing(b) }),
                                                        Triple("📹 Live Laundry Stater Video Stories & Shorts", "Enable 15-second status videos for laundry shops & super admin", isStaterVideoStoriesEnabled to { b: Boolean -> mainViewModel.toggleStaterVideoStories(b) }),
                                                        Triple("👟 Shoe Spa & Leather Bag Restoration Care", "Specialized dry cleaning module for formal shoes, sneakers & bags", isShoeSpaCareEnabled to { b: Boolean -> mainViewModel.toggleShoeSpaCare(b) }),
                                                        Triple("⚡ 2-Hour Super Express Emergency Processing", "Enable express 2-hour priority delivery option across all shops", isExpress2HourDeliveryEnabled to { b: Boolean -> mainViewModel.toggleExpress2HourDelivery(b) }),
                                                        Triple("🧥 Festival Cloth Rental & Formal Suit Pass", "Allow customers to rent wedding clothes & suit passes from shops", isClothRentalServiceEnabled to { b: Boolean -> mainViewModel.toggleClothRentalService(b) }),
                                                        Triple("📦 Order Live GPS Route Tracking", "Show live delivery driver map and tracking status to customers", isOrderTrackingEnabled to { b: Boolean -> mainViewModel.toggleFeature("order_tracking", b) }),
                                                        Triple("📞 Direct Customer & Laundry Phone Calls", "Enable one-tap phone call connection between customer & shop", isDirectCallEnabled to { b: Boolean -> mainViewModel.toggleFeature("direct_call", b) }),
                                                        Triple("🎟️ Dynamic Coupons & Offers Engine", "Enable super admin & shop discount codes, banners & cashback", isCouponsOffersEnabled to { b: Boolean -> mainViewModel.toggleFeature("coupons_offers", b) })
                                                    )

                                                    dynamicOptions.forEach { (title, desc, stateAndToggle) ->
                                                        val (state, toggleAction) = stateAndToggle
                                                        Surface(
                                                            shape = RoundedCornerShape(14.dp),
                                                            color = Color.White,
                                                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                                                        ) {
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                                                    Text(title, fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.bodyMedium)
                                                                    Text(desc, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                                                }
                                                                Switch(
                                                                    checked = state,
                                                                    onCheckedChange = { toggleAction(it) },
                                                                    colors = SwitchDefaults.colors(checkedThumbColor = PrimaryPink)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            // Section 2: AI Generated Dynamic Tools (Super Admin Prompts)
                                            Surface(
                                                shape = RoundedCornerShape(20.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column {
                                                            Text("🤖 AI Generated Tools & Capabilities", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                                            Text("Created via Super Admin AI prompts", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                                        }
                                                        IconButton(
                                                            onClick = { showAiPromptToolDialog = true },
                                                            modifier = Modifier.size(36.dp).clip(CircleShape).background(PrimaryPink)
                                                        ) {
                                                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                                                        }
                                                    }

                                                    if (dynamicAppTools.isEmpty()) {
                                                        Text("No AI tools added yet. Click 'AI Tool Generator' to create one!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                                    } else {
                                                        dynamicAppTools.forEach { tool ->
                                                            Surface(
                                                                shape = RoundedCornerShape(14.dp),
                                                                color = Color.White,
                                                                modifier = Modifier.fillMaxWidth()
                                                            ) {
                                                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                                    Row(
                                                                        modifier = Modifier.fillMaxWidth(),
                                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                                        verticalAlignment = Alignment.CenterVertically
                                                                    ) {
                                                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                                            Surface(shape = RoundedCornerShape(8.dp), color = PrimaryPink.copy(alpha = 0.15f)) {
                                                                                Text(tool.toolCategory, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall, color = PrimaryPink, fontWeight = FontWeight.Bold)
                                                                            }
                                                                            Text(tool.name, fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.titleSmall)
                                                                        }
                                                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                                                            Switch(
                                                                                checked = tool.isEnabled,
                                                                                onCheckedChange = { mainViewModel.toggleDynamicAppTool(tool.id) },
                                                                                colors = SwitchDefaults.colors(checkedThumbColor = PrimaryPink)
                                                                            )
                                                                            IconButton(onClick = { mainViewModel.deleteDynamicAppTool(tool.id) }) {
                                                                                Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Red, modifier = Modifier.size(18.dp))
                                                                            }
                                                                        }
                                                                    }
                                                                    Text(tool.description, style = MaterialTheme.typography.bodyMedium, color = Color.DarkGray)
                                                                    Text("💬 Prompt: \"${tool.promptUsed}\"", style = MaterialTheme.typography.labelSmall, color = PrimaryBlue, fontWeight = FontWeight.Medium)
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            // Section 3: Platform Rules & Policy Niyam Manager
                                            Surface(
                                                shape = RoundedCornerShape(20.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column {
                                                            Text("📜 Platform Rules & Policy Niyam", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                                            Text("App-wide operational guidelines & policies", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                                        }
                                                        Button(
                                                            onClick = { showAddRuleDialog = true },
                                                            colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                                                            shape = RoundedCornerShape(10.dp)
                                                        ) {
                                                            Text("+ Add Niyam", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                                        }
                                                    }

                                                    if (dynamicPlatformRules.isEmpty()) {
                                                        Text("No platform rules active.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                                    } else {
                                                        dynamicPlatformRules.forEach { rule ->
                                                            Surface(
                                                                shape = RoundedCornerShape(14.dp),
                                                                color = Color.White,
                                                                modifier = Modifier.fillMaxWidth()
                                                            ) {
                                                                Row(
                                                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                                    verticalAlignment = Alignment.CenterVertically
                                                                ) {
                                                                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                                            Surface(shape = RoundedCornerShape(6.dp), color = AccentGreen.copy(alpha = 0.15f)) {
                                                                                Text(rule.ruleCategory, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall, color = AccentGreen, fontWeight = FontWeight.Bold)
                                                                            }
                                                                            Text(rule.title, fontWeight = FontWeight.Bold, color = Color.Black)
                                                                        }
                                                                        Text(rule.description, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                                                    }
                                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                                        Switch(
                                                                            checked = rule.isEnabled,
                                                                            onCheckedChange = { mainViewModel.toggleDynamicPlatformRule(rule.id) },
                                                                            colors = SwitchDefaults.colors(checkedThumbColor = AccentGreen)
                                                                        )
                                                                        IconButton(onClick = { mainViewModel.deleteDynamicPlatformRule(rule.id) }) {
                                                                            Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Red, modifier = Modifier.size(18.dp))
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    "App Control Settings" -> {
                                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                            // Card 1: App Branding & Logo Control
                                            Surface(
                                                shape = RoundedCornerShape(20.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Text("App Logo, Branding & Thumbnail Control", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                                    OutlinedTextField(
                                                        value = editAppNameInput,
                                                        onValueChange = { editAppNameInput = it },
                                                        label = { Text("App Name") },
                                                        singleLine = true,
                                                        modifier = Modifier.fillMaxWidth()
                                                    )
                                                    OutlinedTextField(
                                                        value = editAppLogoInput,
                                                        onValueChange = { editAppLogoInput = it },
                                                        label = { Text("App Logo / Thumbnail Image URL") },
                                                        singleLine = true,
                                                        modifier = Modifier.fillMaxWidth()
                                                    )
                                                    OutlinedTextField(
                                                        value = editAppBgInput,
                                                        onValueChange = { editAppBgInput = it },
                                                        label = { Text("App Background Image URL") },
                                                        singleLine = true,
                                                        modifier = Modifier.fillMaxWidth()
                                                    )
                                                    Button(
                                                        onClick = {
                                                            mainViewModel.updateAppBranding(editAppNameInput, editAppLogoInput, editAppBgInput)
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Icon(Icons.Default.Save, contentDescription = null, tint = Color.White)
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text("Save Logo & Branding Changes", color = Color.White, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }

                                            // Card 2: Feature Toggles (Each Feature Separated)
                                            Surface(
                                                shape = RoundedCornerShape(20.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                                    Text("Separated Feature Control Toggles", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)

                                                    val features = listOf(
                                                        Triple("Order Tracking & Live Status", "order_tracking", isOrderTrackingEnabled),
                                                        Triple("Direct Customer Phone Calling", "direct_call", isDirectCallEnabled),
                                                        Triple("In-App Chat Messaging", "in_app_chat", isInAppChatEnabled),
                                                        Triple("Rate Card Price Manager", "rate_card_manager", isRateCardManagerEnabled),
                                                        Triple("Offers, Coupons & Banners", "coupons_offers", isCouponsOffersEnabled),
                                                        Triple("Customer Self-Checkout", "self_checkout", isSelfCheckoutEnabled)
                                                    )

                                                    features.forEach { (title, key, state) ->
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Text(title, fontWeight = FontWeight.SemiBold, color = Color.Black)
                                                            Switch(
                                                                checked = state,
                                                                onCheckedChange = { mainViewModel.toggleFeature(key, it) },
                                                                colors = SwitchDefaults.colors(checkedThumbColor = PrimaryPink, checkedTrackColor = PrimaryPink.copy(alpha = 0.3f))
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            // Card 3: App Direction & Layout Settings
                                            Surface(
                                                shape = RoundedCornerShape(20.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Text("App Direction & Layout Configuration", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text("Layout Reading Direction", fontWeight = FontWeight.SemiBold, color = Color.Black)
                                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                            FilterChip(
                                                                selected = appDirection == "LTR",
                                                                onClick = { mainViewModel.updateAppDirection("LTR") },
                                                                label = { Text("LTR") }
                                                            )
                                                            FilterChip(
                                                                selected = appDirection == "RTL",
                                                                onClick = { mainViewModel.updateAppDirection("RTL") },
                                                                label = { Text("RTL") }
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            // Card 4: AI Control System & Admin Allocation
                                            Surface(
                                                shape = RoundedCornerShape(20.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                                    Text("AI Control & Admin AI Allocation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)

                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text("Global AI Assistant Switch", fontWeight = FontWeight.SemiBold, color = Color.Black)
                                                        Switch(
                                                            checked = aiEnabled,
                                                            onCheckedChange = { aiViewModel.toggleAi(it) },
                                                            colors = SwitchDefaults.colors(checkedThumbColor = PrimaryPink)
                                                        )
                                                    }

                                                    Text("Give AI to Admins:", fontWeight = FontWeight.SemiBold, color = Color.Black)
                                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        FilterChip(
                                                            selected = aiAccessScope == "All Laundry Admins",
                                                            onClick = { mainViewModel.updateAiAccessScope("All Laundry Admins") },
                                                            label = { Text("All Admins") }
                                                        )
                                                        FilterChip(
                                                            selected = aiAccessScope == "Flagship Only",
                                                            onClick = { mainViewModel.updateAiAccessScope("Flagship Only") },
                                                            label = { Text("Flagship Only") }
                                                        )
                                                        FilterChip(
                                                            selected = aiAccessScope == "Disabled",
                                                            onClick = { mainViewModel.updateAiAccessScope("Disabled") },
                                                            label = { Text("Disable") }
                                                        )
                                                    }

                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text("Strict Task Questions Only", fontWeight = FontWeight.SemiBold, color = Color.Black)
                                                        Switch(
                                                            checked = aiStrictTaskEnforcement,
                                                            onCheckedChange = { mainViewModel.toggleAiStrictEnforcement(it) },
                                                            colors = SwitchDefaults.colors(checkedThumbColor = PrimaryPink)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    "Customers" -> {
                                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                            Surface(
                                                shape = RoundedCornerShape(16.dp),
                                                color = PrimaryPink.copy(alpha = 0.12f),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(16.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Column {
                                                        Text("Total Platform Customers", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                                        Text("Manage & View All Verified Customers", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.7f))
                                                    }
                                                    Button(
                                                        onClick = { showAddCustomerDialog = true },
                                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                        shape = RoundedCornerShape(12.dp)
                                                    ) {
                                                        Icon(Icons.Default.PersonAdd, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Add Customer", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                                    }
                                                }
                                            }

                                            OutlinedTextField(
                                                value = customerSearchQuery,
                                                onValueChange = { customerSearchQuery = it },
                                                placeholder = { Text("Search customer by name or phone...") },
                                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = PrimaryPink) },
                                                modifier = Modifier.fillMaxWidth(),
                                                singleLine = true,
                                                shape = RoundedCornerShape(14.dp)
                                            )

                                            val filteredOrders = orders.filter {
                                                it.customerName.contains(customerSearchQuery, ignoreCase = true) ||
                                                it.customerPhone.contains(customerSearchQuery)
                                            }

                                            if (filteredOrders.isEmpty()) {
                                                Surface(
                                                    shape = RoundedCornerShape(14.dp),
                                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                                                        Text("No customers matching '$customerSearchQuery'. Click 'Add Customer' above to create one!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                                    }
                                                }
                                            } else {
                                                filteredOrders.distinctBy { it.customerPhone }.forEach { custOrd ->
                                                    val isLongTerm = custOrd.isLongTermOrder || custOrd.itemsSummary.contains("Long-Term", ignoreCase = true) || custOrd.itemsSummary.contains("Pass", ignoreCase = true)
                                                    Surface(
                                                        shape = RoundedCornerShape(16.dp),
                                                        color = if (isLongTerm) PrimaryPink.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant,
                                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isLongTerm) PrimaryPink else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Column {
                                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                                        Text(custOrd.customerName, fontWeight = FontWeight.Bold, color = Color.Black)
                                                                        if (isLongTerm) {
                                                                            Surface(shape = RoundedCornerShape(6.dp), color = PrimaryPink) {
                                                                                Text("★ LONG-TERM PASS", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                                            }
                                                                        }
                                                                    }
                                                                    Text("Phone: ${custOrd.customerPhone} • ${custOrd.deliveryAddress}", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.7f))
                                                                }
                                                                IconButton(onClick = { mainViewModel.deleteOrder(custOrd.id) }) {
                                                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.7f))
                                                                }
                                                            }

                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                            ) {
                                                                OutlinedButton(
                                                                    onClick = { editingCustomerProfile = custOrd },
                                                                    shape = RoundedCornerShape(10.dp),
                                                                    modifier = Modifier.weight(1f),
                                                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                                                                ) {
                                                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(12.dp), tint = PrimaryPink)
                                                                    Spacer(modifier = Modifier.width(2.dp))
                                                                    Text("Edit", style = MaterialTheme.typography.labelSmall, color = PrimaryPink)
                                                                }

                                                                OutlinedButton(
                                                                    onClick = { selectedCustomerForHistory = custOrd },
                                                                    shape = RoundedCornerShape(10.dp),
                                                                    modifier = Modifier.weight(1f),
                                                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                                                                ) {
                                                                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(12.dp))
                                                                    Spacer(modifier = Modifier.width(2.dp))
                                                                    Text("Orders", style = MaterialTheme.typography.labelSmall)
                                                                }

                                                                OutlinedButton(
                                                                    onClick = { callingCustomer = custOrd.customerName to custOrd.customerPhone },
                                                                    shape = RoundedCornerShape(10.dp),
                                                                    modifier = Modifier.weight(1f),
                                                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                                                                ) {
                                                                    Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(12.dp), tint = PrimaryPink)
                                                                    Spacer(modifier = Modifier.width(2.dp))
                                                                    Text("Call", style = MaterialTheme.typography.labelSmall, color = PrimaryPink)
                                                                }

                                                                Button(
                                                                    onClick = { showCustomerChatSheet = custOrd },
                                                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                                    shape = RoundedCornerShape(10.dp),
                                                                    modifier = Modifier.weight(1f),
                                                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                                                                ) {
                                                                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.White)
                                                                    Spacer(modifier = Modifier.width(2.dp))
                                                                    Text("Chat", style = MaterialTheme.typography.labelSmall, color = Color.White)
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    "Laundries" -> {
                                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("All Partner Laundries (${shops.size}):", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color.Black)
                                                Button(
                                                    onClick = { showAddLaundryDialog = true },
                                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                    shape = RoundedCornerShape(12.dp)
                                                ) {
                                                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Add New Laundry", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                                }
                                            }

                                            shops.forEach { shop ->
                                                Surface(
                                                    shape = RoundedCornerShape(16.dp),
                                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.SpaceBetween
                                                        ) {
                                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                                                AsyncImage(
                                                                    model = shop.logoUrl,
                                                                    contentDescription = null,
                                                                    modifier = Modifier.size(44.dp).clip(CircleShape),
                                                                    contentScale = ContentScale.Crop
                                                                )
                                                                Column {
                                                                    Text(shop.name, fontWeight = FontWeight.Bold, color = Color.Black)
                                                                    Text("${shop.phone} • ${shop.address}", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.7f))
                                                                }
                                                            }

                                                            Surface(
                                                                onClick = {
                                                                    mainViewModel.updateShopDetails(shop.copy(isOpen = !shop.isOpen))
                                                                },
                                                                shape = RoundedCornerShape(10.dp),
                                                                color = if (shop.isOpen) AccentGreen.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f)
                                                            ) {
                                                                Text(
                                                                    if (shop.isOpen) "🟢 Approved" else "🔴 Suspended",
                                                                    color = if (shop.isOpen) AccentGreen else Color.Red,
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    fontWeight = FontWeight.Bold,
                                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                                )
                                                            }
                                                        }

                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                                Surface(
                                                                    onClick = { editingShop = shop },
                                                                    shape = RoundedCornerShape(8.dp),
                                                                    color = PrimaryPink.copy(alpha = 0.12f)
                                                                ) {
                                                                    Text("✏️ Edit Shop", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PrimaryPink, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                                                }
                                                                Surface(
                                                                    onClick = { showAdminCallModal = shop.name to shop.phone },
                                                                    shape = RoundedCornerShape(8.dp),
                                                                    color = PrimaryPink.copy(alpha = 0.12f)
                                                                ) {
                                                                    Text("📞 Call", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PrimaryPink, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                                                }
                                                                Surface(
                                                                    onClick = {
                                                                        aiViewModel.processQuery("Support inquiry for shop ${shop.name}", UserRole.SUPER_ADMIN, shop.phone, shop.name)
                                                                        showSupportChatSheet = true
                                                                    },
                                                                    shape = RoundedCornerShape(8.dp),
                                                                    color = PrimaryBlue.copy(alpha = 0.12f)
                                                                ) {
                                                                    Text("💬 Chat", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PrimaryBlue, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                                                }
                                                            }

                                                            IconButton(onClick = { mainViewModel.deleteLaundryShop(shop.id) }) {
                                                                Icon(Icons.Default.Delete, contentDescription = "Delete Laundry", tint = Color.Red.copy(alpha = 0.7f))
                                                            }
                                                        }

                                                        // Small Calculator next to each laundry admin
                                                        LaundryQuickCalculatorCard()
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    "Reports" -> {
                                        val totalPlatformSalesCount = orders.sumOf { it.totalPrice }.toInt().let { if (it > 0) it else 10000 }
                                        val reportCtx = androidx.compose.ui.platform.LocalContext.current
                                        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                            Button(
                                                onClick = {
                                                    com.example.util.PdfExportHelper.generateAndDownloadFinancialReportPdf(
                                                        context = reportCtx,
                                                        totalRevenue = totalPlatformSalesCount * 1.25,
                                                        activeOrdersCount = orders.count { it.status != com.example.data.model.OrderStatus.COMPLETED },
                                                        completedOrdersCount = orders.count { it.status == com.example.data.model.OrderStatus.COMPLETED },
                                                        totalShopsCount = shops.size,
                                                        recentOrders = orders
                                                    )
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Icon(Icons.Default.Download, contentDescription = null, tint = Color.White)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("📥 Download PDF Financial Report", color = Color.White, fontWeight = FontWeight.Bold)
                                            }
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("📊 Platform Analytics & Reports", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                                
                                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    listOf("Daily", "Weekly", "Monthly", "Yearly").forEach { tf ->
                                                        FilterChip(
                                                            selected = reportsTimeframe == tf,
                                                            onClick = { reportsTimeframe = tf },
                                                            label = { Text(tf, fontSize = 10.sp) },
                                                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPink, selectedLabelColor = Color.White)
                                                        )
                                                    }
                                                }
                                            }

                                            // KPI Metric Grid
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Surface(
                                                    shape = RoundedCornerShape(14.dp),
                                                    color = PrimaryPink.copy(alpha = 0.12f),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Column(modifier = Modifier.padding(12.dp)) {
                                                        Text("Total Revenue ($reportsTimeframe)", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                                        Text("₹${(totalPlatformSalesCount * 1.25).toInt()}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = PrimaryPink)
                                                    }
                                                }
                                                Surface(
                                                    shape = RoundedCornerShape(14.dp),
                                                    color = PrimaryBlue.copy(alpha = 0.12f),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Column(modifier = Modifier.padding(12.dp)) {
                                                        Text("Total Orders", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                                        Text("${orders.size + 42}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = PrimaryBlue)
                                                    }
                                                }
                                            }

                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Surface(
                                                    shape = RoundedCornerShape(14.dp),
                                                    color = AccentGreen.copy(alpha = 0.12f),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Column(modifier = Modifier.padding(12.dp)) {
                                                        Text("Active Laundries", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                                        Text("${shops.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = AccentGreen)
                                                    }
                                                }
                                                Surface(
                                                    shape = RoundedCornerShape(14.dp),
                                                    color = Color(0xFFFF9800).copy(alpha = 0.12f),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Column(modifier = Modifier.padding(12.dp)) {
                                                        Text("Avg Order Value", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                                        Text("₹385", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = Color(0xFFFF9800))
                                                    }
                                                }
                                            }

                                            Text("Category Service Sales Breakdown:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                                            val catBreakdown = listOf(
                                                "Steam Pressing" to 0.45f,
                                                "Dry Cleaning & Suits" to 0.30f,
                                                "Wash & Fold / Ironing" to 0.15f,
                                                "Premium Care & Shoes" to 0.10f
                                            )

                                            catBreakdown.forEach { (cat, pct) ->
                                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                        Text(cat, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = Color.Black)
                                                        Text("${(pct * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PrimaryPink)
                                                    }
                                                    LinearProgressIndicator(
                                                        progress = { pct },
                                                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                                                        color = PrimaryPink,
                                                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Button(
                                                    onClick = { settingsToastMessage = "📄 PDF Report Exported & Saved to Downloads!" },
                                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                    shape = RoundedCornerShape(12.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("Export PDF", color = Color.White, fontWeight = FontWeight.Bold)
                                                }

                                                OutlinedButton(
                                                    onClick = { settingsToastMessage = "📊 Excel CSV Report Exported Successfully!" },
                                                    shape = RoundedCornerShape(12.dp),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp), tint = AccentGreen)
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("Export CSV", color = AccentGreen, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                    "Ads" -> {
                                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                            Surface(
                                                shape = RoundedCornerShape(16.dp),
                                                color = PrimaryPink.copy(alpha = 0.12f),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(16.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Column {
                                                        Text("📢 Advertisements & Banners", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                                        Text("Create & Publish Advertisement Banner", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.7f))
                                                    }
                                                    Button(
                                                        onClick = { showOffersDialog = true },
                                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                        shape = RoundedCornerShape(12.dp)
                                                    ) {
                                                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Create Ad", color = Color.White, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }

                                            Text("Active Published Banner Ads:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)

                                            val allBannersList by mainViewModel.allBanners.collectAsState()
                                            if (allBannersList.isEmpty()) {
                                                Surface(
                                                    shape = RoundedCornerShape(14.dp),
                                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                                                        Text("No active advertisement banners. Click 'Create Ad' above to add one!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                                    }
                                                }
                                            } else {
                                                allBannersList.forEach { banner ->
                                                    Surface(
                                                        shape = RoundedCornerShape(16.dp),
                                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.padding(12.dp),
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.SpaceBetween
                                                        ) {
                                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                                                AsyncImage(
                                                                    model = banner.imageUrl,
                                                                    contentDescription = null,
                                                                    modifier = Modifier.size(54.dp).clip(RoundedCornerShape(10.dp)),
                                                                    contentScale = ContentScale.Crop
                                                                )
                                                                Column {
                                                                    Text(banner.title, fontWeight = FontWeight.Bold, color = Color.Black)
                                                                    Text("Code: ${banner.code} • ${banner.discountPercent}% OFF", style = MaterialTheme.typography.labelSmall, color = PrimaryPink)
                                                                }
                                                            }
                                                            IconButton(onClick = { mainViewModel.deleteOfferBanner(banner.id) }) {
                                                                Icon(Icons.Default.Delete, contentDescription = "Delete Ad", tint = Color.Red.copy(alpha = 0.7f))
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    "Broadcast" -> {
                                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                            Surface(
                                                shape = RoundedCornerShape(16.dp),
                                                color = PrimaryPink.copy(alpha = 0.12f),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(16.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Column {
                                                        Text("🚀 Push Notification Broadcast", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                                        Text("Send instant messages & offer banners to all app users", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.7f))
                                                    }
                                                    Button(
                                                        onClick = { showBroadcastNotificationDialog = true },
                                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                        shape = RoundedCornerShape(12.dp)
                                                    ) {
                                                        Icon(Icons.Default.Campaign, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Send Push", color = Color.White, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    "Subscriptions" -> {
                                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                            // Super Admin Active Plan Pricing Control Card
                                            Surface(
                                                shape = RoundedCornerShape(18.dp),
                                                color = PrimaryPink.copy(alpha = 0.12f),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column {
                                                            Text("⚡ Platform Subscription Tiers Control", fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.titleMedium)
                                                            Text("Super Admin can edit ₹999 plan, monthly/yearly rates, free & custom plans", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.7f))
                                                        }
                                                        Button(
                                                            onClick = { showSubscriptionManagerDialog = true },
                                                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                            shape = RoundedCornerShape(12.dp)
                                                        ) {
                                                            Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("Edit Plan Prices", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                                        }
                                                    }

                                                    val subPlans by mainViewModel.subscriptionPlans.collectAsState()
                                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        subPlans.forEach { plan ->
                                                            Surface(
                                                                shape = RoundedCornerShape(10.dp),
                                                                color = Color.White.copy(alpha = 0.9f),
                                                                modifier = Modifier.weight(1f).clickable { showSubscriptionManagerDialog = true }
                                                            ) {
                                                                val labelText = if (plan.isFree) "${plan.title}: FREE" else "${plan.title}: ₹${plan.priceRupees}"
                                                                Text(labelText, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PrimaryPink, modifier = Modifier.padding(8.dp))
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            Text("Active Partner Shop Subscriptions:", fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.titleSmall)

                                            subscriptions.forEach { sub ->
                                                Surface(
                                                    shape = RoundedCornerShape(16.dp),
                                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.SpaceBetween
                                                        ) {
                                                            Column {
                                                                Text(sub.shopName, fontWeight = FontWeight.Bold, color = Color.Black)
                                                                Text(sub.plan.title, color = PrimaryPink, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                                            }
                                                            Text("₹${sub.plan.priceRupees}", fontWeight = FontWeight.Black, color = Color.Black, style = MaterialTheme.typography.titleMedium)
                                                        }

                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Text("Status: Active • Auto-renew ON", style = MaterialTheme.typography.labelSmall, color = AccentGreen, fontWeight = FontWeight.Bold)
                                                            OutlinedButton(
                                                                onClick = { showSubscriptionManagerDialog = true },
                                                                shape = RoundedCornerShape(10.dp),
                                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                                            ) {
                                                                Text("Edit Plan / Amount", style = MaterialTheme.typography.labelSmall, color = PrimaryPink, fontWeight = FontWeight.Bold)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    "Support" -> {
                                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("🎧 Customer & Admin Support Tickets (${tickets.size}):", fontWeight = FontWeight.Bold, color = Color.Black, style = MaterialTheme.typography.titleMedium)
                                            }

                                            tickets.forEach { ticket ->
                                                Surface(
                                                    shape = RoundedCornerShape(16.dp),
                                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Text(ticket.title, fontWeight = FontWeight.Bold, color = Color.Black)
                                                            Surface(
                                                                shape = RoundedCornerShape(8.dp),
                                                                color = PrimaryPink.copy(alpha = 0.15f)
                                                            ) {
                                                                Text(ticket.status.name, style = MaterialTheme.typography.labelSmall, color = PrimaryPink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                                            }
                                                        }

                                                        Text(ticket.description, style = MaterialTheme.typography.bodyMedium, color = Color.Black.copy(alpha = 0.8f))
                                                        Text("From: ${ticket.createdByName} (${ticket.createdByPhone})", style = MaterialTheme.typography.labelSmall, color = PrimaryPink)

                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Button(
                                                                onClick = {
                                                                    supportReplyTicket = ticket
                                                                    ticketReplyText = ""
                                                                },
                                                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                                                shape = RoundedCornerShape(10.dp)
                                                            ) {
                                                                Icon(Icons.Default.Reply, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                                                Spacer(modifier = Modifier.width(4.dp))
                                                                Text("Reply & Update", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                                            }

                                                            IconButton(onClick = { mainViewModel.deleteSupportTicket(ticket.id) }) {
                                                                Icon(Icons.Default.Delete, contentDescription = "Delete Ticket", tint = Color.Red.copy(alpha = 0.7f))
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else -> {
                                        Text("Selected module management loaded safely.", color = Color.Black.copy(alpha = 0.8f))
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // DASHBOARD 2: SUPER LAUNDRY DRIVE CLEANERS (Completely Separate Own Store Dashboard)
                val shopOrders = orders.filter { it.shopId == flagshipShop?.id || true }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Staters / Video Stories Bar for Super Admin & Laundry Admins
                    item {
                        StaterStoryBar(
                            staters = staters,
                            currentRole = UserRole.SUPER_ADMIN,
                            currentUserPhone = registeredPhone,
                            onAddStaterClick = { showAddStaterDialog = true },
                            onStaterClick = { selectedStater -> activeViewerStater = selectedStater }
                        )
                    }

                    // Separate Header Card for Super Laundry Drive Cleaners
                    item {
                        SleekGradientHeaderCard(
                            mainAmount = "₹68,400.00",
                            amountLabel = "Super Laundry Store Revenue",
                            growthTag = "Flagship Store",
                            stat1Label = "Active Store Orders",
                            stat1Value = "${shopOrders.size} Orders",
                            stat2Label = "Rating",
                            stat2Value = "4.95 ⭐",
                            stat3Label = "Store Customers",
                            stat3Value = "$superLaundryStoreCustomersCount Direct"
                        )
                    }

                    // Store Quick Tabs & AI Controls
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(4.dp)
                        ) {
                            listOf("Live Orders", "Rate Card", "AI Controls", "Store Settings").forEach { tab ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(if (storeActiveTab == tab) PrimaryPink else Color.Transparent)
                                        .clickable { storeActiveTab = tab }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = tab,
                                        color = if (storeActiveTab == tab) Color.White else Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }

                    when (storeActiveTab) {
                        "Live Orders" -> {
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Super Laundry Live Orders",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                        IconButton(onClick = { showLaundryAdminSettingsSheet = true }) {
                                            Icon(Icons.Default.Settings, contentDescription = "Laundry Admin Settings", tint = PrimaryPink)
                                        }
                                    }

                                    // Order Tabs Switcher (New Orders / Old Orders / All Orders)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
                                            .padding(4.dp),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        val newOrdersCount = shopOrders.count { it.status == OrderStatus.NEW }
                                        val oldOrdersCount = shopOrders.count { it.status != OrderStatus.NEW }

                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(if (selectedOrderTab == "New Orders") PrimaryPink else Color.Transparent)
                                                .clickable { selectedOrderTab = "New Orders" }
                                                .padding(vertical = 10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                "New Orders ($newOrdersCount)",
                                                color = if (selectedOrderTab == "New Orders") Color.White else Color.Black,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }

                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(if (selectedOrderTab == "Old Orders") PrimaryPink else Color.Transparent)
                                                .clickable { selectedOrderTab = "Old Orders" }
                                                .padding(vertical = 10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                "Old Orders ($oldOrdersCount)",
                                                color = if (selectedOrderTab == "Old Orders") Color.White else Color.Black,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }

                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(if (selectedOrderTab == "All Orders") PrimaryPink else Color.Transparent)
                                                .clickable { selectedOrderTab = "All Orders" }
                                                .padding(vertical = 10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                "All (${shopOrders.size})",
                                                color = if (selectedOrderTab == "All Orders") Color.White else Color.Black,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                }
                            }

                            val filteredShopOrders = when (selectedOrderTab) {
                                "New Orders" -> shopOrders.filter { it.status == OrderStatus.NEW }
                                "Old Orders" -> shopOrders.filter { it.status != OrderStatus.NEW }
                                else -> shopOrders
                            }

                            items(filteredShopOrders) { order ->
                                SleekOrderCard(
                                    order = order,
                                    onClick = { selectedCustomerForHistory = order },
                                    onStatusChange = { newStatus ->
                                        mainViewModel.updateOrderStatus(order.id, newStatus)
                                    },
                                    onCallCustomer = { name, phone ->
                                        callingCustomer = name to phone
                                    },
                                    onChatCustomer = { ord ->
                                        showCustomerChatSheet = ord
                                    },
                                    onViewHistory = { ord ->
                                        selectedCustomerForHistory = ord
                                    }
                                )
                            }
                        }
                        "Rate Card" -> {
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Super Laundry Master Rate Card Management",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.Black
                                            )
                                            Text(
                                                text = "Set master rates across Iron, Steam Press, and Dry Cleaning categories.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color.Gray
                                            )
                                        }
                                        Button(
                                            onClick = { showAddNewItemSheet = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Add Cloth", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    // Category Filter Tabs
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState())
                                            .padding(vertical = 4.dp)
                                    ) {
                                        Surface(
                                            onClick = { superAdminCategoryFilter = null },
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (superAdminCategoryFilter == null) PrimaryPink else MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(
                                                text = "All Clothes (${flagshipRateCard.size})",
                                                color = if (superAdminCategoryFilter == null) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                            )
                                        }
                                        ServiceCategory.values().forEach { cat ->
                                            val catCount = flagshipRateCard.count { it.category == cat }
                                            Surface(
                                                onClick = { superAdminCategoryFilter = cat },
                                                shape = RoundedCornerShape(12.dp),
                                                color = if (superAdminCategoryFilter == cat) PrimaryPink else MaterialTheme.colorScheme.surfaceVariant
                                            ) {
                                                Text(
                                                    text = "${cat.displayName} ($catCount)",
                                                    color = if (superAdminCategoryFilter == cat) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            val filteredSuperRateCard = if (superAdminCategoryFilter == null) flagshipRateCard else flagshipRateCard.filter { it.category == superAdminCategoryFilter }

                            items(filteredSuperRateCard, key = { it.id }) { item ->
                                SleekRateCardItemView(
                                    item = item,
                                    onEditClick = {
                                        showEditPriceModal = item
                                        newPriceInput = item.price.toInt().toString()
                                    },
                                    onDeleteClick = {
                                        mainViewModel.deleteRateCardItem(item.id)
                                    }
                                )
                            }
                        }
                        "AI Controls" -> {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(24.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = PrimaryPink)
                                            Text("Super Laundry AI Business Engine", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                                        }

                                        Button(
                                            onClick = { showVoiceAiSheet = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(Icons.Default.Mic, contentDescription = null, tint = Color.White)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Launch AI Voice Order & Insights Assistant", color = Color.White)
                                        }

                                        Button(
                                            onClick = { showAiChatSheet = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(Icons.Default.Chat, contentDescription = null, tint = PrimaryPink)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("AI Support & Auto Customer Responder", color = Color.Black)
                                        }
                                    }
                                }
                            }
                        }
                        "Store Settings" -> {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(24.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Text("Super Laundry Store Admin Settings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)

                                        val settingsItems = listOf(
                                            "✍️ Dynamic UI Label Manager",
                                            "🎨 App Branding & Colors (Chat, Call, Support)",
                                            "⚡ Digital Prompt Settings (Platform Commands)",
                                            "💳 Subscription Plan Manager",
                                            "📢 Advertisements & Banner Creator",
                                            "📷 Logo, Gallery & Banner Photos",
                                            "🏪 Profile & Shop Details",
                                            "🤖 AI Persona Voice & Controls",
                                            "🏷️ Rate Card Manager",
                                            "⏰ Shop Timing & Service Area",
                                            "🔔 Notifications & Broadcast Alerts",
                                            "🔒 Security & Access"
                                        )

                                        settingsItems.forEach { setting ->
                                            Surface(
                                                onClick = {
                                                    val myShop = shops.firstOrNull()
                                                    when {
                                                        setting.contains("UI Label") -> showUiLabelManagerDialog = true
                                                        setting.contains("Branding") || setting.contains("Colors") -> showColorSettingsDialog = true
                                                        setting.contains("Digital Prompt") -> showDigitalPromptSettingsDialog = true
                                                        setting.contains("Subscription") -> showSubscriptionManagerDialog = true
                                                        setting.contains("Advertisements") -> showOffersDialog = true
                                                        setting.contains("AI Persona") -> showAiAdvancedSettingsDialog = true
                                                        setting.contains("Logo") -> showLogoBannerDialog = true
                                                        setting.contains("Profile") -> showProfileDetailsDialog = true
                                                        setting.contains("Timing") -> {
                                                            editShopTimingInput = myShop?.shopTiming ?: "8:00 AM - 9:00 PM"
                                                            editShopRadiusInput = (myShop?.serviceAreaRadiusKm ?: 5.0).toString()
                                                            editShopIsOpenInput = myShop?.isOpen ?: true
                                                            showTimingAreaDialog = true
                                                        }
                                                        setting.contains("Rate Card") -> storeActiveTab = "Rate Card"
                                                        setting.contains("Notifications") -> showBroadcastNotificationDialog = true
                                                        setting.contains("Security") -> showSecuritySettingsSheet = true
                                                    }
                                                },
                                                shape = RoundedCornerShape(14.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(14.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(setting, fontWeight = FontWeight.SemiBold, color = Color.Black)
                                                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Black.copy(alpha = 0.6f))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Laundry Admin Settings Modal Sheet
    if (showLaundryAdminSettingsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showLaundryAdminSettingsSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text("Super Laundry Store Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.Black)
                }

                val settingsItems = listOf(
                    "✍️ Dynamic UI Label Manager",
                    "🎨 Custom Color Settings (Chat, Call, Support)",
                    "⚡ Digital Prompt Settings (Platform AI Commands)",
                    "💳 Subscription Plan Manager",
                    "📢 Advertisements & Banner Creator",
                    "📷 Logo, Gallery & Banner Photos",
                    "🏪 Profile & Shop Details",
                    "🤖 AI Persona Voice & Controls",
                    "🏷️ Rate Card Manager",
                    "⏰ Shop Timing & Service Area",
                    "🔔 Notifications & Broadcast Alerts",
                    "🔒 Security & Access"
                )

                items(settingsItems) { setting ->
                    Surface(
                        onClick = {
                            val myShop = shops.firstOrNull()
                            when {
                                setting.contains("UI Label") -> {
                                    showLaundryAdminSettingsSheet = false
                                    showUiLabelManagerDialog = true
                                }
                                setting.contains("Color") -> {
                                    showLaundryAdminSettingsSheet = false
                                    showColorSettingsDialog = true
                                }
                                setting.contains("Digital Prompt") -> {
                                    showLaundryAdminSettingsSheet = false
                                    showDigitalPromptSettingsDialog = true
                                }
                                setting.contains("Subscription") -> {
                                    showLaundryAdminSettingsSheet = false
                                    showSubscriptionManagerDialog = true
                                }
                                setting.contains("Advertisements") -> {
                                    showLaundryAdminSettingsSheet = false
                                    showOffersDialog = true
                                }
                                setting.contains("AI Persona") -> {
                                    showLaundryAdminSettingsSheet = false
                                    showAiAdvancedSettingsDialog = true
                                }
                                setting.contains("Logo") -> {
                                    showLaundryAdminSettingsSheet = false
                                    showLogoBannerDialog = true
                                }
                                setting.contains("Profile") -> {
                                    showLaundryAdminSettingsSheet = false
                                    showProfileDetailsDialog = true
                                }
                                setting.contains("Timing") -> {
                                    showLaundryAdminSettingsSheet = false
                                    editShopTimingInput = myShop?.shopTiming ?: "8:00 AM - 9:00 PM"
                                    editShopRadiusInput = (myShop?.serviceAreaRadiusKm ?: 5.0).toString()
                                    editShopIsOpenInput = myShop?.isOpen ?: true
                                    showTimingAreaDialog = true
                                }
                                setting.contains("Rate Card") -> {
                                    showLaundryAdminSettingsSheet = false
                                    storeActiveTab = "Rate Card"
                                }
                                setting.contains("Notifications") -> {
                                    showLaundryAdminSettingsSheet = false
                                    showBroadcastNotificationDialog = true
                                }
                                setting.contains("Security") -> {
                                    showLaundryAdminSettingsSheet = false
                                    showSecuritySettingsSheet = true
                                }
                            }
                        },
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(setting, fontWeight = FontWeight.SemiBold, color = Color.Black)
                            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Black.copy(alpha = 0.6f))
                        }
                    }
                }

                item {
                    OutlinedButton(
                        onClick = {
                            showLaundryAdminSettingsSheet = false
                            onLogout()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Logout Admin", color = AccentRose)
                    }
                }
            }
        }
    }

    // Interactive Dialog: Super Admin Logo & Banner Settings
    if (showLogoBannerDialog) {
        val myShop = shops.firstOrNull()
        AlertDialog(
            onDismissRequest = { showLogoBannerDialog = false },
            title = { Text("📷 Logo & Banner Settings", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Update store logo and banner image URL:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                    OutlinedTextField(
                        value = editShopLogoInput,
                        onValueChange = { editShopLogoInput = it },
                        label = { Text("Logo Image URL") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Text("Quick Logo Presets:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                    ) {
                        val logoPresets = listOf(
                            "Modern Wash" to "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=300&q=80",
                            "Royal Dry" to "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?auto=format&fit=crop&w=300&q=80",
                            "Express Steam" to "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=300&q=80",
                            "Eco Clean" to "https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=300&q=80"
                        )
                        logoPresets.forEach { (label, url) ->
                            FilterChip(
                                selected = editShopLogoInput == url,
                                onClick = { editShopLogoInput = url },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedTextField(
                        value = editShopBannerInput,
                        onValueChange = { editShopBannerInput = it },
                        label = { Text("Banner Image URL") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Text("Quick Banner Presets:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                    ) {
                        val bannerPresets = listOf(
                            "Laundry Hub" to "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=800&q=80",
                            "Washing Machine" to "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?auto=format&fit=crop&w=800&q=80",
                            "Steam Station" to "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=800&q=80",
                            "Dry Cleaning" to "https://images.unsplash.com/photo-1521656693074-0ef32e80a5d5?auto=format&fit=crop&w=800&q=80"
                        )
                        bannerPresets.forEach { (label, url) ->
                            FilterChip(
                                selected = editShopBannerInput == url,
                                onClick = { editShopBannerInput = url },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (myShop != null) {
                            val updated = myShop.copy(
                                logoUrl = editShopLogoInput.ifBlank { myShop.logoUrl },
                                bannerUrl = editShopBannerInput.ifBlank { myShop.bannerUrl }
                            )
                            mainViewModel.updateShopDetails(updated)
                        }
                        mainViewModel.updateAppBranding(
                            name = appName,
                            logoUrl = editShopLogoInput.ifBlank { myShop?.logoUrl ?: appLogoUrl },
                            backgroundUrl = editShopBannerInput.ifBlank { myShop?.bannerUrl ?: appBackgroundUrl }
                        )
                        settingsToastMessage = "✅ Logo & Banner saved successfully!"
                        showLogoBannerDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Save Logo & Banner", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoBannerDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Interactive Dialog: Super Admin Profile Details
    if (showProfileDetailsDialog) {
        val myShop = shops.firstOrNull()
        AlertDialog(
            onDismissRequest = { showProfileDetailsDialog = false },
            title = { Text("🏪 Profile & Shop Details", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editShopNameInput,
                        onValueChange = { editShopNameInput = it },
                        label = { Text("Shop Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editShopPhoneInput,
                        onValueChange = { editShopPhoneInput = it },
                        label = { Text("Owner Mobile Number") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editShopAddressInput,
                        onValueChange = { editShopAddressInput = it },
                        label = { Text("Shop Address") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editShopDescInput,
                        onValueChange = { editShopDescInput = it },
                        label = { Text("Shop Tagline / Description") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (myShop != null && editShopNameInput.isNotBlank()) {
                            val updated = myShop.copy(
                                name = editShopNameInput,
                                phone = editShopPhoneInput,
                                address = editShopAddressInput,
                                description = editShopDescInput
                            )
                            mainViewModel.updateShopDetails(updated)
                            settingsToastMessage = "✅ Store profile details updated!"
                        }
                        showProfileDetailsDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Save Details", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showProfileDetailsDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Interactive Dialog: Timing & Delivery Radius
    if (showTimingAreaDialog) {
        val myShop = shops.firstOrNull()
        AlertDialog(
            onDismissRequest = { showTimingAreaDialog = false },
            title = { Text("⏰ Timing & Service Radius", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editShopTimingInput,
                        onValueChange = { editShopTimingInput = it },
                        label = { Text("Shop Hours (e.g. 8:00 AM - 9:00 PM)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editShopRadiusInput,
                        onValueChange = { editShopRadiusInput = it },
                        label = { Text("Delivery Radius in KM") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Store Status (Open for Orders)", fontWeight = FontWeight.Bold)
                        Switch(
                            checked = editShopIsOpenInput,
                            onCheckedChange = { editShopIsOpenInput = it }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (myShop != null) {
                            val radius = editShopRadiusInput.toDoubleOrNull() ?: myShop.serviceAreaRadiusKm
                            val updated = myShop.copy(
                                shopTiming = editShopTimingInput,
                                serviceAreaRadiusKm = radius,
                                isOpen = editShopIsOpenInput
                            )
                            mainViewModel.updateShopDetails(updated)
                            settingsToastMessage = "✅ Store timing & radius updated!"
                        }
                        showTimingAreaDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Save Timing", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimingAreaDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Interactive Dialog: Offers, Advertisements & Banners Creator
    if (showOffersDialog) {
        AdvertisementBannerCreatorDialog(
            mainViewModel = mainViewModel,
            onDismiss = { showOffersDialog = false }
        )
    }

    // Settings Feedback Dialog / Toast
    if (settingsToastMessage != null) {
        AlertDialog(
            onDismissRequest = { settingsToastMessage = null },
            title = { Text("⚙️ Settings Updated", fontWeight = FontWeight.Bold) },
            text = { Text(settingsToastMessage!!) },
            confirmButton = {
                TextButton(onClick = { settingsToastMessage = null }) {
                    Text("OK", fontWeight = FontWeight.Bold, color = PrimaryPink)
                }
            }
        )
    }

    if (showLanguageThemeDialog) {
        LanguageThemeDialog(mainViewModel = mainViewModel, aiViewModel = aiViewModel, userRole = UserRole.SUPER_ADMIN, onDismiss = { showLanguageThemeDialog = false })
    }

    if (showAppBrandingDialog) {
        AppBrandingCustomizationDialog(mainViewModel = mainViewModel, aiViewModel = aiViewModel, onDismiss = { showAppBrandingDialog = false })
    }

    if (showFutureFeatureDialog) {
        FutureFeatureSettingsDialog(mainViewModel = mainViewModel, onDismiss = { showFutureFeatureDialog = false })
    }

    if (showAiAdvancedSettingsDialog) {
        AiVoiceSettingsDialog(aiViewModel = aiViewModel, onDismiss = { showAiAdvancedSettingsDialog = false })
    }

    if (showSubscriptionManagerDialog) {
        SubscriptionPlanManagerDialog(mainViewModel = mainViewModel, shops = shops, onDismiss = { showSubscriptionManagerDialog = false })
    }

    if (showBroadcastNotificationDialog) {
        BroadcastNotificationDialog(mainViewModel = mainViewModel, onDismiss = { showBroadcastNotificationDialog = false })
    }

    if (showUiLabelManagerDialog) {
        UiLabelManagerDialog(mainViewModel = mainViewModel, onDismiss = { showUiLabelManagerDialog = false })
    }

    if (showColorSettingsDialog) {
        ColorSettingsDialog(mainViewModel = mainViewModel, onDismiss = { showColorSettingsDialog = false })
    }

    if (showDigitalPromptSettingsDialog) {
        DigitalPromptSettingsDialog(mainViewModel = mainViewModel, aiViewModel = aiViewModel, onDismiss = { showDigitalPromptSettingsDialog = false })
    }

    // Edit Item & Photo Modal (Red Card / Rate Card Item)
    if (showEditPriceModal != null) {
        val presetPhotos = listOf(
            "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80",
            "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&w=200&q=80",
            "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80",
            "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=200&q=80",
            "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=200&q=80",
            "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=200&q=80"
        )

        AlertDialog(
            onDismissRequest = { showEditPriceModal = null },
            title = { Text("✏️ Edit Card Item & Photo", color = Color.Black, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Item Photo Preview with Camera & Gallery Pickers
                    AsyncImage(
                        model = editItemPhotoInput.ifBlank { showEditPriceModal?.photoUrl },
                        contentDescription = "Item Photo",
                        modifier = Modifier
                            .size(100.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(2.dp, PrimaryPink, RoundedCornerShape(16.dp)),
                        contentScale = ContentScale.Crop
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                try { superAdminCameraLauncher.launch(null) } catch (e: Exception) {
                                    editItemPhotoInput = "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&w=600&q=80"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoGradientStart),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.PhotoCamera, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("📸 Camera", fontSize = 12.sp, color = Color.White)
                        }

                        Button(
                            onClick = {
                                try { superAdminGalleryLauncher.launch("image/*") } catch (e: Exception) {
                                    editItemPhotoInput = "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=600&q=80"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("🖼️ Gallery", fontSize = 12.sp, color = Color.White)
                        }
                    }

                    Text("Or choose quick photo preset:", fontSize = 11.sp, color = Color.Gray)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    ) {
                        presetPhotos.forEach { photoUrl ->
                            AsyncImage(
                                model = photoUrl,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { editItemPhotoInput = photoUrl },
                                contentScale = ContentScale.Crop
                            )
                        }
                    }

                    OutlinedTextField(
                        value = editItemNameInput,
                        onValueChange = { editItemNameInput = it },
                        label = { Text("Item / Cloth Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newPriceInput,
                        onValueChange = { newPriceInput = it },
                        label = { Text("Price in ₹") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newPrice = newPriceInput.toDoubleOrNull()
                        if (newPrice != null && showEditPriceModal != null) {
                            mainViewModel.updateRateCardItem(
                                showEditPriceModal!!.copy(
                                    clothName = editItemNameInput.ifBlank { showEditPriceModal!!.clothName },
                                    price = newPrice,
                                    photoUrl = editItemPhotoInput.ifBlank { showEditPriceModal!!.photoUrl }
                                )
                            )
                            showEditPriceModal = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Save Changes", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditPriceModal = null }) {
                    Text("Cancel", color = Color.Black)
                }
            }
        )
    }

    // Voice AI Modal Sheet
    if (showVoiceAiSheet) {
        LaunchedEffect(Unit) {
            aiViewModel.startVoiceSession()
        }

        ModalBottomSheet(
            onDismissRequest = {
                showVoiceAiSheet = false
                aiViewModel.stopVoiceSession()
            },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(600.dp)
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = PrimaryPink)
                        Column {
                            Text(
                                text = "Super Admin AI Voice Engine",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "🎙️ Real-time Text-To-Speech & Gemini Voice",
                                style = MaterialTheme.typography.labelSmall,
                                color = PrimaryBlue
                            )
                        }
                    }
                    IconButton(onClick = {
                        showVoiceAiSheet = false
                        aiViewModel.stopVoiceSession()
                    }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                VoiceAiWaveVisualizer(isListening = true)

                Spacer(modifier = Modifier.height(8.dp))

                // Voice Action Mic Control Bar
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { launchVoiceRecognizer() },
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoGradientStart),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = mainViewModel.getTr("🎙️ बोलकर पूछें (Tap to Speak)", "🎙️ Tap to Speak", "🎙️ बोलून विचार (Tap to Speak)", UserRole.SUPER_ADMIN),
                            fontSize = 12.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = {
                            val testMsg = mainViewModel.getTr("सुपर एडमिन वॉइस एआई सक्रिय है। कृपया अपना प्रश्न पूछें।", "Super Admin Voice AI active. Please ask your question.", "सुपर ॲडमिन व्हॉइस एआय सक्रिय आहे. विचार करा.", UserRole.SUPER_ADMIN)
                            aiViewModel.speak(testMsg)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("🔊 Voice Test", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Quick Voice Chips
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                ) {
                    val quickPrompts = listOf(
                        "Revenue Insights" to "Show platform revenue insights for today",
                        "Customer Analytics" to "Show total registered customer count and growth",
                        "Marketing Suggestions" to "Give me top marketing & offer suggestions",
                        "Draft Invoice" to "Draft an invoice for customer order"
                    )
                    quickPrompts.forEach { (label, query) ->
                        FilterChip(
                            selected = false,
                            onClick = {
                                aiViewModel.processQuery(query, UserRole.SUPER_ADMIN, registeredPhone, "Super Admin")
                            },
                            label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Voice & Chat Messages Log
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(chatMessages) { msg ->
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = if (msg.isUser) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Surface(
                                shape = RoundedCornerShape(
                                    topStart = 18.dp,
                                    topEnd = 18.dp,
                                    bottomStart = if (msg.isUser) 18.dp else 4.dp,
                                    bottomEnd = if (msg.isUser) 4.dp else 18.dp
                                ),
                                color = if (msg.isUser) PrimaryPink else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.widthIn(max = 300.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = msg.text,
                                        color = if (msg.isUser) Color.White else Color.Black,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    if (!msg.isUser) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("🗣️ AI Voice Response", fontSize = 10.sp, color = Color.Gray)
                                            IconButton(
                                                onClick = { aiViewModel.speak(msg.text) },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Default.VolumeUp, contentDescription = "Speak", tint = PrimaryPink, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Input Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { launchVoiceRecognizer() },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(IndigoGradientStart)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Mic", tint = Color.White)
                    }

                    OutlinedTextField(
                        value = aiQueryInput,
                        onValueChange = { aiQueryInput = it },
                        placeholder = { Text(mainViewModel.getTr("बोलिए या टाइप कीजिए...", "Speak or type voice command...", "बोला किंवा टाईप करा...", UserRole.SUPER_ADMIN)) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true
                    )

                    IconButton(
                        onClick = {
                            if (aiQueryInput.isNotBlank()) {
                                aiViewModel.processQuery(aiQueryInput, UserRole.SUPER_ADMIN, registeredPhone, "Super Admin")
                                aiQueryInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(PrimaryPink)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    }

    // AI Chat Sheet
    if (showAiChatSheet) {
        ModalBottomSheet(
            onDismissRequest = {
                showAiChatSheet = false
                aiViewModel.stopSpeaking()
            },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(560.dp)
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = PrimaryPink)
                        Text("Super Laundry AI Business Engine", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                    IconButton(onClick = {
                        showAiChatSheet = false
                        aiViewModel.stopSpeaking()
                    }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Chat Messages
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(chatMessages) { msg ->
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = if (msg.isUser) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Surface(
                                shape = RoundedCornerShape(
                                    topStart = 18.dp,
                                    topEnd = 18.dp,
                                    bottomStart = if (msg.isUser) 18.dp else 4.dp,
                                    bottomEnd = if (msg.isUser) 4.dp else 18.dp
                                ),
                                color = if (msg.isUser) PrimaryPink else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.widthIn(max = 300.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = msg.text,
                                        color = if (msg.isUser) Color.White else Color.Black,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    if (!msg.isUser) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 6.dp),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            IconButton(
                                                onClick = { aiViewModel.speak(msg.text) },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Default.VolumeUp, contentDescription = "Speak", tint = PrimaryPink, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Input Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = aiQueryInput,
                        onValueChange = { aiQueryInput = it },
                        placeholder = { Text("Ask AI about pricing, analytics, support...") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    IconButton(
                        onClick = {
                            if (aiQueryInput.isNotBlank()) {
                                aiViewModel.processQuery(aiQueryInput, UserRole.SUPER_ADMIN, registeredPhone, "Super Admin")
                                aiQueryInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(PrimaryPink)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    }

    // Security Settings Sheet (Change Super Admin Phone Number)
    if (showSecuritySettingsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSecuritySettingsSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "Super Admin Security Settings",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.Black,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Registered Super Admin Number: +91 $registeredPhone",
                    style = MaterialTheme.typography.bodyMedium,
                    color = PrimaryPink
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = newSuperAdminPhoneInput,
                    onValueChange = { newSuperAdminPhoneInput = it },
                    label = { Text("New Registered Phone Number") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryPink,
                        unfocusedBorderColor = OutlineLight,
                        focusedTextColor = Color.Black,
                        unfocusedTextColor = Color.Black
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (newSuperAdminPhoneInput.length >= 10) {
                            mainViewModel.updateRegisteredSuperAdminPhone(newSuperAdminPhoneInput)
                            showSecuritySettingsSheet = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Update Registered Phone Number", color = Color.White)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = {
                        showSecuritySettingsSheet = false
                        onLogout()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Logout Super Admin", color = AccentRose)
                }
            }
        }
    }

    // Call Admin Modal Dialog
    if (showAdminCallModal != null) {
        val (adminName, adminPhone) = showAdminCallModal!!
        AlertDialog(
            onDismissRequest = { showAdminCallModal = null },
            icon = { Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = PrimaryPink, modifier = Modifier.size(36.dp)) },
            title = { Text("Call Laundry Admin: $adminName", color = Color.Black, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Phone: $adminPhone", style = MaterialTheme.typography.titleMedium, color = PrimaryPink, fontWeight = FontWeight.Bold)
                    Text("Choose call or support notification action:", style = MaterialTheme.typography.bodyMedium, color = Color.Black.copy(alpha = 0.7f))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showAdminCallModal = null }
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = PrimaryPink)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Start Direct Phone Call", fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showAdminCallModal = null }, colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)) {
                    Text("Close", color = Color.White)
                }
            }
        )
    }

    // Support Chat Sheet
    if (showSupportChatSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSupportChatSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(500.dp)
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Laundry Support Assistant", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = { showSupportChatSheet = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().weight(1f)
                ) {
                    Box(modifier = Modifier.padding(16.dp)) {
                        Text("Connected to AI Support channel for laundry admins.", color = Color.Black)
                    }
                }
            }
        }
    }

    // Add New Master Clothing Item Modal
    if (showAddNewItemSheet) {
        AlertDialog(
            onDismissRequest = { showAddNewItemSheet = false },
            title = {
                Text(
                    text = "➕ Add Master Clothing Item",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Add new cloth item to master rate card across all categories:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )

                    OutlinedTextField(
                        value = newItemNameInput,
                        onValueChange = { newItemNameInput = it },
                        label = { Text("Cloth Name (e.g. Saree, Suit, Blazer)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Select Category:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ServiceCategory.values().forEach { cat ->
                            FilterChip(
                                selected = newItemCategoryInput == cat,
                                onClick = { newItemCategoryInput = cat },
                                label = { Text(cat.displayName, fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = newItemPriceInput,
                        onValueChange = { newItemPriceInput = it },
                        label = { Text("Price in ₹") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Select Item Photo Preset:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )

                    val presets = listOf(
                        "Shirt" to "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80",
                        "Pants" to "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=200&q=80",
                        "Saree" to "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80",
                        "Suit" to "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=200&q=80",
                        "Dress" to "https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?auto=format&fit=crop&w=200&q=80",
                        "Blanket" to "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=200&q=80"
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                    ) {
                        presets.forEach { (label, url) ->
                            FilterChip(
                                selected = newItemPhotoInput == url,
                                onClick = { newItemPhotoInput = url },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val priceVal = newItemPriceInput.toDoubleOrNull() ?: 0.0
                        if (newItemNameInput.isNotBlank() && priceVal > 0) {
                            val newItem = RateCardItem(
                                id = "master_${System.currentTimeMillis()}",
                                shopId = flagshipShop?.id ?: "shop_flagship",
                                category = newItemCategoryInput,
                                clothName = newItemNameInput.trim(),
                                photoUrl = newItemPhotoInput,
                                price = priceVal
                            )
                            mainViewModel.addRateCardItem(newItem)
                            showAddNewItemSheet = false
                            newItemNameInput = ""
                            newItemPriceInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                    enabled = newItemNameInput.isNotBlank() && (newItemPriceInput.toDoubleOrNull() ?: 0.0) > 0
                ) {
                    Text("Add Master Item", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddNewItemSheet = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Customer Direct Call Dialog
    if (callingCustomer != null) {
        val (cName, cPhone) = callingCustomer!!
        AlertDialog(
            onDismissRequest = { callingCustomer = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = PrimaryPink)
                    Text("Call Customer Details", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Connecting voice call to customer:", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = PrimaryPink.copy(alpha = 0.1f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(cName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.Black)
                            Text("Mobile: $cPhone", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = PrimaryPink)
                            Text("Status: Direct Line Connected (Active Voice Bridge)", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { callingCustomer = null }, colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)) {
                    Text("End Call", color = Color.White)
                }
            }
        )
    }

    // Customer Detailed Profile & Past/New Order History Sheet
    if (selectedCustomerForHistory != null) {
        val ord = selectedCustomerForHistory!!
        ModalBottomSheet(
            onDismissRequest = { selectedCustomerForHistory = null },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(ord.customerName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.Black)
                            Text("Phone: ${ord.customerPhone} • ${ord.deliveryAddress}", style = MaterialTheme.typography.bodyMedium, color = Color.Black.copy(alpha = 0.7f))
                        }
                        IconButton(onClick = { selectedCustomerForHistory = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                        }
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                callingCustomer = ord.customerName to ord.customerPhone
                                selectedCustomerForHistory = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Call Customer", color = Color.White)
                        }

                        Button(
                            onClick = {
                                showCustomerChatSheet = ord
                                selectedCustomerForHistory = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Live Chat", color = Color.White)
                        }
                    }
                }

                item {
                    Text("Customer Order Status & Detailed History", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                }

                val customerAllOrders = orders.filter { it.customerPhone == ord.customerPhone || it.customerName == ord.customerName }
                val pastList = if (customerAllOrders.isNotEmpty()) customerAllOrders else listOf(ord)

                items(pastList) { pastOrder ->
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Order #${pastOrder.orderNumber}", fontWeight = FontWeight.Bold, color = Color.Black)
                                SleekStatusBadge(status = pastOrder.status)
                            }

                            Text("Date: ${pastOrder.createdAt}", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.6f))

                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                            Text("Items Ordered:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryBlue)
                            Text("• ${pastOrder.itemsSummary}", style = MaterialTheme.typography.bodyMedium, color = Color.Black)

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total Amount Paid:", fontWeight = FontWeight.Bold, color = Color.Black)
                                Text("₹${pastOrder.totalPrice.toInt()}", fontWeight = FontWeight.Black, color = PrimaryPink)
                            }
                        }
                    }
                }
            }
        }
    }

    // Customer Live Direct Chat Sheet
    if (showCustomerChatSheet != null) {
        val custOrd = showCustomerChatSheet!!
        val dbChatMessages by mainViewModel.getChatMessages(custOrd.id).collectAsState(initial = emptyList())

        ModalBottomSheet(
            onDismissRequest = { showCustomerChatSheet = null },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(540.dp)
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Chat with ${custOrd.customerName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                        Text("Order #${custOrd.orderNumber} • ${custOrd.customerPhone}", style = MaterialTheme.typography.bodySmall, color = Color.Black.copy(alpha = 0.6f))
                    }
                    IconButton(onClick = { showCustomerChatSheet = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Chat Messages List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (dbChatMessages.isEmpty()) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                                Text("No messages yet. Send a message to the customer below!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                            }
                        }
                    }
                    items(dbChatMessages) { msg ->
                        val isSenderAdmin = msg.senderRole == UserRole.SUPER_ADMIN || msg.senderRole == UserRole.LAUNDRY_ADMIN
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = if (isSenderAdmin) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSenderAdmin) PrimaryPink else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.widthIn(max = 300.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val roleIcon = when (msg.senderRole) {
                                            UserRole.SUPER_ADMIN -> "👑"
                                            UserRole.LAUNDRY_ADMIN -> "🧺"
                                            UserRole.CUSTOMER -> "👤"
                                        }
                                        Text(
                                            text = "$roleIcon ${msg.senderName} (${msg.senderRole.name.replace("_", " ")})",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSenderAdmin) Color.White.copy(alpha = 0.9f) else PrimaryPink
                                        )
                                        IconButton(
                                            onClick = { mainViewModel.deleteChatMessage(msg.id) },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.DeleteOutline,
                                                contentDescription = "Delete",
                                                tint = if (isSenderAdmin) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "➡️ To: ${msg.recipientName} • 🔒 Super Admin Support Chat",
                                        fontSize = 10.sp,
                                        color = if (isSenderAdmin) Color.White.copy(alpha = 0.75f) else Color.Gray,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = msg.messageText,
                                        color = if (isSenderAdmin) Color.White else Color.Black,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Presets
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AssistChip(
                        onClick = {
                            mainViewModel.sendChatMessage(
                                orderId = custOrd.id,
                                senderRole = UserRole.SUPER_ADMIN,
                                senderName = "Super Laundry Admin",
                                text = "Your clothes are washed & ready for pickup!",
                                recipientRole = UserRole.CUSTOMER,
                                recipientName = custOrd.customerName
                            )
                        },
                        label = { Text("Ready for Pickup", fontSize = 11.sp) }
                    )
                    AssistChip(
                        onClick = {
                            mainViewModel.sendChatMessage(
                                orderId = custOrd.id,
                                senderRole = UserRole.SUPER_ADMIN,
                                senderName = "Super Laundry Admin",
                                text = "Delivery agent is on the way with your laundry!",
                                recipientRole = UserRole.CUSTOMER,
                                recipientName = custOrd.customerName
                            )
                        },
                        label = { Text("Out for Delivery", fontSize = 11.sp) }
                    )
                    AssistChip(
                        onClick = {
                            mainViewModel.sendChatMessage(
                                orderId = custOrd.id,
                                senderRole = UserRole.SUPER_ADMIN,
                                senderName = "Super Laundry Admin",
                                text = "Hello! Your laundry processing has started.",
                                recipientRole = UserRole.CUSTOMER,
                                recipientName = custOrd.customerName
                            )
                        },
                        label = { Text("Processing Started", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Message Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = superAdminChatMessageInput,
                        onValueChange = { superAdminChatMessageInput = it },
                        placeholder = { Text("Type message to customer...") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true
                    )
                    IconButton(
                        onClick = {
                            if (superAdminChatMessageInput.isNotBlank()) {
                                mainViewModel.sendChatMessage(
                                    orderId = custOrd.id,
                                    senderRole = UserRole.SUPER_ADMIN,
                                    senderName = "Super Laundry Admin",
                                    text = superAdminChatMessageInput.trim(),
                                    recipientRole = UserRole.CUSTOMER,
                                    recipientName = custOrd.customerName
                                )
                                superAdminChatMessageInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .background(PrimaryPink, CircleShape)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    }

    // Global Settings & Management Dialogs
    if (showLanguageThemeDialog) {
        LanguageThemeDialog(
            mainViewModel = mainViewModel,
            aiViewModel = aiViewModel,
            userRole = UserRole.SUPER_ADMIN,
            onDismiss = { showLanguageThemeDialog = false }
        )
    }

    if (showAiAdvancedSettingsDialog) {
        AiVoiceSettingsDialog(
            aiViewModel = aiViewModel,
            onDismiss = { showAiAdvancedSettingsDialog = false }
        )
    }

    if (showSubscriptionManagerDialog) {
        SubscriptionPlanManagerDialog(
            mainViewModel = mainViewModel,
            shops = shops,
            onDismiss = { showSubscriptionManagerDialog = false }
        )
    }

    if (showBroadcastNotificationDialog) {
        BroadcastNotificationDialog(
            mainViewModel = mainViewModel,
            onDismiss = { showBroadcastNotificationDialog = false }
        )
    }

    if (showOffersDialog) {
        AdvertisementBannerCreatorDialog(
            mainViewModel = mainViewModel,
            onDismiss = { showOffersDialog = false }
        )
    }

    // Add New Partner Laundry Dialog
    if (showAddLaundryDialog) {
        AlertDialog(
            onDismissRequest = { showAddLaundryDialog = false },
            title = { Text("➕ Add New Partner Laundry Shop", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = addLaundryNameInput,
                        onValueChange = { addLaundryNameInput = it },
                        label = { Text("Laundry Shop Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = addLaundryPhoneInput,
                        onValueChange = { addLaundryPhoneInput = it },
                        label = { Text("Contact Phone Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = addLaundryAddressInput,
                        onValueChange = { addLaundryAddressInput = it },
                        label = { Text("Shop Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = addLaundryLogoInput,
                        onValueChange = { addLaundryLogoInput = it },
                        label = { Text("Logo Image URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (addLaundryNameInput.isNotBlank()) {
                            val newShop = LaundryShop(
                                id = "shop_${System.currentTimeMillis()}",
                                name = addLaundryNameInput.trim(),
                                ownerPhone = addLaundryPhoneInput.ifBlank { "+91 9876543210" },
                                logoUrl = addLaundryLogoInput,
                                bannerUrl = "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=1000",
                                rating = 4.8,
                                reviewCount = 1,
                                distanceKm = addLaundryRadiusInput.toDoubleOrNull() ?: 5.0,
                                address = addLaundryAddressInput.ifBlank { "City Center Main Market" },
                                latitude = 12.9716,
                                longitude = 77.5946,
                                phone = addLaundryPhoneInput.ifBlank { "+91 9876543210" },
                                isOpen = true
                            )
                            mainViewModel.addLaundryShop(newShop)
                            showAddLaundryDialog = false
                            addLaundryNameInput = ""
                            addLaundryPhoneInput = ""
                            addLaundryAddressInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Add Laundry Shop", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddLaundryDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Edit Laundry Dialog
    if (editingShop != null) {
        var editName by remember { mutableStateOf(editingShop!!.name) }
        var editPhone by remember { mutableStateOf(editingShop!!.phone) }
        var editAddress by remember { mutableStateOf(editingShop!!.address) }
        var editLogo by remember { mutableStateOf(editingShop!!.logoUrl) }

        AlertDialog(
            onDismissRequest = { editingShop = null },
            title = { Text("✏️ Edit Partner Laundry Details", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Laundry Shop Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editPhone,
                        onValueChange = { editPhone = it },
                        label = { Text("Phone Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editAddress,
                        onValueChange = { editAddress = it },
                        label = { Text("Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editLogo,
                        onValueChange = { editLogo = it },
                        label = { Text("Logo Image URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        mainViewModel.updateShopDetails(
                            editingShop!!.copy(
                                name = editName,
                                phone = editPhone,
                                address = editAddress,
                                logoUrl = editLogo
                            )
                        )
                        editingShop = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Save Changes", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingShop = null }) { Text("Cancel") }
            }
        )
    }

    // Add Customer Dialog
    if (showAddCustomerDialog) {
        AlertDialog(
            onDismissRequest = { showAddCustomerDialog = false },
            title = { Text("👤 Add New Verified Customer", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = addCustNameInput,
                        onValueChange = { addCustNameInput = it },
                        label = { Text("Customer Full Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = addCustPhoneInput,
                        onValueChange = { addCustPhoneInput = it },
                        label = { Text("Customer Phone Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = addCustAddressInput,
                        onValueChange = { addCustAddressInput = it },
                        label = { Text("Delivery Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (addCustNameInput.isNotBlank() && addCustPhoneInput.isNotBlank()) {
                            val newOrder = Order(
                                id = "ord_${System.currentTimeMillis()}",
                                orderNumber = "#SL-${(1000..9999).random()}",
                                shopId = flagshipShop?.id ?: "shop_flagship",
                                shopName = flagshipShop?.name ?: "Super Laundry Express",
                                customerName = addCustNameInput.trim(),
                                customerPhone = addCustPhoneInput.trim(),
                                itemsSummary = "Full Service Wash & Iron",
                                totalPrice = 0.0,
                                status = OrderStatus.NEW,
                                deliveryAddress = addCustAddressInput.ifBlank { "Main Market Road, City Center" },
                                createdAt = System.currentTimeMillis()
                            )
                            mainViewModel.placeOrder(newOrder) {}
                            showAddCustomerDialog = false
                            addCustNameInput = ""
                            addCustPhoneInput = ""
                            addCustAddressInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Create Customer Record", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCustomerDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Support Reply Ticket Dialog
    if (supportReplyTicket != null) {
        val t = supportReplyTicket!!
        AlertDialog(
            onDismissRequest = { supportReplyTicket = null },
            title = { Text("🎧 Reply to Ticket: ${t.title}", fontWeight = FontWeight.Bold, color = Color.Black) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Original Description: ${t.description}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                    OutlinedTextField(
                        value = ticketReplyText,
                        onValueChange = { ticketReplyText = it },
                        label = { Text("Admin Reply / Solution") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Update Ticket Status:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(TicketStatus.IN_PROGRESS, TicketStatus.RESOLVED, TicketStatus.OPEN).forEach { st ->
                            FilterChip(
                                selected = ticketNewStatus == st,
                                onClick = { ticketNewStatus = st },
                                label = { Text(st.name, style = MaterialTheme.typography.labelSmall) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PrimaryPink, selectedLabelColor = Color.White)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        mainViewModel.updateTicketStatus(t.id, ticketNewStatus)
                        settingsToastMessage = "Reply sent and ticket updated to ${ticketNewStatus.name}!"
                        supportReplyTicket = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Text("Send Reply & Save", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { supportReplyTicket = null }) { Text("Cancel") }
            }
        )
    }

    // Edit Customer Profile Data Dialog
    if (editingCustomerProfile != null) {
        val cust = editingCustomerProfile!!
        EditCustomerProfileDialog(
            initialName = cust.customerName,
            initialPhone = cust.customerPhone,
            initialEmail = null,
            initialAddress = cust.deliveryAddress,
            initialIsLongTerm = cust.isLongTermOrder || cust.itemsSummary.contains("Long-Term", ignoreCase = true),
            initialPlanName = if (cust.isLongTermOrder) cust.itemsSummary else null,
            onSave = { name, phone, email, address, isLongTerm, planName ->
                mainViewModel.updateCustomerProfile(
                    phone = phone,
                    name = name,
                    email = email,
                    address = address,
                    isLongTermCustomer = isLongTerm,
                    subscriptionPlanName = planName
                )
                settingsToastMessage = "Updated customer profile for $name!"
                editingCustomerProfile = null
            },
            onDismiss = { editingCustomerProfile = null }
        )
    }

    if (showAddStaterDialog) {
        AddStaterDialog(
            authorName = "Super Admin",
            authorPhone = registeredPhone,
            authorRole = UserRole.SUPER_ADMIN,
            shopId = flagshipShop?.id ?: "shop_flagship",
            shopName = "Super Admin Central",
            onPostStater = { mediaUrl, isVideo, caption ->
                mainViewModel.addStater(
                    authorPhone = registeredPhone,
                    authorName = "Super Admin Platform",
                    authorRole = UserRole.SUPER_ADMIN,
                    shopId = flagshipShop?.id ?: "shop_flagship",
                    shopName = "Super Admin Central",
                    mediaUrl = mediaUrl,
                    isVideo = isVideo,
                    caption = caption
                )
                settingsToastMessage = "🚀 Super Admin Stater video announcement published across all dashboards!"
            },
            onDismiss = { showAddStaterDialog = false }
        )
    }

    if (activeViewerStater != null) {
        StaterViewerDialog(
            stater = activeViewerStater!!,
            currentUserRole = UserRole.SUPER_ADMIN,
            currentUserPhone = registeredPhone,
            onDeleteStater = { mainViewModel.deleteStater(it) },
            onDismiss = { activeViewerStater = null }
        )
    }

    if (showAiPromptToolDialog) {
        AlertDialog(
            onDismissRequest = { showAiPromptToolDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = PrimaryPink)
                    Text("🤖 AI Tool & Feature Generator", fontWeight = FontWeight.Bold, color = Color.Black)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("AI prompt enter karein, app mein Naya Option, Tool ya Capability live ho jayega!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                    Text("Quick Suggestion Prompts:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val presets = listOf(
                            "⚖️ Per-Kg Weight Calculator" to "Add a feature to calculate cloth weight in Kilograms and auto apply ₹59/kg laundry rates",
                            "👟 Shoe & Leather Bag Spa" to "Add specialized shoe cleaning, sneaker restoration and leather bag dry clean options",
                            "🧥 Wedding Cloth Rental" to "Enable festival cloth rental and formal suit subscription pass for shops",
                            "🚚 Express 2-Hour Delivery" to "Add urgent 2-hour emergency processing & priority doorstep pickup"
                        )
                        presets.forEach { (presetLabel, presetPrompt) ->
                            AssistChip(
                                onClick = {
                                    aiToolPromptInput = presetPrompt
                                    aiToolNameInput = presetLabel
                                    aiToolDescInput = "AI Generated capability: $presetLabel"
                                },
                                label = { Text(presetLabel, style = MaterialTheme.typography.labelSmall) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = PrimaryPink.copy(alpha = 0.1f), labelColor = PrimaryPink)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = aiToolNameInput,
                        onValueChange = { aiToolNameInput = it },
                        label = { Text("Tool / Feature Name (e.g., ⚖️ Kilo Rate Calculator)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = aiToolPromptInput,
                        onValueChange = { aiToolPromptInput = it },
                        label = { Text("AI Prompt Instructions") },
                        placeholder = { Text("Describe what feature or option to add to the app...") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = aiToolDescInput,
                        onValueChange = { aiToolDescInput = it },
                        label = { Text("Short Feature Description") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (aiToolNameInput.isNotBlank() && aiToolPromptInput.isNotBlank()) {
                            mainViewModel.addDynamicAppTool(
                                name = aiToolNameInput,
                                promptUsed = aiToolPromptInput,
                                description = if (aiToolDescInput.isNotBlank()) aiToolDescInput else "AI Tool: $aiToolNameInput",
                                category = aiToolCategoryInput
                            )
                            settingsToastMessage = "🚀 AI Tool '$aiToolNameInput' generated and enabled in Platform Control!"
                            aiToolNameInput = ""
                            aiToolPromptInput = ""
                            aiToolDescInput = ""
                            showAiPromptToolDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("🚀 Generate & Enable Feature", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAiPromptToolDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showAddRuleDialog) {
        AlertDialog(
            onDismissRequest = { showAddRuleDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Gavel, contentDescription = null, tint = AccentGreen)
                    Text("📜 Naya Platform Rule / Niyam Jodein", fontWeight = FontWeight.Bold, color = Color.Black)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Set app-wide policy, pricing rules, or offer conditions for all shops and users.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)

                    OutlinedTextField(
                        value = ruleTitleInput,
                        onValueChange = { ruleTitleInput = it },
                        label = { Text("Rule Title (e.g. 🧺 Per-Kg Minimum Order)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = ruleDescInput,
                        onValueChange = { ruleDescInput = it },
                        label = { Text("Rule / Policy Description") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Rule Category:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Pricing & Operational Niyam", "Delivery Terms", "Special Services", "Customer Policy").forEach { cat ->
                            FilterChip(
                                selected = ruleCategoryInput == cat,
                                onClick = { ruleCategoryInput = cat },
                                label = { Text(cat, style = MaterialTheme.typography.labelSmall) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = AccentGreen, selectedLabelColor = Color.White)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (ruleTitleInput.isNotBlank() && ruleDescInput.isNotBlank()) {
                            mainViewModel.addDynamicPlatformRule(
                                title = ruleTitleInput,
                                description = ruleDescInput,
                                category = ruleCategoryInput
                            )
                            settingsToastMessage = "📜 New rule '$ruleTitleInput' published to platform!"
                            ruleTitleInput = ""
                            ruleDescInput = ""
                            showAddRuleDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
                ) {
                    Text("Publish Rule", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddRuleDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}


