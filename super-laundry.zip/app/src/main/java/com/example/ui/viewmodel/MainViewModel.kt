package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.SuperLaundryRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = SuperLaundryRepository(application)

    val currentUser: StateFlow<AppUser?> = repository.currentUser
    val activeRole: StateFlow<UserRole> = repository.activeRole
    val superAdminDashboardType: StateFlow<SuperAdminDashboardType> = repository.superAdminDashboardType
    val registeredSuperAdminPhone: StateFlow<String> = repository.registeredSuperAdminPhone

    val allShops: StateFlow<List<LaundryShop>> = repository.getAllShops().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allOrders: StateFlow<List<Order>> = repository.getAllOrders().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allSubscriptions: StateFlow<List<Subscription>> = repository.getAllSubscriptions().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allTickets: StateFlow<List<SupportTicket>> = repository.getAllSupportTickets().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allBanners: StateFlow<List<OfferBanner>> = repository.getAllOfferBanners().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allNotifications: StateFlow<List<NotificationItem>> = repository.getAllNotifications().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allAppUsers: StateFlow<List<AppUser>> = repository.getAllAppUsers().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Super Admin App Control & Settings State
    private val _appName = MutableStateFlow("Super Laundry")
    val appName: StateFlow<String> = _appName.asStateFlow()

    private val _appTagline = MutableStateFlow("Smart On-Demand Laundry & Dry Cleaning Portal")
    val appTagline: StateFlow<String> = _appTagline.asStateFlow()

    private val _appLogoUrl = MutableStateFlow("https://images.unsplash.com/photo-1545173168-9f1947eebb7f?q=80&w=300")
    val appLogoUrl: StateFlow<String> = _appLogoUrl.asStateFlow()

    private val _appBackgroundUrl = MutableStateFlow("https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=1000")
    val appBackgroundUrl: StateFlow<String> = _appBackgroundUrl.asStateFlow()

    // Dynamic Color & Styling Customization States (Super Admin Controlled)
    private val _primaryColorHex = MutableStateFlow("#EC4899") // Default Soft Pink
    val primaryColorHex: StateFlow<String> = _primaryColorHex.asStateFlow()

    private val _headerBgColorHex = MutableStateFlow("#F0F9FF") // Default Light Blue Tint
    val headerBgColorHex: StateFlow<String> = _headerBgColorHex.asStateFlow()

    private val _textColorHex = MutableStateFlow("#0F172A") // Default Navy Black
    val textColorHex: StateFlow<String> = _textColorHex.asStateFlow()

    private val _logoColorHex = MutableStateFlow("#EC4899")
    val logoColorHex: StateFlow<String> = _logoColorHex.asStateFlow()

    private val _supportCallColorHex = MutableStateFlow("#10B981") // Default Call Support Green
    val supportCallColorHex: StateFlow<String> = _supportCallColorHex.asStateFlow()

    private val _chatColorHex = MutableStateFlow("#6366F1") // Indigo Chat Color
    val chatColorHex: StateFlow<String> = _chatColorHex.asStateFlow()

    private val _callColorHex = MutableStateFlow("#10B981") // Emerald Green Call Color
    val callColorHex: StateFlow<String> = _callColorHex.asStateFlow()

    private val _supportColorHex = MutableStateFlow("#F59E0B") // Amber Support Color
    val supportColorHex: StateFlow<String> = _supportColorHex.asStateFlow()

    // Dynamic UI Labels State (Super Admin Controlled)
    private val _customUiLabels = MutableStateFlow<Map<String, String>>(
        mapOf(
            "namaste" to "Namaste, Super Laundry!",
            "greeting_sub" to "Platform controls and AI neural insights are online.",
            "switch_to_store" to "Super Laundry Store",
            "switch_to_platform" to "Platform Admin",
            "tab_overview" to "Overview & Analytics",
            "tab_laundries" to "Laundry Shops Management",
            "tab_customers" to "Customer Directory",
            "tab_subscriptions" to "Plan Subscriptions",
            "tab_reports" to "Financial Reports",
            "tab_platform_control" to "Platform Control & AI Studio",
            "tab_ads" to "Ads & Offer Banners",
            "tab_app_settings" to "App Settings & Branding",
            "tab_support" to "Support & Helpdesk",
            "ai_control_center" to "AI Control Center",
            "ai_voice_assistant" to "AI Voice Assistant (Akash)",
            "chat_label" to "In-App Customer Chat",
            "calling_label" to "Direct Phone Call Support",
            "support_label" to "Super Admin Helpdesk"
        )
    )
    val customUiLabels: StateFlow<Map<String, String>> = _customUiLabels.asStateFlow()

    fun setCustomUiLabel(key: String, value: String) {
        val updated = _customUiLabels.value.toMutableMap()
        updated[key] = value
        _customUiLabels.value = updated
    }

    fun updateCustomUiLabels(newLabels: Map<String, String>) {
        val updated = _customUiLabels.value.toMutableMap()
        updated.putAll(newLabels)
        _customUiLabels.value = updated
    }

    // Per-Role Language Preferences
    private val _customerLanguage = MutableStateFlow("Hindi (हिंदी)")
    val customerLanguage: StateFlow<String> = _customerLanguage.asStateFlow()

    private val _laundryAdminLanguage = MutableStateFlow("Hindi (हिंदी)")
    val laundryAdminLanguage: StateFlow<String> = _laundryAdminLanguage.asStateFlow()

    private val _superAdminLanguage = MutableStateFlow("English (IN)")
    val superAdminLanguage: StateFlow<String> = _superAdminLanguage.asStateFlow()

    fun getTr(
        hindiText: String,
        englishText: String,
        marathiText: String = hindiText,
        role: UserRole = UserRole.SUPER_ADMIN
    ): String {
        val lang = when (role) {
            UserRole.CUSTOMER -> _customerLanguage.value
            UserRole.LAUNDRY_ADMIN -> _laundryAdminLanguage.value
            UserRole.SUPER_ADMIN -> _superAdminLanguage.value
        }
        return when {
            lang.contains("Marathi") || lang.contains("मराठी") -> marathiText
            lang.contains("Hindi") || lang.contains("हिंदी") || lang.contains("Hinglish") -> hindiText
            else -> englishText
        }
    }

    fun tr(key: String, role: UserRole = UserRole.SUPER_ADMIN): String {
        val customOverride = _customUiLabels.value[key]
        if (!customOverride.isNullOrBlank()) {
            return customOverride
        }

        val lang = when (role) {
            UserRole.CUSTOMER -> _customerLanguage.value
            UserRole.LAUNDRY_ADMIN -> _laundryAdminLanguage.value
            UserRole.SUPER_ADMIN -> _superAdminLanguage.value
        }
        val isMarathi = lang.contains("Marathi") || lang.contains("मराठी")
        val isHindi = lang.contains("Hindi") || lang.contains("हिंदी") || lang.contains("Hinglish")

        return when (key) {
            "namaste" -> if (isMarathi) "नमस्कार, सुपर लॉन्ड्री!" else if (isHindi) "नमस्ते, सुपर लॉन्ड्री!" else "Namaste, Super Laundry!"
            "greeting_sub" -> if (isMarathi) "प्लॅटफॉर्म नियंत्रण आणि एआय मज्जासंस्था ऑनलाइन आहेत." else if (isHindi) "प्लेटफॉर्म कंट्रोल एवं एआई न्यूरल इंसाइट्स ऑनलाइन हैं।" else "Platform controls and AI neural insights are online."
            "switch_to_store" -> if (isMarathi) "सुपर लॉन्ड्री स्टोअर" else if (isHindi) "सुपर लॉन्ड्री स्टोर" else "Super Laundry Store"
            "switch_to_platform" -> if (isMarathi) "प्लॅटफॉर्म ॲडमिन" else if (isHindi) "प्लॅटफॉर्म एडमिन" else "Platform Admin"
            "tab_overview" -> if (isMarathi) "एकूण आढावा" else if (isHindi) "ओवरव्यू एवं एनालिटिक्स" else "Overview & Analytics"
            "tab_laundries" -> if (isMarathi) "लॉन्ड्री दुकाने व्यवस्थापन" else if (isHindi) "लॉन्ड्री दुकान प्रबंधन" else "Laundry Shop Management"
            "tab_orders" -> if (isMarathi) "सर्व ऑर्डर्स" else if (isHindi) "सभी ऑर्डर्स" else "All Orders Track"
            "tab_customers" -> if (isMarathi) "ग्राहक यादी" else if (isHindi) "ग्राहक सूची" else "Customer Directory"
            "tab_subscriptions" -> if (isMarathi) "सब्सक्रिप्शन प्लॅन्स" else if (isHindi) "सब्सक्रिप्शन प्लान्स" else "Plan Subscriptions"
            "tab_reports" -> if (isMarathi) "आर्थिक अहवाल" else if (isHindi) "वित्तीय रिपोर्ट्स एवं मुनाफा" else "Financial Reports"
            "tab_platform_control" -> if (isMarathi) "प्लॅटफॉर्म नियंत्रण" else if (isHindi) "प्लॅटफॉर्म कंट्रोल एवं एआई" else "Platform Control & AI Studio"
            "tab_ads" -> if (isMarathi) "जाहिराती आणि बॅनर" else if (isHindi) "विज्ञापन एवं ऑफर बैनर" else "Ads & Offer Banners"
            "tab_app_settings" -> if (isMarathi) "ॲप सेटिंग्ज आणि ब्रँडिंग" else if (isHindi) "ऐप सेटिंग्स एवं ब्रांडिंग" else "App Settings & Branding"
            "tab_support" -> if (isMarathi) "मदत आणि हेल्पडेस्क" else if (isHindi) "सहायता एवं हेल्पडेस्क" else "Support & Helpdesk"
            "ai_control_center" -> if (isMarathi) "एआय कंट्रोल सेंटर" else if (isHindi) "एआई कंट्रोल सेंटर" else "AI Control Center"
            "ai_voice_assistant" -> if (isMarathi) "एआय व्हॉइस असिस्टंट (आकाश)" else if (isHindi) "एआई वॉइस असिस्टेंट (आकाश)" else "AI Voice Assistant (Akash)"
            "color_settings" -> if (isMarathi) "रंग बदल सेटिंग आणि थीम" else if (isHindi) "कलर चेंज सेटिंग एवं थीम्स" else "Color Change Setting & Themes"
            "future_feature_settings" -> if (isMarathi) "भविष्यातील वैशिष्ट्य सेटिंग्ज" else if (isHindi) "फ्यूचर फीचर सेटिंग्स एवं बिल्डर" else "Future Feature Settings & Builder"
            "save_settings" -> if (isMarathi) "सेटिंग्ज जतन करा" else if (isHindi) "सेटिंग्स सुरक्षित करें" else "Save Settings"
            "reset_default" -> if (isMarathi) "डिफॉल्ट थीमवर रीसेट करा" else if (isHindi) "डिफ़ॉल्ट थीम पर रीसेट करें" else "Reset to Default Theme"
            else -> key
        }
    }

    // Feature Toggles
    private val _isOrderTrackingEnabled = MutableStateFlow(true)
    val isOrderTrackingEnabled: StateFlow<Boolean> = _isOrderTrackingEnabled.asStateFlow()

    private val _isDirectCallEnabled = MutableStateFlow(true)
    val isDirectCallEnabled: StateFlow<Boolean> = _isDirectCallEnabled.asStateFlow()

    private val _isInAppChatEnabled = MutableStateFlow(true)
    val isInAppChatEnabled: StateFlow<Boolean> = _isInAppChatEnabled.asStateFlow()

    private val _isRateCardManagerEnabled = MutableStateFlow(true)
    val isRateCardManagerEnabled: StateFlow<Boolean> = _isRateCardManagerEnabled.asStateFlow()

    private val _isCouponsOffersEnabled = MutableStateFlow(true)
    val isCouponsOffersEnabled: StateFlow<Boolean> = _isCouponsOffersEnabled.asStateFlow()

    private val _isSelfCheckoutEnabled = MutableStateFlow(true)
    val isSelfCheckoutEnabled: StateFlow<Boolean> = _isSelfCheckoutEnabled.asStateFlow()

    // App Language & Theme Mode
    private val _appLanguage = MutableStateFlow("Hindi (हिंदी)")
    val appLanguage: StateFlow<String> = _appLanguage.asStateFlow()

    private val _appThemeMode = MutableStateFlow("Auto Day/Night")
    val appThemeMode: StateFlow<String> = _appThemeMode.asStateFlow()

    // App Direction & AI Scope
    private val _appDirection = MutableStateFlow("LTR")
    val appDirection: StateFlow<String> = _appDirection.asStateFlow()

    private val _aiAccessScope = MutableStateFlow("All Laundry Admins")
    val aiAccessScope: StateFlow<String> = _aiAccessScope.asStateFlow()

    private val _aiStrictTaskEnforcement = MutableStateFlow(true)
    val aiStrictTaskEnforcement: StateFlow<Boolean> = _aiStrictTaskEnforcement.asStateFlow()

    // App Control Setters
    fun updateAppLanguage(language: String, userRole: UserRole = UserRole.CUSTOMER) {
        _appLanguage.value = language
        when (userRole) {
            UserRole.CUSTOMER -> _customerLanguage.value = language
            UserRole.LAUNDRY_ADMIN -> _laundryAdminLanguage.value = language
            UserRole.SUPER_ADMIN -> _superAdminLanguage.value = language
        }
    }

    fun setCustomerLanguage(language: String) {
        _customerLanguage.value = language
        _appLanguage.value = language
    }

    fun setLaundryAdminLanguage(language: String) {
        _laundryAdminLanguage.value = language
        _appLanguage.value = language
    }

    fun setSuperAdminLanguage(language: String) {
        _superAdminLanguage.value = language
        _appLanguage.value = language
    }

    fun updateAppStylingAndColors(
        primaryHex: String,
        headerBgHex: String,
        textHex: String,
        logoHex: String,
        supportCallHex: String = "#10B981",
        tagline: String = ""
    ) {
        _primaryColorHex.value = primaryHex
        _headerBgColorHex.value = headerBgHex
        _textColorHex.value = textHex
        _logoColorHex.value = logoHex
        _supportCallColorHex.value = supportCallHex
        if (tagline.isNotBlank()) {
            _appTagline.value = tagline
        }
    }

    fun resetThemeToDefault() {
        _primaryColorHex.value = "#EC4899"
        _headerBgColorHex.value = "#6366F1"
        _textColorHex.value = "#0F172A"
        _logoColorHex.value = "#EC4899"
        _supportCallColorHex.value = "#10B981"
        _appThemeMode.value = "Auto Day/Night"
    }

    // Future Feature Settings & Registry
    private val _futureFeatures = MutableStateFlow<List<FutureFeatureConfig>>(
        listOf(
            FutureFeatureConfig(
                id = "feat_sub_expiry",
                featureName = "Subscription Expiry Reminder System",
                promptDescription = "Automated WhatsApp and push notification alerts 3 days before laundry admin subscription expires.",
                requirements = "Connect with notification service and subscription end date flow.",
                targetRole = "Laundry Admin",
                targetDashboard = "Laundry Admin",
                isEnabled = true
            ),
            FutureFeatureConfig(
                id = "feat_loyalty_points",
                featureName = "Customer Loyalty & Rewards Points",
                promptDescription = "Award 1 point for every ₹10 spent on laundry, redeemable on future orders.",
                requirements = "Integrate with checkout screen and customer profile.",
                targetRole = "Customer",
                targetDashboard = "Customer",
                isEnabled = true
            ),
            FutureFeatureConfig(
                id = "feat_monthly_revenue_report",
                featureName = "Monthly Revenue Breakdown Report",
                promptDescription = "Detailed monthly revenue reports with chart visuals and export options.",
                requirements = "Integrate with analytics module and CSV download.",
                targetRole = "Super Admin",
                targetDashboard = "Super Admin Platform",
                isEnabled = true
            )
        )
    )
    val futureFeatures: StateFlow<List<FutureFeatureConfig>> = _futureFeatures.asStateFlow()

    fun addFutureFeature(config: FutureFeatureConfig) {
        _futureFeatures.value = listOf(config) + _futureFeatures.value
    }

    fun toggleFutureFeature(id: String, enabled: Boolean) {
        _futureFeatures.value = _futureFeatures.value.map {
            if (it.id == id) it.copy(isEnabled = enabled) else it
        }
    }

    fun updateAppThemeMode(themeMode: String) {
        _appThemeMode.value = themeMode
    }

    fun sendBroadcastAnnouncement(title: String, message: String, audience: String) {
        viewModelScope.launch {
            val item = NotificationItem(
                id = "notif_${System.currentTimeMillis()}",
                senderRole = UserRole.SUPER_ADMIN,
                targetRole = audience,
                title = title,
                message = message,
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
            repository.sendBroadcastNotification(item)
        }
    }

    fun changeShopSubscription(shopId: String, shopName: String, plan: SubscriptionPlan) {
        viewModelScope.launch {
            repository.createOrRenewSubscription(shopId, shopName, plan)
        }
    }

    fun updateAppBranding(name: String, logoUrl: String, backgroundUrl: String) {
        _appName.value = name
        _appLogoUrl.value = logoUrl
        _appBackgroundUrl.value = backgroundUrl
    }

    fun toggleFeature(feature: String, enabled: Boolean) {
        when (feature) {
            "order_tracking" -> _isOrderTrackingEnabled.value = enabled
            "direct_call" -> _isDirectCallEnabled.value = enabled
            "in_app_chat" -> _isInAppChatEnabled.value = enabled
            "rate_card_manager" -> _isRateCardManagerEnabled.value = enabled
            "coupons_offers" -> _isCouponsOffersEnabled.value = enabled
            "self_checkout" -> _isSelfCheckoutEnabled.value = enabled
        }
    }

    fun updateAppDirection(direction: String) {
        _appDirection.value = direction
    }

    fun updateAiAccessScope(scope: String) {
        _aiAccessScope.value = scope
    }

    fun toggleAiStrictEnforcement(enabled: Boolean) {
        _aiStrictTaskEnforcement.value = enabled
    }

    // Selection States
    private val _selectedShop = MutableStateFlow<LaundryShop?>(null)
    val selectedShop: StateFlow<LaundryShop?> = _selectedShop.asStateFlow()

    fun selectShop(shop: LaundryShop) {
        _selectedShop.value = shop
    }

    fun updateShopDetails(shop: LaundryShop) {
        viewModelScope.launch {
            repository.updateShopDetails(shop)
        }
    }

    fun addLaundryShop(shop: LaundryShop) {
        viewModelScope.launch {
            repository.addLaundryShop(shop)
        }
    }

    fun deleteLaundryShop(shopId: String) {
        viewModelScope.launch {
            repository.deleteLaundryShop(shopId)
        }
    }

    fun getRateCardForShop(shopId: String): Flow<List<RateCardItem>> = repository.getRateCardForShop(shopId)

    fun getOrdersForShop(shopId: String): Flow<List<Order>> = repository.getOrdersForShop(shopId)

    fun getOrdersForCustomer(phone: String): Flow<List<Order>> = repository.getOrdersForCustomer(phone)

    fun getChatMessages(orderId: String): Flow<List<ChatMessage>> = repository.getChatMessages(orderId)

    // Actions
    fun switchRole(role: UserRole) = repository.switchRole(role)

    fun switchSuperAdminDashboard() = repository.switchSuperAdminDashboard()

    fun updateRegisteredSuperAdminPhone(newPhone: String) = repository.updateRegisteredSuperAdminPhone(newPhone)

    fun loginWithOtp(phone: String, role: UserRole, onComplete: (AppUser) -> Unit) {
        viewModelScope.launch {
            val user = repository.loginWithOtp(phone, role)
            onComplete(user)
        }
    }

    fun logout() = repository.logout()

    fun placeOrder(order: Order, onComplete: () -> Unit) {
        viewModelScope.launch {
            repository.placeOrder(order)
            onComplete()
        }
    }

    fun updateOrderStatus(orderId: String, status: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, status)
        }
    }

    fun sendChatMessage(
        orderId: String,
        senderRole: UserRole,
        senderName: String,
        text: String,
        recipientRole: UserRole = UserRole.LAUNDRY_ADMIN,
        recipientName: String = "Laundry Admin"
    ) {
        viewModelScope.launch {
            val msg = ChatMessage(
                id = "msg_${System.currentTimeMillis()}_${(100..999).random()}",
                orderId = orderId,
                senderRole = senderRole,
                senderName = senderName,
                messageText = text,
                recipientRole = recipientRole,
                recipientName = recipientName
            )
            repository.sendChatMessage(msg)
        }
    }

    fun deleteChatMessage(messageId: String) {
        viewModelScope.launch {
            repository.deleteChatMessage(messageId)
        }
    }

    fun clearChatForOrder(orderId: String) {
        viewModelScope.launch {
            repository.clearChatForOrder(orderId)
        }
    }

    fun updateRateCardItem(item: RateCardItem) {
        viewModelScope.launch {
            repository.updateRateCardItem(item)
        }
    }

    fun addRateCardItem(item: RateCardItem) {
        viewModelScope.launch {
            repository.insertRateCardItem(item)
        }
    }

    fun deleteRateCardItem(itemId: String) {
        viewModelScope.launch {
            repository.deleteRateCardItem(itemId)
        }
    }

    fun renewSubscription(shopId: String, shopName: String, plan: SubscriptionPlan) {
        viewModelScope.launch {
            repository.createOrRenewSubscription(shopId, shopName, plan)
        }
    }

    fun createSupportTicket(
        title: String,
        description: String,
        userRole: UserRole,
        targetRole: UserRole,
        creatorPhone: String,
        creatorName: String
    ) {
        viewModelScope.launch {
            val ticket = SupportTicket(
                id = "tick_${System.currentTimeMillis()}",
                createdByPhone = creatorPhone,
                createdByName = creatorName,
                userRole = userRole,
                targetRole = targetRole,
                title = title,
                description = description
            )
            repository.createSupportTicket(ticket)
        }
    }

    fun deleteSupportTicket(ticketId: String) {
        viewModelScope.launch {
            repository.deleteSupportTicket(ticketId)
        }
    }

    fun updateTicketStatus(ticketId: String, status: TicketStatus) {
        viewModelScope.launch {
            repository.updateTicketStatus(ticketId, status)
        }
    }

    fun deleteOrder(orderId: String) {
        viewModelScope.launch {
            repository.deleteOrder(orderId)
        }
    }

    fun sendBroadcastNotification(
        title: String,
        message: String,
        senderRole: UserRole,
        targetRole: String,
        targetId: String? = null
    ) {
        viewModelScope.launch {
            val notification = NotificationItem(
                id = "notif_${System.currentTimeMillis()}",
                senderRole = senderRole,
                targetRole = targetRole,
                targetId = targetId,
                title = title,
                message = message
            )
            repository.sendBroadcastNotification(notification)
        }
    }

    fun addOfferBanner(banner: OfferBanner) {
        viewModelScope.launch {
            repository.addOfferBanner(banner)
        }
    }

    fun deleteOfferBanner(id: String) {
        viewModelScope.launch {
            repository.deleteOfferBanner(id)
        }
    }

    fun updateCustomerProfile(
        phone: String,
        name: String,
        email: String?,
        address: String,
        isLongTermCustomer: Boolean = false,
        subscriptionPlanName: String? = null
    ) {
        viewModelScope.launch {
            val existing = repository.currentUser.value
            val targetRole = if (existing?.phone == phone) existing.role else UserRole.CUSTOMER
            val updatedUser = AppUser(
                phone = phone,
                role = targetRole,
                name = name,
                email = email,
                address = address,
                isLongTermCustomer = isLongTermCustomer,
                subscriptionPlanName = subscriptionPlanName
            )
            repository.saveOrUpdateUser(updatedUser)
        }
    }

    fun deleteCustomer(phone: String) {
        viewModelScope.launch {
            repository.deleteAppUser(phone)
        }
    }

    fun placeLongTermOrder(
        shopId: String,
        shopName: String,
        planTitle: String,
        priceRupees: Double,
        customerPhone: String,
        customerName: String,
        deliveryAddress: String
    ) {
        viewModelScope.launch {
            val orderId = "ord_lt_${System.currentTimeMillis()}"
            val orderNum = "SL-LT${(1000..9999).random()}"
            val longTermOrder = Order(
                id = orderId,
                orderNumber = orderNum,
                shopId = shopId,
                shopName = shopName,
                customerPhone = customerPhone,
                customerName = customerName,
                itemsSummary = "Long-Term Pass: $planTitle",
                totalPrice = priceRupees,
                status = OrderStatus.IN_PROCESS,
                createdAt = System.currentTimeMillis(),
                deliveryAddress = deliveryAddress,
                instructions = "Active Long-Term Subscription Package",
                totalItemsCount = 1,
                isLongTermOrder = true
            )
            repository.placeOrder(longTermOrder)

            // Update customer record as Long-Term customer
            updateCustomerProfile(
                phone = customerPhone,
                name = customerName,
                email = repository.currentUser.value?.email ?: "customer@laundry.com",
                address = deliveryAddress,
                isLongTermCustomer = true,
                subscriptionPlanName = planTitle
            )
        }
    }

    // Staters (Status Updates / Stories / Short Videos)
    private val _allStaters = MutableStateFlow<List<StaterUpdate>>(
        listOf(
            StaterUpdate(
                id = "stater_sa_1",
                authorPhone = "9876543210",
                authorName = "Super Admin Central",
                authorRole = UserRole.SUPER_ADMIN,
                shopId = null,
                shopName = "Platform Control Headquarters",
                mediaUrl = "https://images.unsplash.com/photo-1545173168-9f1947eebb7f?q=80&w=800",
                isVideo = false,
                caption = "📢 Super Admin Stater: Flat 20% festival cashback offer live for all laundry partners nationwide!",
                timestamp = System.currentTimeMillis() - 3600000
            ),
            StaterUpdate(
                id = "stater_la_1",
                authorPhone = "9811122233",
                authorName = "CleanCare Express",
                authorRole = UserRole.LAUNDRY_ADMIN,
                shopId = "shop_1",
                shopName = "CleanCare Express Steam Laundry",
                mediaUrl = "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=800",
                isVideo = true,
                caption = "🧺 Morning batch live: Eco-friendly steam press & crisp shirt folding in progress!",
                timestamp = System.currentTimeMillis() - 1800000
            ),
            StaterUpdate(
                id = "stater_la_2",
                authorPhone = "9822233344",
                authorName = "Royal Dry Cleaners",
                authorRole = UserRole.LAUNDRY_ADMIN,
                shopId = "shop_2",
                shopName = "Royal Dry Cleaners & Steamers",
                mediaUrl = "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?q=80&w=800",
                isVideo = false,
                caption = "✨ 2-Hour Express Steam Ironing available for formal suits & silk sarees today!",
                timestamp = System.currentTimeMillis() - 900000
            )
        )
    )
    val allStaters: StateFlow<List<StaterUpdate>> = _allStaters.asStateFlow()

    fun addStater(
        authorPhone: String,
        authorName: String,
        authorRole: UserRole,
        shopId: String? = null,
        shopName: String? = null,
        mediaUrl: String,
        isVideo: Boolean = false,
        caption: String = ""
    ) {
        val newStater = StaterUpdate(
            id = "stater_${System.currentTimeMillis()}",
            authorPhone = authorPhone,
            authorName = authorName,
            authorRole = authorRole,
            shopId = shopId,
            shopName = shopName,
            mediaUrl = mediaUrl,
            isVideo = isVideo,
            caption = caption,
            timestamp = System.currentTimeMillis()
        )
        _allStaters.update { listOf(newStater) + it }
    }

    fun deleteStater(staterId: String) {
        _allStaters.update { list -> list.filterNot { it.id == staterId } }
    }

    // Dynamic Platform Controls & Feature Toggles
    private val _isByWeightKiloPricingEnabled = MutableStateFlow(true)
    val isByWeightKiloPricingEnabled: StateFlow<Boolean> = _isByWeightKiloPricingEnabled.asStateFlow()

    private val _isStaterVideoStoriesEnabled = MutableStateFlow(true)
    val isStaterVideoStoriesEnabled: StateFlow<Boolean> = _isStaterVideoStoriesEnabled.asStateFlow()

    private val _isShoeSpaCareEnabled = MutableStateFlow(true)
    val isShoeSpaCareEnabled: StateFlow<Boolean> = _isShoeSpaCareEnabled.asStateFlow()

    private val _isExpress2HourDeliveryEnabled = MutableStateFlow(true)
    val isExpress2HourDeliveryEnabled: StateFlow<Boolean> = _isExpress2HourDeliveryEnabled.asStateFlow()

    private val _isClothRentalServiceEnabled = MutableStateFlow(false)
    val isClothRentalServiceEnabled: StateFlow<Boolean> = _isClothRentalServiceEnabled.asStateFlow()

    // Dynamic Rules & Platform Niyam
    private val _dynamicPlatformRules = MutableStateFlow<List<DynamicPlatformRule>>(
        listOf(
            DynamicPlatformRule(
                id = "rule_1",
                title = "🧺 Per-Kg Laundry Pricing Niyam",
                description = "Laundry shops can accept clothes by weight (e.g. ₹59/kg for Wash & Fold, ₹89/kg for Wash & Steam Iron).",
                ruleCategory = "Pricing & Operational Niyam",
                isEnabled = true
            ),
            DynamicPlatformRule(
                id = "rule_2",
                title = "🚚 Free Pickup Threshold (Above ₹299)",
                description = "Free doorstep pickup & delivery applies automatically on orders over ₹299 across all partnered stores.",
                ruleCategory = "Delivery Terms",
                isEnabled = true
            ),
            DynamicPlatformRule(
                id = "rule_3",
                title = "⚡ 2-Hour Super Express Emergency Ironing",
                description = "Urgent cloth processing within 2 hours available at 1.5x standard rate for premium subscribers.",
                ruleCategory = "Special Services",
                isEnabled = true
            )
        )
    )
    val dynamicPlatformRules: StateFlow<List<DynamicPlatformRule>> = _dynamicPlatformRules.asStateFlow()

    // AI Generated Dynamic Tools & App Options
    private val _dynamicAppTools = MutableStateFlow<List<DynamicAppTool>>(
        listOf(
            DynamicAppTool(
                id = "tool_1",
                name = "⚖️ Per-Kg Weight Calculator Tool",
                promptUsed = "Add a feature to calculate total order price based on cloth weight in Kilograms",
                description = "Allows customers and laundry admins to weigh cloth bundles and auto-calculate rate per Kg.",
                toolCategory = "New Laundry Service",
                isEnabled = true
            ),
            DynamicAppTool(
                id = "tool_2",
                name = "👟 Shoe & Leather Bag Spa Cleaning",
                promptUsed = "Add specialized shoe cleaning and leather jacket restoration options for shops",
                description = "Enables dry cleaning, stain removal & deep restoration for sneakers, formal shoes & leather bags.",
                toolCategory = "Special Services",
                isEnabled = true
            ),
            DynamicAppTool(
                id = "tool_3",
                name = "📹 Live Laundry Stater Shorts",
                promptUsed = "Enable 15-second video stater stories for shop announcements and customer trust",
                description = "Allows shops to broadcast quick live video updates of washing & pressing batch status.",
                toolCategory = "Social & Promotion",
                isEnabled = true
            )
        )
    )
    val dynamicAppTools: StateFlow<List<DynamicAppTool>> = _dynamicAppTools.asStateFlow()

    // Editable Subscription Plans (Super Admin & Laundry Admin Global Price Configuration)
    private val _subscriptionPlans = MutableStateFlow<List<EditableSubscriptionPlan>>(
        listOf(
            EditableSubscriptionPlan("MONTHLY", "Monthly Pass", 1, 0, "100% Free", isFree = true),
            EditableSubscriptionPlan("QUARTERLY", "Quarterly Pass", 3, 0, "100% Free", isFree = true),
            EditableSubscriptionPlan("HALF_YEARLY", "Half-Yearly Pass", 6, 0, "100% Free", isFree = true),
            EditableSubscriptionPlan("YEARLY", "Annual Gold Pass", 12, 0, "100% Free", isFree = true)
        )
    )
    val subscriptionPlans: StateFlow<List<EditableSubscriptionPlan>> = _subscriptionPlans.asStateFlow()

    fun updateSubscriptionPlanPrice(planId: String, newPrice: Int, isFree: Boolean = false) {
        _subscriptionPlans.update { list ->
            list.map { plan ->
                if (plan.planId == planId) {
                    plan.copy(
                        priceRupees = if (isFree) 0 else newPrice,
                        isFree = isFree
                    )
                } else plan
            }
        }
    }

    fun makeSubscriptionPlanFree(planId: String) {
        updateSubscriptionPlanPrice(planId, 0, isFree = true)
    }

    fun toggleByWeightKiloPricing(enabled: Boolean) { _isByWeightKiloPricingEnabled.value = enabled }
    fun toggleStaterVideoStories(enabled: Boolean) { _isStaterVideoStoriesEnabled.value = enabled }
    fun toggleShoeSpaCare(enabled: Boolean) { _isShoeSpaCareEnabled.value = enabled }
    fun toggleExpress2HourDelivery(enabled: Boolean) { _isExpress2HourDeliveryEnabled.value = enabled }
    fun toggleClothRentalService(enabled: Boolean) { _isClothRentalServiceEnabled.value = enabled }

    fun addDynamicPlatformRule(title: String, description: String, category: String = "Pricing & Operational Niyam") {
        val rule = DynamicPlatformRule(
            title = title,
            description = description,
            ruleCategory = category,
            isEnabled = true
        )
        _dynamicPlatformRules.update { listOf(rule) + it }
    }

    fun toggleDynamicPlatformRule(ruleId: String) {
        _dynamicPlatformRules.update { list ->
            list.map { if (it.id == ruleId) it.copy(isEnabled = !it.isEnabled) else it }
        }
    }

    fun deleteDynamicPlatformRule(ruleId: String) {
        _dynamicPlatformRules.update { list -> list.filterNot { it.id == ruleId } }
    }

    fun addDynamicAppTool(name: String, promptUsed: String, description: String, category: String = "New Laundry Service") {
        val tool = DynamicAppTool(
            name = name,
            promptUsed = promptUsed,
            description = description,
            toolCategory = category,
            isEnabled = true
        )
        _dynamicAppTools.update { listOf(tool) + it }
    }

    fun toggleDynamicAppTool(toolId: String) {
        _dynamicAppTools.update { list ->
            list.map { if (it.id == toolId) it.copy(isEnabled = !it.isEnabled) else it }
        }
    }

    fun deleteDynamicAppTool(toolId: String) {
        _dynamicAppTools.update { list -> list.filterNot { it.id == toolId } }
    }
}

