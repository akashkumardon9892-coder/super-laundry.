package com.example.ui.screens.auth

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRole
import com.example.ui.components.SlideshowBackground
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    registeredSuperAdminPhone: String,
    isSuperAdminAlreadyLoggedIn: Boolean,
    onLoginSuccess: (phone: String, role: UserRole) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selectedRole by remember {
        mutableStateOf(UserRole.CUSTOMER)
    }
    val defaultPhoneForRole = when (selectedRole) {
        UserRole.SUPER_ADMIN -> registeredSuperAdminPhone.ifEmpty { "9876543210" }
        UserRole.LAUNDRY_ADMIN -> "9811122233"
        UserRole.CUSTOMER -> "9988776655"
    }
    var phoneInput by remember { mutableStateOf(defaultPhoneForRole) }
    var showOtpSheet by remember { mutableStateOf(false) }
    var otpInput by remember { mutableStateOf("123456") }
    var isGoogleLogin by remember { mutableStateOf(false) }
    var loginErrorMessage by remember { mutableStateOf<String?>(null) }

    fun sanitizePhone(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        return when {
            digits.length == 12 && digits.startsWith("91") -> digits.substring(2)
            digits.length == 11 && digits.startsWith("0") -> digits.substring(1)
            digits.length > 10 -> digits.takeLast(10)
            else -> digits
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        // 1. Animated Slideshow Background
        SlideshowBackground()

        // Overlay scrim gradient for dim light & clear background image visibility
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.38f),
                            Color.Black.copy(alpha = 0.58f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Branding Section with Clear Hashtags & Trustworthy Title
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = PrimaryPink.copy(alpha = 0.85f)
                    ) {
                        Text(
                            text = "#SuperLaundry",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = PrimaryBlue.copy(alpha = 0.85f)
                    ) {
                        Text(
                            text = "#IndiaNumber1Laundry",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(PrimaryBlue, IndigoGradientEnd)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "SL",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 30.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Super Laundry",
                    style = MaterialTheme.typography.displayLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Black
                )

                Spacer(modifier = Modifier.height(4.dp))

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.45f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(AccentGreen)
                        )
                        Text(
                            text = "India's Most Trusted & Verified Laundry Platform",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Role Selector & Phone Form Card
            Surface(
                shape = RoundedCornerShape(32.dp),
                color = SurfaceDark.copy(alpha = 0.90f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Select Login Portal",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    if (loginErrorMessage != null) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = loginErrorMessage!!,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Role Switcher Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(BackgroundDark)
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        if (!isSuperAdminAlreadyLoggedIn) {
                            RoleTab(
                                label = "Super Admin",
                                isSelected = selectedRole == UserRole.SUPER_ADMIN,
                                onClick = {
                                    selectedRole = UserRole.SUPER_ADMIN
                                    phoneInput = registeredSuperAdminPhone.ifEmpty { "9876543210" }
                                    loginErrorMessage = null
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        RoleTab(
                            label = "Laundry Shop",
                            isSelected = selectedRole == UserRole.LAUNDRY_ADMIN,
                            onClick = {
                                selectedRole = UserRole.LAUNDRY_ADMIN
                                phoneInput = "9811122233"
                                loginErrorMessage = null
                            },
                            modifier = Modifier.weight(1f)
                        )

                        RoleTab(
                            label = "Customer",
                            isSelected = selectedRole == UserRole.CUSTOMER,
                            onClick = {
                                selectedRole = UserRole.CUSTOMER
                                phoneInput = "9988776655"
                                loginErrorMessage = null
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (selectedRole == UserRole.SUPER_ADMIN) {
                        // Super Admin Options
                        Text(
                            text = "Super Admin Authentication",
                            style = MaterialTheme.typography.labelMedium,
                            color = PrimaryBlueLight,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        // Option 1: Primary Google Account
                        Button(
                            onClick = {
                                isGoogleLogin = true
                                val validPhone = sanitizePhone(registeredSuperAdminPhone).ifEmpty { "9876543210" }
                                onLoginSuccess(validPhone, UserRole.SUPER_ADMIN)
                            },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("google_login_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Google",
                                tint = PrimaryBlue,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Login with Primary Google Account",
                                color = OnSurfaceLight,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "— OR —",
                            style = MaterialTheme.typography.labelSmall,
                            color = OnSurfaceVariantDark
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Mobile Number Input Area - ENTIRELY BLUE
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = PrimaryBlue,
                        border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlueLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp)
                        ) {
                            Text(
                                text = "MOBILE NUMBER VERIFICATION",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = phoneInput,
                                onValueChange = {
                                    val cleaned = sanitizePhone(it)
                                    phoneInput = cleaned
                                    loginErrorMessage = null
                                },
                                label = { Text("Mobile Number (+91)", color = Color.White.copy(alpha = 0.9f)) },
                                leadingIcon = {
                                    Icon(Icons.Outlined.Phone, contentDescription = "Phone", tint = Color.White)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.White,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.6f),
                                    focusedLabelColor = Color.White,
                                    unfocusedLabelColor = Color.White.copy(alpha = 0.8f),
                                    focusedContainerColor = Color.White.copy(alpha = 0.15f),
                                    unfocusedContainerColor = Color.White.copy(alpha = 0.10f),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("mobile_number_input")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Continue & Access Portal Button
                    Button(
                        onClick = {
                            val sanitized = sanitizePhone(phoneInput).ifEmpty { defaultPhoneForRole }
                            loginErrorMessage = null
                            onLoginSuccess(sanitized, selectedRole)
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("continue_login_button")
                    ) {
                        Text(
                            text = "Continue to Portal",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = Color.White)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Request OTP Button
                    OutlinedButton(
                        onClick = {
                            val sanitized = sanitizePhone(phoneInput)
                            if (sanitized.length < 10) {
                                phoneInput = defaultPhoneForRole
                            }
                            isGoogleLogin = false
                            showOtpSheet = true
                            loginErrorMessage = null
                        },
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryBlueLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("request_otp_button")
                    ) {
                        Text(
                            text = "Get OTP Verification Code",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Bottom Trust Footer
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Outlined.VerifiedUser, contentDescription = "Security", tint = AccentGreen, modifier = Modifier.size(18.dp))
                Text(
                    text = "100% Secure Encrypted OTP • Multi-Tenant Isolation",
                    style = MaterialTheme.typography.labelSmall,
                    color = OnSurfaceVariantDark
                )
            }
        }
    }

    // OTP Modal Sheet
    if (showOtpSheet) {
        ModalBottomSheet(
            onDismissRequest = { showOtpSheet = false },
            containerColor = SurfaceDark,
            scrimColor = Color.Black.copy(alpha = 0.7f),
            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Enter 6-Digit OTP",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Sent to +91 $phoneInput",
                    style = MaterialTheme.typography.bodyMedium,
                    color = OnSurfaceVariantDark
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Auto Fill Demo Button for ease of testing
                Surface(
                    onClick = { otpInput = "123456" },
                    shape = RoundedCornerShape(12.dp),
                    color = PrimaryBlue.copy(alpha = 0.2f),
                    modifier = Modifier.testTag("autofill_otp_button")
                ) {
                    Text(
                        text = "⚡ Auto-Fill Demo OTP (123456)",
                        style = MaterialTheme.typography.labelMedium,
                        color = PrimaryBlueLight,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = otpInput,
                    onValueChange = { if (it.length <= 6) otpInput = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    textStyle = TextStyle(
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        letterSpacing = 8.sp,
                        color = Color.White
                    ),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryBlueLight,
                        unfocusedBorderColor = OutlineDark,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("otp_input_field")
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        val finalPhone = sanitizePhone(phoneInput).ifEmpty { defaultPhoneForRole }
                        showOtpSheet = false
                        onLoginSuccess(finalPhone, selectedRole)
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("verify_otp_button")
                ) {
                    Text(
                        text = "Verify & Access Dashboard",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun RoleTab(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) PrimaryBlue else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color.White else OnSurfaceVariantDark
        )
    }
}
