package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Blue & Soft Pink Theme Palette
val PrimaryBlue = Color(0xFF0EA5E9)       // Sky Light Blue
val PrimaryBlueLight = Color(0xFF38BDF8)  // Lighter Sky Blue
val PrimaryBlueDark = Color(0xFF0284C7)   // Deep Sky Blue

val PrimaryPink = Color(0xFFEC4899)       // Soft Pink
val PrimaryPinkLight = Color(0xFFF472B6)  // Light Pink
val PrimaryPinkDark = Color(0xFFDB2777)   // Rose Pink
val SoftPink = Color(0xFFFCE7F3)

val LightPinkBackground = Color(0xFFF0F9FF) // Light Blue tint background
val LightPinkSurfaceVariant = Color(0xFFE0F2FE)
val LightPinkBorder = Color(0xFFBAE6FD)

val IndigoGradientStart = Color(0xFF38BDF8) // Light Blue
val IndigoGradientEnd = Color(0xFFEC4899)   // Pink

val AccentGreen = Color(0xFF10B981)
val AccentOrange = Color(0xFFF97316)
val AccentAmber = Color(0xFFF59E0B)
val AccentPurple = Color(0xFF8B5CF6)
val AccentRose = Color(0xFFE11D48)

// Light Blue & White Theme Colors
val BackgroundLight = Color(0xFFF0F9FF)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE0F2FE)
val OnSurfaceLight = Color(0xFF0F172A)      // Deep Navy Black Text
val OnSurfaceVariantLight = Color(0xFF334155) // Slate Navy Text
val OutlineLight = Color(0xFFBAE6FD)

// Dark / High Contrast Theme Colors
val BackgroundDark = Color(0xFFF0F9FF)
val SurfaceDark = Color(0xFFFFFFFF)
val SurfaceVariantDark = Color(0xFFE0F2FE)
val OnSurfaceDark = Color(0xFF0F172A)
val OnSurfaceVariantDark = Color(0xFF334155)
val OutlineDark = Color(0xFFBAE6FD)

// Status Colors
val StatusPending = Color(0xFFEA580C)
val StatusInProcess = Color(0xFF0284C7)
val StatusReady = Color(0xFF0D9488)
val StatusCompleted = Color(0xFF16A34A)
val StatusCancelled = Color(0xFFDC2626)


