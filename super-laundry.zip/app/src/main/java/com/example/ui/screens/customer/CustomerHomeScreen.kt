package com.example.ui.screens.customer

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AiViewModel
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerHomeScreen(
    mainViewModel: MainViewModel,
    aiViewModel: AiViewModel,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentUser by mainViewModel.currentUser.collectAsState()
    val shops by mainViewModel.allShops.collectAsState()
    val banners by mainViewModel.allBanners.collectAsState()
    val staters by mainViewModel.allStaters.collectAsState()
    val customerOrders by mainViewModel.getOrdersForCustomer(currentUser?.phone ?: "9988776655").collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf("Explore") } // Explore, My Orders, AI Support
    var selectedShopForDetail by remember { mutableStateOf<LaundryShop?>(null) }
    var pendingSelectedShop by remember { mutableStateOf<LaundryShop?>(null) }
    var selectedCategoryFilter by remember { mutableStateOf<ServiceCategory?>(null) } // null = All clothes
    var activeViewerStater by remember { mutableStateOf<StaterUpdate?>(null) }

    // Cart / Order state
    val cartQuantities = remember { mutableStateMapOf<String, Int>() }
    var showCheckoutSheet by remember { mutableStateOf(false) }
    var specialInstructions by remember { mutableStateOf("") }
    var activeChatOrderId by remember { mutableStateOf<String?>(null) }
    var showDirectCallDialog by remember { mutableStateOf(false) }
    var callingShopName by remember { mutableStateOf("") }

    var showCustomerSettingsSheet by remember { mutableStateOf(false) }
    var showLanguageThemeDialog by remember { mutableStateOf(false) }
    var showAiAdvancedSettingsDialog by remember { mutableStateOf(false) }
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showLongTermOrderDialog by remember { mutableStateOf(false) }

    val aiUiAction by aiViewModel.uiActionTrigger.collectAsState()
    LaunchedEffect(aiUiAction) {
        when (aiUiAction) {
            is com.example.ui.viewmodel.AiUiAction.OpenSettings -> {
                showCustomerSettingsSheet = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenLanguageSelector -> {
                showLanguageThemeDialog = true
                aiViewModel.clearUiAction()
            }
            is com.example.ui.viewmodel.AiUiAction.OpenAiVoiceSettings -> {
                showAiAdvancedSettingsDialog = true
                aiViewModel.clearUiAction()
            }
            else -> {}
        }
    }

    Scaffold(
        topBar = {
            SleekTopBar(
                title = "Super Laundry",
                subtitle = "India's Verified Care",
                roleBadge = "Customer",
                onProfileClick = { showCustomerSettingsSheet = true }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == "Explore" && selectedShopForDetail == null,
                    onClick = {
                        selectedTab = "Explore"
                        selectedShopForDetail = null
                    },
                    icon = { Icon(Icons.Outlined.Home, contentDescription = "Home") },
                    label = { Text("Explore") },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = PrimaryBlue)
                )
                NavigationBarItem(
                    selected = selectedTab == "Orders",
                    onClick = {
                        selectedTab = "Orders"
                        selectedShopForDetail = null
                    },
                    icon = { Icon(Icons.Outlined.ReceiptLong, contentDescription = "Orders") },
                    label = { Text("My Orders") },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = PrimaryBlue)
                )
                NavigationBarItem(
                    selected = selectedTab == "Laundry Support",
                    onClick = {
                        selectedTab = "Laundry Support"
                        selectedShopForDetail = null
                    },
                    icon = { Icon(Icons.Outlined.PhoneInTalk, contentDescription = "Laundry Support") },
                    label = { Text("Laundry Support") },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = PrimaryBlue)
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when {
                activeChatOrderId != null -> {
                    // Chat & Direct Call View inside Order
                    OrderChatScreen(
                        orderId = activeChatOrderId!!,
                        mainViewModel = mainViewModel,
                        onBack = { activeChatOrderId = null }
                    )
                }
                selectedShopForDetail != null -> {
                    // SHOP DETAIL & RATE CARDS VIEW
                    val shop = selectedShopForDetail!!
                    val rateCard by mainViewModel.getRateCardForShop(shop.id).collectAsState(initial = emptyList())
                    
                    val fullCatalog = remember(shop.id, rateCard) {
                        val standardList = listOf(
                            // Iron Category
                            RateCardItem("c_1", shop.id, ServiceCategory.IRONING, "Casual Cotton Shirt", "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80", 12.0),
                            RateCardItem("c_2", shop.id, ServiceCategory.IRONING, "T-Shirt / Polo", "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=200&q=80", 10.0),
                            RateCardItem("c_3", shop.id, ServiceCategory.IRONING, "Jeans & Casual Pants", "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=200&q=80", 15.0),
                            RateCardItem("c_4", shop.id, ServiceCategory.IRONING, "Dailywear Saree", "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80", 30.0),
                            RateCardItem("c_5", shop.id, ServiceCategory.IRONING, "Kurti & Tops", "https://images.unsplash.com/photo-1564257631407-4deb1f99d992?auto=format&fit=crop&w=200&q=80", 12.0),
                            RateCardItem("c_6", shop.id, ServiceCategory.IRONING, "Leggings & Shorts", "https://images.unsplash.com/photo-1506629082925-2368c7f76df1?auto=format&fit=crop&w=200&q=80", 10.0),
                            RateCardItem("c_7", shop.id, ServiceCategory.IRONING, "Salwar & Pyjamas", "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=200&q=80", 12.0),
                            RateCardItem("c_8", shop.id, ServiceCategory.IRONING, "Towels & Handkerchiefs", "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=200&q=80", 5.0),

                            // Steam Press Category
                            RateCardItem("c_sp1", shop.id, ServiceCategory.STEAM_PRESS, "Formal Executive Shirt", "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=200&q=80", 20.0),
                            RateCardItem("c_sp2", shop.id, ServiceCategory.STEAM_PRESS, "Formal Trouser Pants", "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?auto=format&fit=crop&w=200&q=80", 25.0),
                            RateCardItem("c_sp3", shop.id, ServiceCategory.STEAM_PRESS, "Premium Silk Saree", "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80", 60.0),
                            RateCardItem("c_sp4", shop.id, ServiceCategory.STEAM_PRESS, "Kurta & Pyjama Set", "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=200&q=80", 35.0),
                            RateCardItem("c_sp5", shop.id, ServiceCategory.STEAM_PRESS, "Starch Cotton Shirt / Kurta", "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?auto=format&fit=crop&w=200&q=80", 30.0),
                            RateCardItem("c_sp6", shop.id, ServiceCategory.STEAM_PRESS, "Frocks & Party Dresses", "https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?auto=format&fit=crop&w=200&q=80", 45.0),
                            RateCardItem("c_sp7", shop.id, ServiceCategory.STEAM_PRESS, "Bell-Bottom Trousers", "https://images.unsplash.com/photo-1582552938357-32b906df40cb?auto=format&fit=crop&w=200&q=80", 28.0),
                            RateCardItem("c_sp8", shop.id, ServiceCategory.STEAM_PRESS, "Formal Blazer / Waistcoat", "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=200&q=80", 80.0),

                            // Dry Cleaning Category
                            RateCardItem("c_dc1", shop.id, ServiceCategory.DRY_CLEANING, "Heavy Blanket / Comforter", "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=200&q=80", 399.0),
                            RateCardItem("c_dc2", shop.id, ServiceCategory.DRY_CLEANING, "Heavy Winter Coat & Jacket", "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?auto=format&fit=crop&w=200&q=80", 299.0),
                            RateCardItem("c_dc3", shop.id, ServiceCategory.DRY_CLEANING, "Traditional Sherwani & Kurta Set", "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=200&q=80", 499.0),
                            RateCardItem("c_dc4", shop.id, ServiceCategory.DRY_CLEANING, "2-Piece Suit & Tuxedo", "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=200&q=80", 349.0),
                            RateCardItem("c_dc5", shop.id, ServiceCategory.DRY_CLEANING, "Woolen Sweater & Cardigan", "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=200&q=80", 149.0),
                            RateCardItem("c_dc6", shop.id, ServiceCategory.DRY_CLEANING, "Heavy Designer Lehenga / Frock", "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=200&q=80", 499.0),
                            RateCardItem("c_dc7", shop.id, ServiceCategory.DRY_CLEANING, "Designer Silk Saree & Dupatta", "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=200&q=80", 199.0),
                            RateCardItem("c_dc8", shop.id, ServiceCategory.DRY_CLEANING, "Scarves, Stoles & Stockings", "https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?auto=format&fit=crop&w=200&q=80", 79.0)
                        )
                        if (rateCard.isEmpty()) {
                            standardList
                        } else {
                            val existingNames = rateCard.map { it.clothName.lowercase() }
                            rateCard + standardList.filterNot { std -> existingNames.any { it.contains(std.clothName.lowercase().take(4)) } }
                        }
                    }

                    val filteredItems = if (selectedCategoryFilter == null) fullCatalog else fullCatalog.filter { it.category == selectedCategoryFilter }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            IconButton(onClick = { selectedShopForDetail = null }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                        }

                        item {
                            Box(modifier = Modifier.fillMaxWidth().height(200.dp)) {
                                AsyncImage(
                                    model = shop.bannerUrl,
                                    contentDescription = "Store Banner",
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(24.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Surface(
                                    shape = CircleShape,
                                    shadowElevation = 4.dp,
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(16.dp)
                                        .size(64.dp)
                                ) {
                                    AsyncImage(
                                        model = shop.logoUrl,
                                        contentDescription = "Store Logo",
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }

                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(shop.name, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                                    if (shop.isVerified) {
                                        Surface(shape = CircleShape, color = PrimaryBlue) {
                                            Icon(Icons.Default.Verified, contentDescription = "Verified", tint = Color.White, modifier = Modifier.size(18.dp).padding(2.dp))
                                        }
                                    }
                                }

                                // Store Profile Status Badge
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (shop.isOpen) AccentGreen else Color.Red
                                    ) {
                                        Text(
                                            text = if (shop.isOpen) "🟢 STORE OPEN • ACCEPTING ORDERS" else "🔴 STORE CLOSED CURRENTLY",
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text("🕒 ${shop.shopTiming}", style = MaterialTheme.typography.bodySmall, color = Color.Gray, fontWeight = FontWeight.Medium)
                                }

                                Text("${shop.address} • ${shop.distanceKm} km away", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        // Map Location Preview
                        item {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = PrimaryBlue.copy(alpha = 0.08f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(Icons.Default.Map, contentDescription = "Map", tint = PrimaryBlue)
                                    Column {
                                        Text("Google Map Location", fontWeight = FontWeight.Bold, color = PrimaryBlue)
                                        Text("Lat: ${shop.latitude}, Long: ${shop.longitude}", style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }

                        // Direct Laundry Owner Contact & Support Card
                        item {
                            Surface(
                                shape = RoundedCornerShape(22.dp),
                                color = PrimaryBlue,
                                shadowElevation = 2.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "LAUNDRY OWNER DIRECT HOTLINE",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White.copy(alpha = 0.85f),
                                            fontWeight = FontWeight.Black
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "${shop.name} Owner",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = "Direct Number: ${shop.phone}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color.White,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            callingShopName = "${shop.name} (${shop.phone})"
                                            showDirectCallDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                                    ) {
                                        Icon(Icons.Default.PhoneInTalk, contentDescription = "Call Owner", tint = Color.White, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Call Owner", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }

                        // Prominent Rate Card & Price List Header Card
                        item {
                            Surface(
                                shape = RoundedCornerShape(22.dp),
                                color = PrimaryPink,
                                shadowElevation = 3.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ReceiptLong,
                                        contentDescription = "Price List",
                                        tint = Color.White,
                                        modifier = Modifier.size(32.dp)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "ENTIRE LAUNDRY RATE CARD & PHOTOS",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White.copy(alpha = 0.85f),
                                            fontWeight = FontWeight.Black
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "${shop.name} Full Rate Card",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "All photos and rates for pants, shirts, frocks, tops, sarees, t-shirts, suits, kurtas, leggings, sweaters, coats & salwars are displayed below before ordering.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.White.copy(alpha = 0.95f)
                                        )
                                    }
                                }
                            }
                        }

                        // Category Rate Card Tabs (ALL CLOTHES, Steam Iron, Wash, Dry Clean)
                        item {
                            LazyRow(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(if (selectedCategoryFilter == null) PrimaryBlue else Color.Transparent)
                                            .clickable { selectedCategoryFilter = null }
                                            .padding(horizontal = 16.dp, vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            "All Clothes (${fullCatalog.size})",
                                            color = if (selectedCategoryFilter == null) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                                items(ServiceCategory.values()) { cat ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(if (selectedCategoryFilter == cat) PrimaryBlue else Color.Transparent)
                                            .clickable { selectedCategoryFilter = cat }
                                            .padding(horizontal = 16.dp, vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            cat.displayName,
                                            color = if (selectedCategoryFilter == cat) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }

                        // Rate Items
                        items(filteredItems) { item ->
                            val currentQty = cartQuantities[item.id] ?: 0
                            SleekRateCardItemView(
                                item = item,
                                quantity = currentQty,
                                onQuantityChange = { qty ->
                                    if (qty <= 0) cartQuantities.remove(item.id) else cartQuantities[item.id] = qty
                                }
                            )
                        }

                        // Place Order Bar Button
                        item {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { showCheckoutSheet = true },
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("place_order_button")
                            ) {
                                Text("Place Order with Selected Laundry", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
                selectedTab == "Orders" -> {
                    // CUSTOMER ORDERS
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Text("My Laundry Orders", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        }

                        items(customerOrders) { order ->
                            SleekOrderCard(
                                order = order,
                                onClick = { activeChatOrderId = order.id },
                                onCallShop = { shopName ->
                                    callingShopName = shopName
                                    showDirectCallDialog = true
                                },
                                onChatCustomer = { activeChatOrderId = order.id }
                            )
                        }
                    }
                }
                selectedTab == "Laundry Support" -> {
                    // CUSTOMER LAUNDRY DIRECT SUPPORT
                    CustomerLaundrySupportView(
                        shops = shops,
                        onCallShop = { shopName, shopPhone ->
                            callingShopName = "$shopName ($shopPhone)"
                            showDirectCallDialog = true
                        }
                    )
                }
                else -> {
                    // EXPLORE VERIFIED LAUNDRIES
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // AI Namaste Customer Greeting Card
                        item {
                            Surface(
                                shape = RoundedCornerShape(22.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryBlue.copy(alpha = 0.25f)),
                                shadowElevation = 2.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(PrimaryBlue.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("🙏", fontSize = 24.sp)
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Namaste, ${currentUser?.name ?: "Valued Customer"}!",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Black,
                                            color = Color.Black
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "Wishing you a happy, fresh, and prosperous day ahead! Select any verified laundry below to check its price list & rate card.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color.Black.copy(alpha = 0.75f)
                                        )
                                    }
                                }
                            }
                        }

                        // Customer Profile & Long-Term Order Status Card
                        item {
                            val isLongTerm = currentUser?.isLongTermCustomer == true || customerOrders.any { it.isLongTermOrder || it.itemsSummary.contains("Long-Term", ignoreCase = true) }
                            Surface(
                                shape = RoundedCornerShape(22.dp),
                                color = if (isLongTerm) PrimaryPink.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, if (isLongTerm) PrimaryPink else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Icon(
                                                imageVector = if (isLongTerm) Icons.Default.CardMembership else Icons.Default.AccountCircle,
                                                contentDescription = null,
                                                tint = if (isLongTerm) PrimaryPink else PrimaryBlue
                                            )
                                            Text(
                                                text = if (isLongTerm) "★ LONG-TERM LAUNDRY PROFILE" else "MY CUSTOMER PROFILE",
                                                fontWeight = FontWeight.Black,
                                                fontSize = 12.sp,
                                                color = if (isLongTerm) PrimaryPink else PrimaryBlue
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = { showEditProfileDialog = true },
                                            shape = RoundedCornerShape(12.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp), tint = PrimaryPink)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Edit Profile Data", fontSize = 11.sp, color = PrimaryPink, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("Name: ${currentUser?.name ?: "Valued Customer"}", fontWeight = FontWeight.Bold, color = Color.Black)
                                        Text("Phone: ${currentUser?.phone ?: "Not registered"}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        Text("Email: ${currentUser?.email ?: "customer@laundry.com"}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        Text("Address: ${currentUser?.address ?: "Click Edit Profile to add delivery address"}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                        if (isLongTerm) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Surface(shape = RoundedCornerShape(8.dp), color = AccentGreen) {
                                                Text(
                                                    "Active Long-Term Pass: ${currentUser?.subscriptionPlanName ?: "Monthly Subscription Active"}",
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                                    color = Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Laundry Admin & Super Admin Staters / Video Stories Bar
                        item {
                            StaterStoryBar(
                                staters = staters,
                                currentRole = UserRole.CUSTOMER,
                                currentUserPhone = currentUser?.phone ?: "",
                                onAddStaterClick = {},
                                onStaterClick = { selectedStater -> activeViewerStater = selectedStater }
                            )
                        }

                        // Offer Banner Carousel (Super Admin Banners)
                        if (banners.isNotEmpty()) {
                            item {
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    items(banners) { banner ->
                                        Surface(
                                            shape = RoundedCornerShape(24.dp),
                                            color = IndigoGradientStart,
                                            modifier = Modifier.width(300.dp)
                                        ) {
                                            Column(modifier = Modifier.padding(20.dp)) {
                                                Text(banner.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(banner.subtitle, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.85f))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Text("Verified Laundry Shops Near You", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }

                        items(shops) { shop ->
                            Surface(
                                onClick = { pendingSelectedShop = shop },
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Box {
                                        AsyncImage(
                                            model = shop.logoUrl,
                                            contentDescription = "Store Logo",
                                            modifier = Modifier
                                                .size(68.dp)
                                                .clip(RoundedCornerShape(20.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                        Surface(
                                            shape = CircleShape,
                                            color = if (shop.isOpen) AccentGreen else Color.Red,
                                            modifier = Modifier
                                                .size(14.dp)
                                                .align(Alignment.TopEnd)
                                                .border(2.dp, Color.White, CircleShape)
                                        ) {}
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(shop.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            if (shop.isVerified) {
                                                Icon(Icons.Default.Verified, contentDescription = "Verified", tint = PrimaryBlue, modifier = Modifier.size(16.dp))
                                            }
                                        }

                                        // Store Profile Status
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = if (shop.isOpen) "🟢 Open Now" else "🔴 Closed",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (shop.isOpen) AccentGreen else Color.Red
                                            )
                                            Text("• ${shop.shopTiming}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                        }

                                        Text("${shop.distanceKm} km • ${shop.address}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Icon(Icons.Default.Star, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(16.dp))
                                            Text("${shop.rating}", fontWeight = FontWeight.Bold)
                                            Text("(${shop.reviewCount} reviews)", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog before opening Laundry Admin Shop
    if (pendingSelectedShop != null) {
        val targetShop = pendingSelectedShop!!
        AlertDialog(
            onDismissRequest = { pendingSelectedShop = null },
            icon = {
                Icon(Icons.Default.Storefront, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(36.dp))
            },
            title = {
                Text(
                    text = "Confirm Laundry Selection",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Do you want to view all clothing rates and photos for ${targetShop.name}?",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = PrimaryBlue.copy(alpha = 0.08f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "📍 ${targetShop.address} (${targetShop.distanceKm} km away)\n📞 Direct Phone: ${targetShop.phone}",
                            style = MaterialTheme.typography.bodySmall,
                            color = PrimaryBlue,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedShopForDetail = targetShop
                        pendingSelectedShop = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Yes, View Rate Card & Order")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { pendingSelectedShop = null },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Checkout Sheet
    if (showCheckoutSheet && selectedShopForDetail != null) {
        val shop = selectedShopForDetail!!
        val rateCard by mainViewModel.getRateCardForShop(shop.id).collectAsState(initial = emptyList())
        val selectedCartItems = rateCard.filter { (cartQuantities[it.id] ?: 0) > 0 }
        val computedTotal = if (selectedCartItems.isNotEmpty()) {
            selectedCartItems.sumOf { it.price * (cartQuantities[it.id] ?: 1) }
        } else 180.0
        val computedSummary = if (selectedCartItems.isNotEmpty()) {
            selectedCartItems.joinToString(", ") { "${it.clothName} x${cartQuantities[it.id]}" }
        } else "Selected Steam Wash & Care Items"

        ModalBottomSheet(
            onDismissRequest = { showCheckoutSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text("Confirm Order to ${shop.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Laundry Owner Phone: ${shop.phone}", style = MaterialTheme.typography.bodyMedium, color = PrimaryBlue, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(12.dp))

                // Selected items rate card summary
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Selected Items Rate Card Summary:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(computedSummary, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Order Amount:", fontWeight = FontWeight.Bold)
                            Text("₹${computedTotal.toInt()}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = PrimaryPink)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = specialInstructions,
                    onValueChange = { specialInstructions = it },
                    label = { Text("Special Wash/Iron Instructions") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val newOrder = Order(
                            id = "ord_${System.currentTimeMillis()}",
                            orderNumber = "SL-${(1000..9999).random()}",
                            shopId = shop.id,
                            shopName = shop.name,
                            customerPhone = currentUser?.phone ?: "9988776655",
                            customerName = currentUser?.name ?: "Customer",
                            itemsSummary = computedSummary,
                            totalPrice = computedTotal,
                            status = OrderStatus.NEW,
                            instructions = specialInstructions
                        )
                        mainViewModel.placeOrder(newOrder) {
                            showCheckoutSheet = false
                            selectedShopForDetail = null
                            selectedTab = "Orders"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("Submit Order to Laundry Owner", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Direct Laundry Call Modal Sheet
    if (showDirectCallDialog) {
        ModalBottomSheet(
            onDismissRequest = { showDirectCallDialog = false },
            containerColor = SurfaceDark
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Calling Laundry Shop...",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = callingShopName.ifEmpty { "Super Laundry Partner" },
                    style = MaterialTheme.typography.titleMedium,
                    color = PrimaryPink,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Direct Verified Laundry Hotline • Connected",
                    style = MaterialTheme.typography.bodySmall,
                    color = AccentGreen
                )

                Spacer(modifier = Modifier.height(20.dp))

                VoiceAiWaveVisualizer(isListening = true)

                Spacer(modifier = Modifier.height(24.dp))

                FloatingActionButton(
                    onClick = { showDirectCallDialog = false },
                    containerColor = AccentRose,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(64.dp)
                ) {
                    Icon(Icons.Default.CallEnd, contentDescription = "End Call")
                }
            }
        }
    }

    // Customer Profile & App Settings Sheet
    if (showCustomerSettingsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCustomerSettingsSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Customer App Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.Black)

                Surface(
                    onClick = {
                        showCustomerSettingsSheet = false
                        showEditProfileDialog = true
                    },
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = PrimaryPink)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Edit Customer Profile Data", fontWeight = FontWeight.SemiBold, color = Color.Black)
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                    }
                }

                Surface(
                    onClick = {
                        showCustomerSettingsSheet = false
                        showLanguageThemeDialog = true
                    },
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = PrimaryBlue)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Language & Day/Night Theme", fontWeight = FontWeight.SemiBold, color = Color.Black)
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                    }
                }

                Surface(
                    onClick = {
                        showCustomerSettingsSheet = false
                        selectedTab = "Laundry Support"
                    },
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.HeadsetMic, contentDescription = null, tint = AccentGreen)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Laundry Support & Direct Hotline", fontWeight = FontWeight.SemiBold, color = Color.Black)
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
                    }
                }

                OutlinedButton(
                    onClick = {
                        showCustomerSettingsSheet = false
                        onLogout()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Logout Account", color = AccentRose, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showLanguageThemeDialog) {
        LanguageThemeDialog(mainViewModel = mainViewModel, aiViewModel = aiViewModel, userRole = UserRole.CUSTOMER, onDismiss = { showLanguageThemeDialog = false })
    }

    if (showEditProfileDialog) {
        EditCustomerProfileDialog(
            initialName = currentUser?.name ?: "",
            initialPhone = currentUser?.phone ?: "",
            initialEmail = currentUser?.email,
            initialAddress = currentUser?.address ?: "",
            initialIsLongTerm = currentUser?.isLongTermCustomer ?: false,
            initialPlanName = currentUser?.subscriptionPlanName,
            onSave = { name, phone, email, address, isLongTerm, planName ->
                mainViewModel.updateCustomerProfile(
                    phone = phone,
                    name = name,
                    email = email,
                    address = address,
                    isLongTermCustomer = isLongTerm,
                    subscriptionPlanName = planName
                )
            },
            onDismiss = { showEditProfileDialog = false }
        )
    }

    if (showLongTermOrderDialog) {
        PlaceLongTermOrderDialog(
            mainViewModel = mainViewModel,
            customerPhone = currentUser?.phone ?: "9988776655",
            customerName = currentUser?.name ?: "Valued Customer",
            customerAddress = currentUser?.address ?: "Default Address",
            onDismiss = { showLongTermOrderDialog = false }
        )
    }

    if (activeViewerStater != null) {
        StaterViewerDialog(
            stater = activeViewerStater!!,
            currentUserRole = UserRole.CUSTOMER,
            currentUserPhone = currentUser?.phone ?: "",
            onDeleteStater = { mainViewModel.deleteStater(it) },
            onDismiss = { activeViewerStater = null }
        )
    }
}

@Composable
private fun CustomerLaundrySupportView(
    shops: List<LaundryShop>,
    onCallShop: (shopName: String, shopPhone: String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = PrimaryBlue,
                shadowElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("LAUNDRY STORE DIRECT SUPPORT", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f), fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Contact Laundry Owners Directly", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Connect directly with the shop owner for your laundry submission, pickup scheduling, and care instructions.", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.95f))
                }
            }
        }

        item {
            Text("Verified Laundry Shop Contacts", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        items(shops) { shop ->
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    AsyncImage(
                        model = shop.logoUrl,
                        contentDescription = shop.name,
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(18.dp)),
                        contentScale = ContentScale.Crop
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(shop.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(shop.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Owner Phone: ${shop.phone}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = PrimaryBlue)
                    }

                    Button(
                        onClick = { onCallShop(shop.name, shop.phone) },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPink),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.PhoneInTalk, contentDescription = "Call Owner", tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Call Owner", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}
