package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.data.model.UserRole
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.customer.CustomerHomeScreen
import com.example.ui.screens.laundryadmin.LaundryAdminMainScreen
import com.example.ui.screens.superadmin.SuperAdminMainScreen
import com.example.ui.theme.SuperLaundryTheme
import com.example.ui.viewmodel.AiViewModel
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()
    private val aiViewModel: AiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SuperLaundryTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SuperLaundryApp(
                        mainViewModel = mainViewModel,
                        aiViewModel = aiViewModel
                    )
                }
            }
        }
    }
}

@Composable
fun SuperLaundryApp(
    mainViewModel: MainViewModel,
    aiViewModel: AiViewModel
) {
    val currentUser by mainViewModel.currentUser.collectAsState()
    val activeRole by mainViewModel.activeRole.collectAsState()
    val registeredPhone by mainViewModel.registeredSuperAdminPhone.collectAsState()

    if (currentUser == null) {
        LoginScreen(
            registeredSuperAdminPhone = registeredPhone,
            isSuperAdminAlreadyLoggedIn = false,
            onLoginSuccess = { phone, role ->
                mainViewModel.loginWithOtp(phone, role) {}
            }
        )
    } else {
        when (activeRole) {
            UserRole.SUPER_ADMIN -> {
                SuperAdminMainScreen(
                    mainViewModel = mainViewModel,
                    aiViewModel = aiViewModel,
                    onLogout = { mainViewModel.logout() }
                )
            }
            UserRole.LAUNDRY_ADMIN -> {
                LaundryAdminMainScreen(
                    mainViewModel = mainViewModel,
                    aiViewModel = aiViewModel,
                    onLogout = { mainViewModel.logout() }
                )
            }
            UserRole.CUSTOMER -> {
                CustomerHomeScreen(
                    mainViewModel = mainViewModel,
                    aiViewModel = aiViewModel,
                    onLogout = { mainViewModel.logout() }
                )
            }
        }
    }
}
